--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2011 University of Washington Laboratory Medicine
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Laboratory Medicine and is
--    not to be disclosed to any third party without prior express
--    written permission of University of Washington Laboratory Medicine.
--    University of Washington Laboratory Medicine, as the
--    author and owner under 17 U.S.C. Sec. 201(b) of this work made
--    for hire, claims copyright in this material as an unpublished 
--    work under 17 U.S.C. Sec.s 102 and 104(a)   
-- 
--  *********************************************************************


-- Used to determine data for this test from the LIS differs from what has been
-- stored in the DB. The columns that end with '_hash' contain a sha512 hash
-- value for the values, which is 128 characters in length.
--   whole_line_hash contains a hash for an entire line from the feed. It
--     provides a quick check to see if anything changed. 
--   oltg_hash contains a hash for only those values that go into the oltg
--     table, that come from the LIS feed. Note that there are several columns
--     defined in the feed that are always empty. See Tom's notebook 7, page
--     104.
--   reference_ranges_hash contains a hash for the reference ranges.
--   billing_code_hash contains a hash for the billing and CPT codes.
--   component_tests_hash contains a hash for the component tests.
CREATE TABLE IF NOT EXISTS "lis_feed" (
  "mnemonic" varchar(16) NOT NULL PRIMARY KEY,
  "whole_line_hash"       char(128) NOT NULL,
  "oltg_hash"             char(128) NOT NULL,
  "billing_codes_hash"    char(128) NOT NULL,
  "component_tests_hash"  char(128) NOT NULL,
  "reference_ranges_hash" char(128) NOT NULL,
  --                                     12345678901234567890123
  "updated_date" varchar(23) NOT NULL -- YYYY-MM-DD HH:MM:SS.SSS format
);
