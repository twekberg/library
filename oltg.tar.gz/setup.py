from os import path
import subprocess

from distutils.core import setup
from setuptools import find_packages

# Provide the abbreviated git sha and the svn revision number as
# package data. These commands are run whenever setup.py is
# invoked. Use `python setup.py -h` to refresh files in oltg/data
# without building or installing.
subprocess.call('git log --pretty=format:%h -n 1 > oltg/data/sha', shell=True)
subprocess.call("svn info 2> /dev/null | grep Revision | cut -d' ' -f2 > oltg/data/rev", shell=True)
from oltg import __version__

params = {'author': 'Tom Ekberg',
          'author_email': 'tekberg@uw.edu',
          'description': 'Online Test Guide',
          'name': 'oltg',
          'package_dir': {'oltg': 'oltg'},
          'packages': find_packages(exclude=['scripts', 'oltg.maybe-trash']),
          'scripts': [],
          'url': 'https://uwmc-labmed.beanstalkapp.com/developers/browse/mastermu',
          'version': __version__,
          'package_data': {'oltg': [path.join('data',f) for f in ['sha','rev']]},
          'zip_safe': False,            # Force directory instead of egg file
          # egg files don't work well with WSGI files.
          }

setup(**params)
