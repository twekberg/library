#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2012 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Support for database dependent operations (operations implemented differently
for different databases). These are:
  full text search
  Keeping Postgres SEQUENCEs up-to-date
  lpad
"""

import re


# Postgres full text function to_tsquery treats has these metacharacters.
# To use them in a query, one must prepend a '\'.
pg_special = re.compile('([&|!()*@:])')


def full_text_where(db_type, columns):
    """
    Generate the proper full text code specific to the database
    suitable for use in a WHERE clause.

    Assumes that the search text named in the query is :search_text.
    """
    # MySQL uses the MATCH operator while Postgress uses @@.
    if db_type == 'postgresql':
        return "to_tsvector('mastermu_oltg.very_simple', %s) @@ to_tsquery('mastermu_oltg.very_simple', :search_text)" % (
            " || ' ' || ".join(columns), )

    elif db_type == 'mysql':
        return 'MATCH(%s) AGAINST(:search_text IN BOOLEAN MODE)' % (
            ', '.join(columns), )
    else:
        raise Exception('Unknown db_type: "%s"' % (db_type,))


def full_text_string(db_type, search_text):
    """
    Convert the full text search string into a form specific to the
    database being used.
    """
    # Both of them add a wildcard if a search_text word has 3 or more
    # characters, otherwise do an exact match on the word.
    # Given the search_text of 'hep c'
    # Postgres: 'hep:* & c'
    # MySQL:    '+hep* +c'
    # The python split() function splits on any whitespace string, with empties being removed.
    # split(' ') doesn't, which generates an exception later on.
    # 'a b  c d'.split() -> ['a', 'b', 'c', 'd']
    # 'a b  c d'.split(' ') -> ['a', 'b', '', 'c', 'd']
    if db_type == 'postgresql':
        search_text = re.sub(pg_special, r'\\\1', search_text)
        return ' & '.join([word if len(word)<3 else (word + ':*') for word in search_text.split()])
    elif db_type == 'mysql':
        return ' '.join(['+' + (word if len(word)<3 else (word + '*')) for word in search_text.split()])
    else:
        raise Exception('Unknown db_type: "%s"' % (db_type,))


def update_sequences(db_type, session):
    """
    After some operations the PostgreSQL SEQUENCES are out of
    date. The next INSERT using them will cause a primary key
    violation.

    Returns the number of sequences changed.
    """
    n_sequences = 0
    if db_type == 'postgresql':
        for db_type in ['', '_staging']:
            for db in ['billing_and_cpt_codes', 'caution_urls', 'component_tests',
                       'cross_references', 'reference_ranges']:
                max = list(session.execute('SELECT MAX(id) FROM mastermu_oltg.%s%s' % (db, db_type)))
                if len(max) != 1:
                    raise Exception("Expected SELECT MAX for table %s%s to have length 1, got length %d: %s"
                                    % (db, db_type, len(max), max))
                max = max[0][0]         # First row, first column
                # If count(*) = 0 then max will be None. No need to update the sequence for that case.
                if max is not None:
                    session.execute("ALTER SEQUENCE mastermu_oltg.%s%s_id_seq RESTART WITH %d"
                                    % (db, db_type, max+1))
                    n_sequences += 1
    return n_sequences


def lpad(db_type, expr, len):
    """
    Generate an expression that performs a left pad with blanks up to the specified length.

    Note: if a string literal is passed, is must have leading/trailing single quotes.
    """
    if db_type == 'postgresql':
        return "LPAD(%s||'', %d, ' ')" % (expr, len)
    elif db_type == 'mysql':
        return "LPAD(concat(%s,''), %d, ' ')" % (expr, len)
    elif db_type == 'sqlite':
        return "substr('%s'||%s, -%d, %d)" % (' ' * len, expr, len, len)
    else:
        raise Exception('Unknown db_type: "%s"' % (db_type,))


def insensitive_like(db_type):
    """
    Return the verb for a case insensitive LIKE.
    """
    if db_type == 'postgresql':
        return "ILIKE"
    elif db_type == 'mysql':
        return "LIKE"                   # Defaults to case insensitive
    elif db_type == 'sqlite':
        return "LIKE"                   # Defaults to case insensitive
    else:
        raise Exception('Unknown db_type: "%s"' % (db_type,))

def regex(db_type, pattern):
    """
    Return the verb and pattern to do a regular expression match.
    """
    if db_type == 'postgresql':
        return "SIMILAR TO E'%s'" % (pattern,)
    elif db_type == 'mysql':
        return "REGEXP '%s'" % (pattern,)
    elif db_type == 'sqlite':
        raise Exception('%s does not implement the REGEXP function"' % (db_type,))
    else:
        raise Exception('Unknown db_type: "%s"' % (db_type,))
    
