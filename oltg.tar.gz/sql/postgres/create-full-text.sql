--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2012 University of Washington Laboratory Medicine
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Laboratory Medicine and is
--    not to be disclosed to any third party without prior express
--    written permission of University of Washington Laboratory Medicine.
--    University of Washington Laboratory Medicine, as the
--    author and owner under 17 U.S.C. Sec. 201(b) of this work made
--    for hire, claims copyright in this material as an unpublished 
--    work under 17 U.S.C. Sec.s 102 and 104(a)   
-- 
--  *********************************************************************

-- Full text settings needed for postgres.


-- Before doing the next command you need to create the empty stopwords file on
-- db1:
--    sudo touch /usr/share/pgsql/tsearch_data/empty.stop

CREATE TEXT SEARCH DICTIONARY mastermu_oltg.simple_dict (
    TEMPLATE = pg_catalog.simple,
    STOPWORDS = empty);

COMMENT ON TEXT SEARCH DICTIONARY mastermu_oltg.simple_dict
    IS 'very simple dictionary; just lower case and no stopwords';


CREATE TEXT SEARCH CONFIGURATION mastermu_oltg.very_simple (COPY = simple);

COMMENT ON TEXT SEARCH CONFIGURATION mastermu_oltg.very_simple
    IS 'very simple configuration with no stopwords';

ALTER TEXT SEARCH CONFIGURATION mastermu_oltg.very_simple
    ALTER MAPPING FOR asciiword WITH mastermu_oltg.simple_dict;

-- Now create the indexes. All of these together take < 1 second to create.
CREATE INDEX ft_oltg ON mastermu_oltg.oltg
    USING gin(to_tsvector('very_simple',
    mnemonic || ' ' || name || ' ' || lab_name || ' ' || orca_name || ' ' || epic_name));

CREATE INDEX ft_cross_reference ON mastermu_oltg.cross_references
    USING gin(to_tsvector('very_simple', cross_reference ));

CREATE INDEX ft_oltg_staging ON mastermu_oltg.oltg_staging
    USING gin(to_tsvector('very_simple',
    mnemonic || ' ' || name || ' ' || lab_name || ' ' || orca_name || ' ' || epic_name));

CREATE INDEX ft_cross_reference_staging ON mastermu_oltg.cross_references_staging
    USING gin(to_tsvector('very_simple', cross_reference ));
