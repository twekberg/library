#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************

"""
The HTTP_USER_AGENT environment variable specifies the type of browser and the version.

Create a parser and call the parse method. Returns a tuple of ('browser string', 'version string').
"""

# These are HTTP_USER_AGENT values from 5 browsers.

# Firefox 8.0
# Mozilla/5.0 (Windows NT 6.1; WOW64; rv:8.0) Gecko/20100101 Firefox/8.0

# IE 9.0
# Mozilla/5.0 (compatible; MSIE 9.0; Windows NT 6.1; WOW64; Trident/5.0)

# IE 6.0
# Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)

# Google Chrome 15.0
# Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/535.2 (KHTML, like Gecko) Chrome/15.0.874.121 Safari/535.2

# Safari 5.1
# Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50


import re


class UserAgentParser(object):
    # regex patterns for the known browser types.
    patterns = [(r'(Firefox)/(\d+\.\d)', 1, 2),
                (r'MS(IE)\s+(\d+\.\d);', 1, 2),
                (r'(Chrome)/(\d+\.\d)', 1, 2),
                (r'Version/(\d+\.\d)\s+(Safari)', 2, 1),
                ]
    def __init__(self):
        pass

    def parse(self, ua):
        ua = str(ua)
        for (pattern, browser, version) in UserAgentParser.patterns:
            m = re.search(pattern, ua)
            if m:
                return (m.group(browser), m.group(version))
        return ('Unknown', '0.0')
