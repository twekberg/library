#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Controller for the reference range page.
"""

import oltg
import oltg.controllers.collectors as collectors
from oltg.controllers import app
import oltg.models
import oltg.models.access_log as access_log
from oltg.templates.RefRanges import RefRanges
from oltg.templates.DisplayError import DisplayError
from oltg.controllers.db_interface import get_mnemonic_detail
from oltg.controllers.common import common_namespace


def ref_ranges_page(environ, start_response, logger):
    """Display details for a test."""
    session = environ.get('SESSION', None)
    config_dict = environ['CONFIG']

    namespace = dict(mnemonic_data=[])
    for mne in [m.upper() for m in get_mnemonics(session)]:
        namespace['mnemonic_data'].append(get_mnemonic_detail(mne,
                                                              from_database=config_dict['read_mnemonics_from_database'] == 'True',
                                                              json_dir=config_dict.get('mnemonics_json_dir')))
    namespace.update(common_namespace(environ, config_dict))
    start_response('200 OK', [('Content-Type', 'text/html')])
    if 'error_message' in namespace:
        t = DisplayError(searchList = [namespace])
    else:
        t = RefRanges(searchList = [namespace])
    return [str(t.respond())]


def get_mnemonics(session):
    """
    Get the list of mnemonics that have reference ranges.
    """
    # Need to pull the mnemonic out of each row in the resultset.
    return [row[0] for row in session.execute("""
SELECT distinct(mnemonic) FROM mastermu_oltg.reference_ranges ORDER BY 1""")]


