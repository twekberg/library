"""
Validates the caution URLs for all tests.

Reports the mnemonic and URLs that are in error. Also lists the mnemonics and
URLs from the old OLTG that have truncated URLs but do not cause an HTTP error.

Some of the HTTP status codes are:
  200 - OK (trundated URL)
  401 - Unauthorized
  403 - Forbidden
  404 - Not Found
  406 - Not Acceptable
  415 - Unsupported Media Type
  500 - Internal Server Error
  503 - Service Unavailable

Running time is about 7 minutes.
"""


import argparse
import BaseHTTPServer
import errno
import httplib
import socket
from urllib2 import urlopen,URLError
import re

import oltg.subcommands
import oltg.models


# Some exceptions raised by openurl don't have a getcode method to retrieve the
# HTTP status code. One of them is a ???? object which has a reason instance
# variable that contains the errno value (the errno attribute is None!?). This
# dict maps the errno value to the corresponding HTTP status code.
errno_to_http = {errno.ETIMEDOUT: httplib.REQUEST_TIMEOUT,
                 # No such file or directory -> Not Acceptable
                 -errno.ENOENT: httplib.NOT_ACCEPTABLE,
                 }

def build_parser(parser):
    oltg.subcommands.default_parser(parser)


def action(args):
    (d, session, engine) = oltg.subcommands.init_args(args)
    try:
        bad_mnemonics = []
        for (mnemonic, url) in get_all_urls(session):
            status_code = get_url_status_code(url)
            if status_code != 200:
                print '%s\t%d\t%s' % (mnemonic, status_code, url)
                bad_mnemonics.append(mnemonic)
        truncated_urls = get_truncated_urls(session, bad_mnemonics)
        status_code = 200               # These weren't flagged as errors
        for (mnemonic, url) in truncated_urls:
            # Split out just the URLs
            print '%s\t%d\t%s' % (mnemonic,
                                  status_code,
                                  ('\n%s\t%s\t' % (mnemonic, status_code)).join([both.split('#')[0] for both in url.split('~')]))
    finally:
        ## We are done with the session. Close it.
        oltg.models.release_session(session, engine)


def get_all_urls(session):
    """
    Return a list of (mnemonic,url) pairs.
    """
    sql = "SELECT mnemonic, address FROM mastermu_oltg.caution_urls ORDER BY 1"
    return list(session.execute(sql))


def get_url_status_code(url):
    """
    Validate URL. 
    Returns the HTTP status code. 200 means success.
    """
    try:
        sock = urlopen(url)
        sock.read(1)                  # Try to read from it
        sock.close()
        return sock.getcode()
    except URLError as e:
        if 'getcode' in dir(e):
            return e.getcode()
        if type(e.reason) == type(socket.error()):
            m = re.search(r'^\(error\((\d+),', str(e.args))
            if m:
                errno = int(m.group(1))
                if errno in errno_to_http:
                    return errno_to_http[errno]
        if type(e.reason) == type(socket.gaierror()):
            m = re.search(r'^\(gaierror\((-?\d+),', str(e.args))
            if m:
                errno = int(m.group(1))
                if errno in errno_to_http:
                    return errno_to_http[errno]
        if 'reason' in dir(e) and e.reason:
            m = re.search(r'^\[Errno\s+(\d+)\]', e.reason)
            if m:
                errno = int(m.group(1))
                if errno in errno_to_http:
                    return errno_to_http[errno]
        return e.getcode()
    except UnicodeError:
        return httplib.UNSUPPORTED_MEDIA_TYPE


def get_truncated_urls(session, bad_mnemonics):
    """
    The byblos OLTG stores all of the URL into a field that can contain at most
    255 characters.  This function returns a list of (mnemonic,urls) that are
    exactly that length.  The bad_mnemonics list are those that have already
    been identified as having errors.
    """
    sql = """SELECT mnemonic,cautions FROM mastermu.oltg
WHERE length(cautions)>=255 AND mnemonic not in ('%s')""" % "','".join(bad_mnemonics)
    return list(session.execute(sql))
