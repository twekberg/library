#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Import tests that are sendouts = Lab Undefined Order.
"""

# Example:
#   ./runoltg import_cerner_sendouts filename

from datetime import datetime
import os
import os.path
import random
import re
import sys

from labmed.util.boolean import to_bool
from labmed.util.pluralize import just_pluralize
import labmed.spreadsheet_reader

import oltg.subcommands
import oltg.models
import oltg.models.object_queries as object_queries
from oltg.models.create_models import (Oltg,
                                       CernerPlaceholderMap,
                                       CernerNonplaceholderSynonym,
                                       CernerSynonym)
from oltg.models.messages import Messages


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    labmed.spreadsheet_reader.spreadsheet_parser(parser, what_file='cerner sendout')


def action(args):
    """
    Scan the sendout data we got from Chuck.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    messages = Messages(session, 'Load sendouts')
    try:
        ok = False
        messages.store('started')
        try:
            act = labmed.spreadsheet_reader.Action(args.input_filename,
                                                   RowHandler,
                                                   row_handler_args = {'session': session,
                                                                       'only_print': False},
                                                   csv_sep=args.csv_sep)
            act.loop()
            ok = True
        except Exception as e:
            # Unexpected exception.
            messages.store('Caught exception', ok, e)
        messages.store('completed. count=%d, missing synonyms=%d' % (act.count, act.row_handler.missing_synonyms), ok)
    finally:
        session.commit()
        oltg.models.release_session(session, engine)
    return 0 if ok else 1               # exit status


class RowHandler(labmed.spreadsheet_reader.BaseRowHandler):
    """
    Default row handler simply copies the data into the object.
    """
    def __init__(self, session, column_names, only_print):
        labmed.spreadsheet_reader.BaseRowHandler.__init__(self, session, None, column_names, only_print)
        self.now = datetime.now()
        self.missing_synonyms = 0

    def handle(self, row):
        mnemonic = row[self.column_map['mnemonic']]
        is_sendout = to_bool(row[self.column_map['use_lab_undefined_test']])
        labund_code = 1                 # Dummy cerner_orders row for labund
        labund_mnemonic = 'using_labund'
        o = list(self.session.query(CernerPlaceholderMap)
                 .filter(CernerPlaceholderMap.lab_mnemonic == mnemonic)
                 .all()
                 )
        if len(o) == 0:
            # Not there yet, or was deleted. Need to create one.
            o = CernerPlaceholderMap()
            o.lab_mnemonic = mnemonic
            o.placeholder_lab_mnemonic = labund_mnemonic
            o.ready_for_delete = False
            self.session.add(o)
        else:
            # Found an existing CernerPlaceholderMap object.
            o = o[0]
            if o.placeholder_lab_mnemonic != labund_mnemonic:
                # Something changed.
                # Delete the CernerNonplaceholderSynonym for the old placeholder mnemonic.
                # Tried to use sqlAlchemy to do the delete but the examples didn't work:
                # no .delete method on the table object.
                sql = 'DELETE FROM mastermu_oltg.cerner_nonplaceholder_synonyms WHERE nonplaceholder_lab_mnemonic=:mnemonic'
                self.session.execute(sql, {'mnemonic': mnemonic})
                o.placeholder_lab_mnemonic = labund_mnemonic
        # Now get the list of CernerSynonym objects for the fake LABUND mnemonic.
        o = list(self.session.query(CernerSynonym)
                 .filter(CernerSynonym.cerner_order_code == labund_code)
                 .all()
                 )
        if len(o) == 0:
            self.missing_synonyms += 1
        else:
            # Copy the synonym(s) from the fake order for this mnemonic.
            for s in o:
                old = list(self.session.query(CernerNonplaceholderSynonym)
                           .filter(CernerNonplaceholderSynonym.nonplaceholder_lab_mnemonic == mnemonic)
                           .filter(CernerNonplaceholderSynonym.placeholder_cerner_synonym_id == s.id)
                           .all())
                if len(old) == 0:
                    # Not there yet. Need to create one.
                    nps = CernerNonplaceholderSynonym()
                    nps.nonplaceholder_lab_mnemonic = mnemonic
                    nps.placeholder_cerner_synonym_id = s.id
                    nps.show = True
                    nps.ready_for_delete = False
                    self.session.add(nps)
                else:
                    # Already exists - do nothing
                    pass
        self.session.commit()
