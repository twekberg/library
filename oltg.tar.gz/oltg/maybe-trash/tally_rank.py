#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
# Determine the ranking of tests using the dept_tally_view as a source of the
# data. The data is stored in the tally_rankings table.
#
# This should be run periodically to make sure tests are ranked properly.
#
# Usage:
#   python tally_rank.py
"""

import models
from models.dept_tally_view import DeptTallyView
from models.tally_rank import TallyRank
import os
import os.path
import re
import sqlalchemy as sa
import sys
import traceback
import warnings
import math


session = models.session


def main():
    grand_total = get_sum()
    percent = 0.10
    running_total = 0
    count = 0
    session.execute('TRUNCATE tally_rankings')
    print '%10s %10s %10s %20s %10s' % ('N Tests', 'Percent', 'Mnemonic', "Mnemonic's total", 'Running total')
    for (mnemonic, total) in get_tallies():
        running_total += total
        count += 1
        if running_total > grand_total * percent:
            print '%10d %10.1f %10s %20d %10d' % (count, percent * 100, mnemonic, total, running_total)
            t = TallyRank()
            t.n_tests = count
            t.percent = percent * 100
            t.mnemonic = mnemonic
            t.mnemonics_total = total
            session.add(t)
            percent += 0.10
    t = TallyRank()
    print '%10d %10.1f %10s %20d %10d' % (count, percent * 100, mnemonic, total, running_total)
    t.n_tests = count
    t.percent = percent * 100
    t.mnemonic = mnemonic
    t.mnemonics_total = total
    session.add(t)
    session.commit()


def main_log():
    """
    Same as main() except this version does a log scale instead of a linear scale.
    """
    grand_total = get_sum()
    last_mnemonic = None
    percent_increment = 0.2
    percent = percent_increment
    running_total = 1
    count = 0
    last_count = 0
    session.execute('TRUNCATE tally_rankings')
    print '%10s %10s %10s %10s %20s %10s' % ('N Tests', 'Added tests', 'Percent', 'Mnemonic', "Mnemonic's total", 'log(Running total)')
    for (mnemonic, total) in get_tallies():
        running_total += total
        count += 1
        if math.log10(running_total) > math.log10(grand_total) * percent:
            print '%10d %10d %10.1f %10s %20d %10.7f' % (count, count-last_count, percent * 100, mnemonic, total, math.log10(running_total))
            t = TallyRank()
            t.n_tests = count
            t.percent = percent * 100
            t.mnemonic = mnemonic
            t.mnemonics_total = total
            session.add(t)
            percent += percent_increment
            last_mnemonic = mnemonic
            last_count = count
    if mnemonic != last_mnemonic:
        t = TallyRank()
        print '%10d %10d %10.1f %10s %20d %10.7f' % (count, count-last_count, percent * 100, mnemonic, total, math.log10(running_total))
        t.n_tests = count
        t.percent = percent * 100
        t.mnemonic = mnemonic
        t.mnemonics_total = total
        session.add(t)
    session.commit()


def get_sum():
    """
    Get the total number of orderable tests.
    """
    o = session.execute("""
SELECT SUM(t.total)
FROM dept_tally_view t
JOIN oltg ON oltg.mnemonic = t.mnemonic
WHERE oltg.order_flag = 'Y'""")
    x = list(o)
    if o:
        # Get the first (only) row and the first (only) element in the row.
        return float(x[0][0])
    else:
        return None


def get_tallies():
    return session.execute("""
SELECT t.*
FROM dept_tally_view t
JOIN oltg ON oltg.mnemonic = t.mnemonic
WHERE oltg.order_flag = 'Y'
ORDER BY 2""")


if __name__ == '__main__':
    #main()
    main_log()
