#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Import CPOE data from Chuck's spreadsheet.

The format will probably change in the future.

This should take about 10 seconds to execute.
"""

# Example:
#   python python/scan_fee_schedule.py ~/SANDBOX/CLAB2011_Fee.xls

import argparse
from datetime import datetime
import os
import os.path
import re
import sys
import warnings
import xlrd

import sqlalchemy.exc
from labmed.util.unicode import to_unicode

import oltg.subcommands
import oltg.models
import oltg.models.object_queries as object_queries
from oltg.models.create_models import Oltg
from oltg.models.messages import Messages
import oltg.subcommands.push_to_prod as push_to_prod


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('date_updated', action="store",
                        help='This is the date to record into the oltg for this update. Use YYYY/MM/DD format.')
    parser.add_argument('cpoe_file', action="store",
                        help='This is the file that contains the Medicare fee schedules.')


def action(args):
    """
    Scan Chuck's CPOE file. The format of this will most likely change in the future.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    messages = Messages(session, 'Load CPOE')
    try:
        object_query = object_queries.StagingObjectQueries(session)
        filename = args.cpoe_file
        ok = False
        date_updated = datetime.strptime(args.date_updated, '%Y/%m/%d')
        messages.store('started')
        try:
            count = 0
            init(filename)
            row_index = 0
            # Get the column headers
            types = sheet.row_types(row_index)
            values = sheet.row_values(row_index)
            column_headers = [None if types[i] == xlrd.XL_CELL_EMPTY else str(values[i]) for i in xrange(len(values))]
            # If the file format changed, these will probably throw a ValueError exception.
            mnemonic_index = column_headers.index('SQ Mnemonic')
            order_flag_index = column_headers.index('ORDER_CPOE_FLAG')
            cpoe_order_name_index = column_headers.index('CPOE_ORDER_NAME')

            start_data_row = 1
            
            for row_index in xrange(start_data_row,sheet.nrows):
                order_flag = sheet.cell_value(row_index, order_flag_index)
                if order_flag == 'Yes':
                    mnemonic = sheet.cell_value(row_index, mnemonic_index)
                    cpoe_order_name = sheet.cell_value(row_index, cpoe_order_name_index)
                    o = object_query.get_oltg(mnemonic)
                    if o is None:
                        raise Exception("Unable to locate oltg record for %s on spreadsheet row number %d." % (mnemonic, row_index))
                    if o.orca_name != cpoe_order_name:
                        count += 1
                        o.orca_name = to_unicode(cpoe_order_name)
                        o.orca_name_updated = date_updated
            session.commit()
            push_to_prod.push(session, engine)
            ok = True
        except Exception as e:
            # Unexpected exception.
            messages.store('Caught exception', ok, e)
        messages.store('completed. count=%d' % (count,), ok)
    finally:
        oltg.models.release_session(session, engine)
    return 0 if ok else 1               # exit status


def init(input_filename):
    global sheet

    book = xlrd.open_workbook(input_filename)
    sheet = book.sheet_by_index(0)
    # Get truncation warnings of the form:
    #   /usr/local/lib/python2.6/site-packages/SQLAlchemy-0.6.6-py2.6.egg/sqlalchemy/engine/default.py:299:
    #   Warning: Data truncated for column 'reimbursement' at row 1
    #   cursor.execute(statement, parameters)
    # This happens because the reimbursement values are stored as single precision floats, but are
    # read as double precision floats. Those reimbursement values that can not
    # be represented as a float, get truncation errors.
    # The following code will cause this warning to ignored, instead of printing to stderr.
    warnings.filterwarnings(action="ignore", message="Data truncated for column 'reimbursement'")
    warnings.filterwarnings(action="ignore", message="BaseException.message has been deprecated")
