#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Import settings the remaining non-cerner aware tests.
"""

# Example:
#   ./runoltg import_cerner_remaining filename

import os
import os.path
import random
import re

from labmed.util.boolean import to_bool
from labmed.util.unicode import to_unicode
from labmed.util.pluralize import just_pluralize
import labmed.spreadsheet_reader
from oltg.models.messages import Messages

import oltg.subcommands
import oltg.models
import oltg.models.object_queries as object_queries
from oltg.models.create_models import (Oltg,
                                       CernerNonplaceholderSynonym)


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    labmed.spreadsheet_reader.spreadsheet_parser(parser, what_file='cerner nonplaceholder synonym')


def action(args):
    """
    Scan the plasteholder map table we got from Chuck.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    messages = Messages(session, 'Load remaining')
    try:
        ok = False
        messages.store('started')
        try:
            act = labmed.spreadsheet_reader.Action(args.input_filename,
                                                   RowHandler,
                                                   row_handler_args = {'session': session,
                                                                       'only_print': False},
                                                   csv_sep=args.csv_sep)
            act.loop()
            ok = True
        except Exception as e:
            # Unexpected exception.
            messages.store('Caught exception', False, e)
        messages.store('completed. count=%d' % (act.count, ), ok)
    finally:
        oltg.models.release_session(session, engine)
    return 0 if ok else 1               # exit status


class RowHandler(labmed.spreadsheet_reader.BaseRowHandler):
    """
    Default row handler simply copies the data into the object.
    """
    def __init__(self, session, column_names, only_print):
        labmed.spreadsheet_reader.BaseRowHandler.__init__(self, session, None, column_names, only_print)

    def handle(self, row):
        lab_mnemonic = row[self.column_map['lab_mnemonic']]
        category = row[self.column_map['category']] # Chuck will pick a different column name.
        code = {'labund':285805416 ,'lab only': 0}[category]
        o = list(self.session.query(CernerOrder)
                 .filter(CernerOrder.lab_mnemonic == lab_mnemonic)
                 .all()
                 )
        if len(o) == 0:
            # Not there yet. Need to create one.
            o = CernerOrders()
            o.nonplaceholder_lab_mnemonic = nonplaceholder_lab_mnemonic
            o.placeholder_cerner_synonym_id = cerner_synonym_id
            o.show = show
            o.from_cerner_unload = False
            self.session.add(o)
        else:
            # Found an existing CernerOrders object.
            o = o[0]
            if o.placeholder_cerner_synonym_id != cerner_synonym_id or o.show != show:
                # Something changed.
                o.placeholder_cerner_synonym_id = cerner_synonym_id
                o.show = show
        o.ready_for_delete = False
        self.session.commit()
