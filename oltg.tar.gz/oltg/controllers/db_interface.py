"""
This module implements an interface to either the database and ORM
bindings, or to data previously written by json. This module provides
all data required for either rendering or serializing a record for a
lab test identified by LIS mnemonic.

No sqlalchemy objects may pass! We assume that the output of any
public function named get_* in this module a) does not require any
information about the execution environment; and b) can be directly
serialized (eg to JSON).

Note that this module should replace controllers/collectors.py (which
performs a similar function but leaks ORM objects!)
"""

from collections import defaultdict
from datetime import datetime
from itertools import izip_longest
import os.path
import json
import re
import logging
import logging.handlers
import traceback

from oltg.app import APP
import oltg.models
from oltg.models.object_queries import (get_tbp_type,
                                        get_order_flag,
                                        get_security_flag,
                                        get_foreign_column_lengths,
                                        )


def get_mnemonic_detail(mnemonic, from_database=True, json_dir=None):
    """
    Get data for `mnemonic` represented as objects that can be
    serialized to JSON format or displayed. We assume that
    de-serialized data can be used interchangably with output from
    this function.

    Nearly all logic for transforming and reformatting data should be
    implemented here or in one of the functions in this module (that
    is, as opposed to in templates).
    """

    mnemonic = mnemonic.upper()
    if from_database:
        return get_mnemonic_detail_from_db(mnemonic)
    else:
        return get_mnemonic_detail_from_json(mnemonic, json_dir)


def get_mnemonic_detail_from_json(mnemonic, json_dir):
    """
    Returns a dictionary with the detail for this mnemonic.
    """
    json_file = os.path.join(json_dir, '%s.json' % (mnemonic,))
    if os.path.exists(json_file):
        with open(json_file) as mdata:
            d =  json.load(mdata)
    else:
        # No such mnemonic.
        d = dict(error_message = '%s is not a known lab code.' % (mnemonic,))
    return d

def get_mnemonic_detail_from_db(mnemonic):
    """
    Returns a dictionary with the detail for this mnemonic.
    """
    o = oltg.models.object_query.get_oltg(mnemonic)
    if not o:
        raise KeyError('mnemonic "%s" was not found' % mnemonic)
    
    d = dict(mnemonic = unicode(mnemonic),
             entered_name      = o.name,
             department        = oltg.models.object_query.get_department(o),
             display_name      = get_display_name(oltg.models.object_query.get_name(o)),
             cautions          = get_cautions(mnemonic),
             cerner_names      = oltg.models.object_query.get_cerner_names(mnemonic),
             reference_ranges  = get_reference_ranges(mnemonic),
             xrefs             = get_cross_references(mnemonic),
             component_tests   = list(oltg.models.object_query.get_component_tests(mnemonic)),
             cpt_codes         = list(get_cpt_codes(mnemonic)),
             )
    # Get any additional attributes that need no transformation or
    # further formatting. Replace any None values with an empty
    # string.
    d.update(get_mnemonic_detail_from_object(o))

    # clean up any garbage that snuck through and convert any datetime
    # objects to tuples

    # TODO: can we get all of this garbage out of the database, ie
    # filter on input and editing?
    for k, v in d.items():        
        if is_garbage(v):
            d[k] = u''
        elif isinstance(v, datetime):
            try:
                d[k] = datetime(v.year,v.month,v.day).strftime('%m/%d/%Y')
            except Exception as e:
                raise Exception("TWE caught exception %s on '%s': %s" %
                                (str(e), k, v))
        elif isinstance(v, basestring):
            d[k] = d[k].encode('utf-8')
    return d


def get_mnemonic_detail_from_object(o):
    """
    Turn an Oltg object into a dictionary.
    Set max_lengths to the max lengths for each column that needs it.
    """
    d = {}
    d.update(dict((a, getattr(o, a) or u'') for a in o.get_column_names()))
    # These require a little processing.
    d['name']              = oltg.models.object_query.get_name(o)
    d['specimen_handling'] = get_specimen_handling(o)
    d['tbp_type']          = get_tbp_type(o.tbp_type)
    d['order_flag']        = get_order_flag(o.order_flag)
    d['security_flag']     = get_security_flag(o.security_flag)
    if not d['reference_range_effective_date']:
        d['reference_range_effective_date'] = 'Unknown'

    # Maximum length field for all varchar columns, including related tables.
    max_lengths           = dict([(name, o.get_db_type_length(name)) for name in o.get_column_names()
                                   if o.get_db_type_length(name)])
    # Get the lengths for columns in the foreign tables that are editable.
    max_lengths.update(get_foreign_column_lengths())
    d['max_lengths']       = max_lengths

    return d
    

def is_garbage(val):
    """
    Return True if 'val' is garbage (eg, '<p>&nbsp;</p>'). All non
    unicode or string objects evaluate to False.
    """

    rexp = re.compile("""
    ^&nbsp;$
    |
    ^<p>&nbsp;</p>$
    |
    ^<p><!--.+--></p>$
    """, re.X | re.I)

    return isinstance(val, basestring) and bool(rexp.search(val))

def get_display_name(name):
    """
    Substitutes some characters that Tom doesn't like
    """
    
    # TODO: don't save special_terms in the database - there's no way
    # that storing them there justifies the overhead: delete the table
    # and ORM mappings and either use a dict in this module or fix the
    # unicode encoding problems. But better yet:    
    # TODO: handle unicode appropriately and use d['name'] instead
    replacements = [(u'\\b(ColoSeq)\\b', u'\\1&trade;', 1)]

    for rexp, repl, count in replacements:
        name = re.sub(
            rexp, repl, name[:], count = count)

    return unicode(name)
        
def get_cautions(mnemonic):
    """
    Convert the object into a list with just the URL and href
    """

    # TODO: use unicode
    return [(str(c.address), str(c.label)) for c in oltg.models.object_query.get_caution_urls(mnemonic)]

def cerner_order(mnemonic):
    pass

def get_reference_ranges(mnemonic):
    """
    Return a list of (female_ages, female_range, male_ages, male_range) tuples.

    TODO: need to test the assumption that f.age_range == m.age_range
    """

    female = oltg.models.object_query.get_reference_ranges(mnemonic, 'F').all()
    male = oltg.models.object_query.get_reference_ranges(mnemonic, 'M').all()

    return [(getattr(f, 'age_range', u'') or u'',
             getattr(f, 'reference_text', u'') or u'',
             getattr(m, 'age_range', u'') or u'',
             getattr(m, 'reference_text', u'') or u'') for f,m in izip_longest(female, male, fillvalue=None)]

def get_cross_references(mnemonic):
    """
    Convert the object to a list with just the cross references.
    """
    return [x.cross_reference for x in oltg.models.object_query.get_cross_references(mnemonic)]

def get_specimen_handling(o):
    """
    The old code looks through the specimen handling words to look for URLs.
    If it finds any, it converts them to <a href="url">url</a>.
    """

    # TODO: use unicode    
    if o.specimen_handling is None:
        return ''
    return ' '.join([('<a href="%s">%s</a>' % (w, w)) if is_url(w) else w
                     for w in o.specimen_handling.split(' ')])

def get_cpt_codes(mnemonic):
    """
    Return an iterator of tuples with elements ('cpt_code', 'medicare')
    where cpt_code is in the format u'code x times' and medicare is
    either a unicode object representing a dollar amount or u''.
    """

    # count occurrences of each code
    counts = defaultdict(int)
    for c in oltg.models.object_query.get_billing_and_cpt_codes(mnemonic):
        counts[c.cpt_code] += 1
        
    for code, count in counts.items():
        yield (
            u'%s x %s' % (code, count) if count > 1 else code,
            get_medicare_reimbursement(code)
            )


# -----------------------------------------------------------------------------
# These are used by the above collector functions.
# -----------------------------------------------------------------------------

def is_url(name):
    """Returns true if the name looks like a URL. There are other schemes but they are rarely used anymore."""
    if ':' not in name:
        return False
    scheme = name.split(':', 1)[0].lower()
    return scheme in ['http', 'https', 'file', 'ftp']


def get_medicare_reimbursement(cpt_code):
    """
    Return a string in representing a dollar amount or an empty string
    if the result from the database cannot be formatted.
    """
    fs = oltg.models.object_query.get_fee_schedule(cpt_code)    

    try:
        dollars = u'%.2f' % fs.reimbursement
    except (TypeError, AttributeError), e:
        dollars = u''

    return dollars
