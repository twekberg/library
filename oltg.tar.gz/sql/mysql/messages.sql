--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2011 University of Washington Laboratory Medicine
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Laboratory Medicine and is
--    not to be disclosed to any third party without prior express
--    written permission of University of Washington Laboratory Medicine.
--    University of Washington Laboratory Medicine, as the
--    author and owner under 17 U.S.C. Sec. 201(b) of this work made
--    for hire, claims copyright in this material as an unpublished 
--    work under 17 U.S.C. Sec.s 102 and 104(a)   
-- 
--  *********************************************************************


CREATE TABLE IF NOT EXISTS `mastermu_oltg`.`messages` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `category` varchar(20) NOT NULL,      -- General category of the message.
  `text` varchar(200) NOT NULL,         -- Supplimental text 
  `ok` boolean NOT NULL,                -- OK vs NG status.
  `created_date` datetime,
  `failure_detail` text                 -- Stack trace detailing the failure.
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Status messages go here.';
