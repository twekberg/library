--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2012 University of Washington Laboratory Medicine
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Laboratory Medicine and is
--    not to be disclosed to any third party without prior express
--    written permission of University of Washington Laboratory Medicine.
--    University of Washington Laboratory Medicine, as the
--    author and owner under 17 U.S.C. Sec. 201(b) of this work made
--    for hire, claims copyright in this material as an unpublished 
--    work under 17 U.S.C. Sec.s 102 and 104(a)   
-- 
--  *********************************************************************


INSERT INTO mastermu_oltg.special_terms (match_regex, replacement_string, count)
 VALUES(E'\\b(ColoSeq)\\b', E'\\1&trade;', 1);