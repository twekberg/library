"""
Test factory function for model classes
"""

import os
from os import path
import unittest

from datetime import datetime
import re
import sys
import traceback

import oltg.config as config
import oltg.models
from oltg.models.create_models import create_model_class
from oltg.models.create_models import CernerOrder

class TestGetModel(unittest.TestCase):
    def test01(self):
        _CernerOrder = create_model_class('cerner_orders',
                                    class_name = 'CernerOrder')

        self.assertEqual(CernerOrder.table_name,
                         _CernerOrder.table_name)

        self.assertEqual(CernerOrder.db_types,
                         _CernerOrder.db_types)

        self.assertEqual(CernerOrder.schema,
                         _CernerOrder.schema)


    def test02(self):
        """
        Make sure the to_class_name function works for the cases we care about.
        """
        self.assertEqual('CrossReferenceStaging', oltg.models.create_models.to_class_name('cross_references_staging'))
        self.assertEqual('CrossReference', oltg.models.create_models.to_class_name('cross_references'))
        # Table name that isn't plural.
        self.assertEqual('FooBarBaz', oltg.models.create_models.to_class_name('foo_bar_BAZ'))
        
if __name__ == '__main__':
    unittest.main()
