-- Create indexes on mnemonic to speed things up.

CREATE INDEX oltg_billing_and_cpt_codes_ix ON billing_and_cpt_codes(mnemonic);
CREATE INDEX oltg_caution_urls_ix ON caution_urls(mnemonic);
CREATE INDEX oltg_component_tests_ix ON component_tests(mnemonic);
CREATE INDEX oltg_cross_references_ix ON cross_references(mnemonic);
CREATE INDEX oltg_fee_schedules_ix ON fee_schedules(cpt_code);
CREATE INDEX oltg_reference_ranges_ix ON reference_ranges(mnemonic);

-- Now create the same indexes for the staging tables.
CREATE INDEX oltg_billing_and_cpt_code_staging_ix ON billing_and_cpt_codes_staging(mnemonic);
CREATE INDEX oltg_caution_urls_staging_ix ON caution_urls_staging(mnemonic);
CREATE INDEX oltg_component_tests_staging_ix ON component_tests_staging(mnemonic);
CREATE INDEX oltg_cross_references_staging_ix ON cross_references_staging(mnemonic);
CREATE INDEX oltg_reference_ranges_staging_ix ON reference_ranges_staging(mnemonic);

-- Create indexes for Cerner tables.
