#  @(#) $Id:  $  

#  *********************************************************************
# 
#    Copyright (c) 2011 University of Washington Laboratory Medicine
#    All Rights Reserved
# 
#    The information contained herein is confidential to and the
#    property of University of Washington Laboratory Medicine and is
#    not to be disclosed to any third party without prior express
#    written permission of University of Washington Laboratory Medicine.
#    University of Washington Laboratory Medicine, as the
#    author and owner under 17 U.S.C. Sec. 201(b) of this work made
#    for hire, claims copyright in this material as an unpublished 
#    work under 17 U.S.C. Sec.s 102 and 104(a)   
# 
#  *********************************************************************

"""
Check the date of the LIS Feed file to see if we have a new one.
"""

from sqlalchemy.sql import func
import oltg.models
from oltg.models.message import Message
import os.path
import datetime
from oltg.util.us_time_zone import Pacific
import oltg.subcommands.scan_lis as scan_lis
import oltg.subcommands.push_to_prod as push_to_prod

session = oltg.models.session

# Number of seconds in a day.
day_sec = 86400

def main():
    # This query is equivilent to the SELECT statement below
    m = session.query(func.max(Message.created_date)) \
        .filter(Message.category == "LIS Feed") \
        .filter(Message.text.like('completed%')) \
        .filter(func.length(Message.text) > 19) \
        .filter(Message.ok == 1)
    if list(m) and len(list(m)) == 1:
        message_date = list(m)[0][0]
        """
        SELECT MAX(created_date)
        FROM messages
        WHERE category='LIS Feed'
         AND text LIKE 'completed%'
         AND length(text) > 19 -- count>=100
         AND ok != 0;
        """

        # Now get the ctime on the file
        feed_file = '/home/cstaff/bcDump-LABA.lis'
        feed_file_ctime = os.path.getctime(feed_file)
        delta = datetime.timedelta(int(feed_file_ctime / day_sec), feed_file_ctime - int(feed_file_ctime / day_sec) * day_sec)
        # Correct for time zone and daylight savings time.
        file_date = datetime.datetime(1970, 1, 1) + delta + Pacific.stdoffset
        file_date = file_date - Pacific.dst(file_date)

        if file_date > message_date:
            status = scan_lis.action(scan_lis.parse_arguments([feed_file]))
            if status == 0:
                push_to_prod.action(None)


if __name__ == '__main__':
    main()
