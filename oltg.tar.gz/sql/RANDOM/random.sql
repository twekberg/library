-- Look for packages that have components that are batteries.
-- Lists subcomponents that are batteries in a package.
-- Not quite what is needed.
SELECT mnemonic
FROM oltg
WHERE mnemonic IN
  (SELECT c.component_mnemonic
  FROM oltg
  JOIN component_tests c ON oltg.mnemonic=c.mnemonic
  WHERE oltg.tbp_type = 'P')
AND oltg.tbp_type='B'
LIMIT 20;

-- Invert the SELECT to look for packages
-- that have subcomponents that are batteries.
-- This shows UDRSCG as one of the packages.
SELECT distinct(o.mnemonic) AS package
FROM oltg o
JOIN component_tests c ON o.mnemonic=c.mnemonic
WHERE
 o.tbp_type='P' AND
 o.mnemonic NOT REGEXP '.*[[:digit:]].*' AND
 c.suppressed != 'Y' AND
 c.component_mnemonic IN
  (SELECT g.mnemonic
  FROM oltg g
  JOIN component_tests ct ON g.mnemonic=ct.mnemonic
  WHERE g.tbp_type = 'B' AND ct.suppressed != 'Y');

SELECT count(distinct(o.mnemonic))
FROM oltg o
JOIN component_tests c ON o.mnemonic=c.mnemonic
WHERE
 o.tbp_type='P' AND
 c.component_mnemonic IN
  (SELECT g.mnemonic
  FROM oltg g
  JOIN component_tests c ON g.mnemonic=c.mnemonic
  WHERE g.tbp_type = 'B');

-- Look for components and their components
SELECT 'comp' AS component_type, mnemonic,component_mnemonic FROM component_tests WHERE mnemonic='UDRSCG' AND suppressed != 'Y'
UNION
SELECT 'subcomp' AS component_type, mnemonic,component_mnemonic FROM component_tests WHERE mnemonic IN
 (SELECT component_mnemonic FROM component_tests WHERE mnemonic='UDRSCG' AND suppressed != 'Y');
-- Took 2:15.43 with no indexes
-- Took 0:00.17 with an index
-------------------------------------------------------------------------------

-- This lists the components and subcomponents.
-- Column 1: is the component.
-- Column 2: the level, 1 for direct components, 2 for subcomponents.
-- Column 3: The third column is the shared component mnemonic. For direct
-- components it is the direct component mnemonic. For subcomponents, this is
-- the direct component's mnemonic.
-- Column 4: is the component's id. This is used to maintain the ordering of
-- the battery's components.
SELECT component_mnemonic, 1 as level, component_mnemonic as base_mnemonic, id
 FROM component_tests WHERE mnemonic='UDRSCG' AND suppressed != 'Y'
UNION
SELECT component_mnemonic, 2 as level, mnemonic as base_mnemonic, id
 FROM component_tests WHERE mnemonic IN
 (SELECT component_mnemonic FROM component_tests WHERE mnemonic='UDRSCG' AND suppressed != 'Y')
ORDER BY base_mnemonic, level, id;


SELECT component_mnemonic, 1 as level, component_mnemonic as base_mnemonic, id
 FROM component_tests WHERE mnemonic='PRO' AND suppressed != 'Y'
UNION
SELECT component_mnemonic, 2 as level, mnemonic as base_mnemonic, id
 FROM component_tests WHERE suppressed != 'Y' AND mnemonic IN
 (SELECT component_mnemonic FROM component_tests WHERE mnemonic='PRO' AND suppressed != 'Y')
ORDER BY base_mnemonic, level, id;




SELECT comp.mnemonic, oltg.mnemonic, tbp_type, comp.component_type
FROM 
(SELECT 'comp' AS component_type, mnemonic,component_mnemonic FROM component_tests WHERE mnemonic='UDRSCG'
 UNION
 SELECT 'subcomp' AS component_type, mnemonic,component_mnemonic FROM component_tests WHERE mnemonic IN
  (SELECT component_mnemonic FROM component_tests WHERE mnemonic='UDRSCG')) comp
JOIN oltg on oltg.mnemonic=comp.component_mnemonic;


SELECT 'comp' AS component_type, mnemonic,component_mnemonic FROM component_tests WHERE mnemonic='TRAUMA'
UNION
SELECT 'subcomp' AS component_type, mnemonic,component_mnemonic FROM component_tests WHERE mnemonic IN
 (SELECT component_mnemonic FROM component_tests WHERE mnemonic='TRAUMA');

SELECT comp.mnemonic, oltg.mnemonic, tbp_type, comp.component_type
FROM 
(SELECT 'comp' AS component_type, mnemonic,component_mnemonic FROM component_tests WHERE mnemonic='TOXOGM'
 UNION
 SELECT 'subcomp' AS component_type, mnemonic,component_mnemonic FROM component_tests WHERE mnemonic IN
  (SELECT component_mnemonic FROM component_tests WHERE mnemonic='TOXOGM')) comp
JOIN oltg on oltg.mnemonic=comp.component_mnemonic;

-- ------------------

SELECT * FROM billing_and_cpt_codes
WHERE mnemonic IN ('CTCD34', 'DFN', 'HAESLS', 'POCC8N', 'RS1262');

-- SELECT
-- mnemonic, count(*)
-- FROM billing_and_cpt_codes
-- WHERE cpt_code=''
-- GROUP BY mnemonic
-- HAVING count(*) > 1;

-------------------------------------------------------------------------------
cerner names

SELECT count(*)
FROM cpoe c
JOIN oltg o ON c.alias_inbound = o.mnemonic
WHERE load_date='2011-08-09'
AND c.alias_inbound != '';

SELECT COUNT(*)
FROM mastermu.orca_ecodes ec
JOIN mastermu.orca_esets es ON es.`Event Set Name` = ec.description
JOIN oltg ON ec.alias = oltg.mnemonic;

SELECT oltg.mnemonic, ec.description, oltg.lab_name
FROM mastermu.orca_ecodes ec
JOIN mastermu.orca_esets es ON es.`Event Set Name` = ec.description
JOIN oltg ON ec.alias = oltg.mnemonic
ORDER BY 1 DESC
LIMIT 40;

UPDATE mastermu.orca_ecodes ec
JOIN mastermu.orca_esets es ON es.`Event Set Name` = ec.description
JOIN oltg ON ec.alias = oltg.mnemonic
SET cerner_name=ec.description;
-------------------------------------------------------------------------------
-- Try out full text searches

SELECT oltg.mnemonic,
MATCH(oltg.mnemonic,oltg.name) AGAINST ('Sodium' IN BOOLEAN MODE) AS score
FROM oltg
LEFT OUTER JOIN cross_references c ON oltg.mnemonic = c.mnemonic
WHERE MATCH(oltg.mnemonic,oltg.name) AGAINST ('Sodium' IN BOOLEAN MODE);


-- Look for a name
SELECT oltg.mnemonic,
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total'
FROM oltg
LEFT OUTER JOIN cross_references c ON oltg.mnemonic = c.mnemonic
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
WHERE
MATCH(oltg.mnemonic, oltg.name, oltg.lab_name, oltg.cerner_name, oltg.epic_name)
AGAINST ('Sodium' IN BOOLEAN MODE)
OR
MATCH(c.cross_reference) AGAINST ('Sodium' IN BOOLEAN MODE)
LIMIT 30;
-- Had to break up the two MATCHes. Having them as one MATCH generated a result
-- set of the whole table (hence the LIMIT clause).



-- Look for the mnemonic
SELECT oltg.mnemonic,ifnull(t.total,0),
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total'
FROM oltg
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
WHERE MATCH(oltg.mnemonic) AGAINST ('+NA*' IN BOOLEAN MODE);
-------------------------------------------------------------------------------
-- Trying to figure out why duplicated appear. Used MAX and GROUP BY.
SELECT oltg.mnemonic,
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total',
  MAX(
  MATCH(oltg.mnemonic, oltg.name, oltg.lab_name, oltg.cerner_name, oltg.epic_name)
    AGAINST ('drug' IN BOOLEAN MODE) +
    MATCH( c.cross_reference) AGAINST ('drug' IN BOOLEAN MODE)) AS score
FROM oltg
LEFT OUTER JOIN cross_references c ON oltg.mnemonic = c.mnemonic
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
WHERE
MATCH(oltg.mnemonic, oltg.name, oltg.lab_name, oltg.cerner_name, oltg.epic_name)
AGAINST ('drug' IN BOOLEAN MODE)
OR
MATCH( c.cross_reference) AGAINST ('drug' IN BOOLEAN MODE)
GROUP BY oltg.mnemonic
ORDER BY total DESC, mnemonic
LIMIT 30;
-------------------------------------------------------------------------------
-- Going up the tree.
SELECT oltg.mnemonic, oltg.tbp_type,
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total',
  MATCH(oltg.mnemonic) AGAINST (concat('+', 'NA', '*') IN BOOLEAN MODE) as 'score'
FROM oltg
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
WHERE MATCH(oltg.mnemonic) AGAINST (concat('+', 'NA', '*') IN BOOLEAN MODE)
ORDER BY total DESC, mnemonic;

SELECT oltg.mnemonic,
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total',
  '' as level,
  MATCH(oltg.mnemonic) AGAINST (concat('+', 'NA', '*') IN BOOLEAN MODE) as 'score'
FROM oltg
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
WHERE MATCH(oltg.mnemonic) AGAINST (concat('+', 'NA', '*') IN BOOLEAN MODE)
UNION
-- No need to say 'UNION DISTINCT' since mnemonics from level 0 != mnemonics from level 1
-- Go up one level. Get T -> B and T -> P.
SELECT oltg.mnemonic,
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total',
  'P' as level,
  0.0 as 'score'
FROM oltg
JOIN component_tests c ON oltg.mnemonic = c.mnemonic
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
WHERE c.component_mnemonic IN 
  (SELECT o2.mnemonic
   FROM oltg o2
   WHERE MATCH(o2.mnemonic) AGAINST (concat('+', 'NA', '*') IN BOOLEAN MODE)
  )
UNION DISTINCT
-- Going from parent batteries to grandparent packages: T -> B -> P
SELECT oltg.mnemonic,
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total',
  'GP' as level,
  0.0 as 'score'
FROM oltg
JOIN component_tests c ON oltg.mnemonic = c.mnemonic
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
WHERE c.component_mnemonic IN 
  (SELECT distinct(oltg.mnemonic)
   FROM component_tests c
   JOIN oltg ON oltg.mnemonic = c.mnemonic
   WHERE c.component_mnemonic IN 
     (SELECT o2.mnemonic
      FROM oltg o2
      WHERE MATCH(o2.mnemonic) AGAINST (concat('+', 'NA', '*') IN BOOLEAN MODE)
     )
     AND oltg.tbp_type = 'B'
  )
ORDER BY 4 DESC,1;

-- Just the mnemonics that match.
SELECT oltg.mnemonic
FROM oltg
WHERE MATCH(oltg.mnemonic) AGAINST (concat('+', 'NA', '*') IN BOOLEAN MODE)
ORDER BY mnemonic;

--
SELECT oltg.mnemonic
FROM oltg
WHERE MATCH(oltg.mnemonic) AGAINST (concat('+', 'NA', '*') IN BOOLEAN MODE)
AND oltg.tbp_type = 'B'
ORDER BY mnemonic;

-- up one level
SELECT distinct(oltg.mnemonic),
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total',
  oltg.tbp_type,
  0.0 as 'score'
FROM component_tests c
JOIN oltg ON oltg.mnemonic = c.mnemonic
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
WHERE c.component_mnemonic IN 
  (SELECT o2.mnemonic
   FROM oltg o2
   WHERE MATCH(o2.mnemonic) AGAINST (concat('+', 'NA', '*') IN BOOLEAN MODE)
  )
ORDER BY oltg.tbp_type, oltg.mnemonic;

-- component mnemonics to check for at level 2
SELECT distinct(oltg.mnemonic)
FROM component_tests c
JOIN oltg ON oltg.mnemonic = c.mnemonic
WHERE c.component_mnemonic IN 
  (SELECT o2.mnemonic
   FROM oltg o2
   WHERE MATCH(o2.mnemonic) AGAINST (concat('+', 'NA', '*') IN BOOLEAN MODE)
  )
  AND oltg.tbp_type = 'B';
-------------------------------------------------------------------------------
-------------------------------------------------------------------------------
-- Same thing for word search

SELECT oltg.mnemonic,
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total',
  MAX(
  MATCH(oltg.mnemonic, oltg.name, oltg.lab_name, oltg.cerner_name, oltg.epic_name)
    AGAINST ('sodium' IN BOOLEAN MODE) +
    MATCH( c.cross_reference) AGAINST ('sodium' IN BOOLEAN MODE)) AS score
FROM oltg
LEFT OUTER JOIN cross_references c ON oltg.mnemonic = c.mnemonic
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
WHERE
MATCH(oltg.mnemonic, oltg.name, oltg.lab_name, oltg.cerner_name, oltg.epic_name)
AGAINST ('Sodium' IN BOOLEAN MODE)
OR
MATCH( c.cross_reference) AGAINST ('Sodium' IN BOOLEAN MODE)
GROUP BY oltg.mnemonic
ORDER BY total DESC, mnemonic;

SELECT oltg.mnemonic,
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total',
  '' as level,
  MAX(
  MATCH(oltg.mnemonic, oltg.name, oltg.lab_name, oltg.cerner_name, oltg.epic_name)
    AGAINST ('sodium' IN BOOLEAN MODE) +
    MATCH( c.cross_reference) AGAINST ('sodium' IN BOOLEAN MODE)) AS score
FROM oltg
LEFT OUTER JOIN cross_references c ON oltg.mnemonic = c.mnemonic
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
  WHERE
  MATCH(oltg.mnemonic, oltg.name, oltg.lab_name, oltg.cerner_name, oltg.epic_name)
  AGAINST ('Sodium' IN BOOLEAN MODE)
  OR
  MATCH( c.cross_reference) AGAINST ('Sodium' IN BOOLEAN MODE)
GROUP BY oltg.mnemonic
UNION
-- No need to say 'UNION DISTINCT' since mnemonics from level 0 != mnemonics from level 1
-- Go up one level. Get T -> B and T -> P.
SELECT oltg.mnemonic,
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total',
  'P' as level,
  0.0 as 'score'
FROM oltg
JOIN component_tests c ON oltg.mnemonic = c.mnemonic
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
WHERE c.component_mnemonic IN 
  (SELECT o2.mnemonic
   FROM oltg o2
   LEFT OUTER JOIN cross_references c2 ON o2.mnemonic = c2.mnemonic
   WHERE
   MATCH(o2.mnemonic, o2.name, o2.lab_name, o2.cerner_name, o2.epic_name)
   AGAINST ('Sodium' IN BOOLEAN MODE)
   OR
   MATCH( c2.cross_reference) AGAINST ('Sodium' IN BOOLEAN MODE)
  )
UNION DISTINCT
-- Going from parent batteries to grandparent packages: T -> B -> P
SELECT oltg.mnemonic,
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total',
  'GP' as level,
  0.0 as 'score'
FROM oltg
JOIN component_tests c ON oltg.mnemonic = c.mnemonic
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
WHERE c.component_mnemonic IN
  (SELECT distinct(o2.mnemonic)
   FROM component_tests c
   JOIN oltg o2 ON o2.mnemonic = c.mnemonic
   WHERE c.component_mnemonic IN 
     (SELECT o3.mnemonic
      FROM oltg o3
      LEFT OUTER JOIN cross_references c ON o3.mnemonic = c.mnemonic
      WHERE
      MATCH(o3.mnemonic, o3.name, o3.lab_name, o3.cerner_name, o3.epic_name)
      AGAINST ('Sodium' IN BOOLEAN MODE)
      OR
      MATCH( c.cross_reference) AGAINST ('Sodium' IN BOOLEAN MODE)
     )
     AND o2.tbp_type = 'B'
  )
ORDER BY 4 DESC,1;
-------------------------------------------------------------------------------
SELECT t.*
FROM dept_tally_view t
JOIN oltg ON oltg.mnemonic = t.mnemonic
WHERE oltg.order_flag = 'Y'
ORDER BY 2 DESC LIMIT 40;

SELECT SUM(t.total)
FROM dept_tally_view t
JOIN oltg ON oltg.mnemonic = t.mnemonic
WHERE oltg.order_flag = 'Y';
-------------------------------------------------------------------------------
-- first level for 'Sodium'
SELECT * FROM component_tests WHERE 
component_mnemonic IN 
('672', 'CNA', 'CNUNA', 'FNA', 'FNAG', 'FNASD', 'L00310', 'L00318', 'L00528',
'MNA', 'MNAG', 'MNAPU', 'MNAPW', 'MNASD', 'NA', 'NAK', 'NAPT', 'NAPU', 'SLYT',
'SNA', 'UNA', 'UNAK', 'WNA', 'WNAK', 'WNAX')
ORDER BY component_mnemonic;
-------------------------------------------------------------------------------
What are the parent tests?
+----------+----------+
| mnemonic | Parent   |
+----------+----------+
| CNA      | CLYT     |
| FNA      | FVITRC   | FDIAL    | FLYT     | FNAG     |
| FNASD    | FNAG     |
| MNA      | MNAG     | MLYT     |
| MNAPU    | ASHP1    |
| MNAPW    | ASHP1    |
| MNASD    | MNAG     |
| NA       | COMP     | RENFHF   | MCA93    | NAK      | LYT      |
             COMPHF   | BMPICR   | BMP      | RENFP    | RS1051   |
             RS1068   | RS1072   | RS1180   | RS809    | RS933    |
             SCOMP    | VE29     |
| NAK      | RS1155   |
| NAPT     | ULYT     | UNA      | UNAK     |
| NAPU     | UNAK     | UNA      | ULYT     |
| SNA      | SLYT     |
| UNA      | USTON1   |
| WNA      | ACCODE   | ACODE    | ACODE2   | AG1      | AG2      |
             AG3      | AG8      | AGC1     | AGC2     | AGC3     |
             AGC8     | AP1COD   | AP8COD   | APCODE   | ERVG2    |
             NAG1     | NAG2     | NAG3     | NAG8     | NAGC1    |
             NAGC2    | NAGC3    | NAGC8    | NVG1     | NVG2     |
             NVG3     | NVG8     | NVGC1    | NVGC2    | NVGC3    |
             NVGC8    | OAG1     | OAGC9    | OVG1     | OVGC9    |
             VCCODE   | VCODE    | VCODE2   | VG1      | VG2      |
             VG3      | VG8      | VGC1     | VGC2     | VGC3     |
             VGC8     | VP1COD   | VP8COD   | VPCODE   | WNAK     |
-------------------------------------------------------------------------------
-- Now for the grandparents
SELECT distinct(c.mnemonic)
FROM component_tests c
JOIN oltg ON oltg.mnemonic = c.mnemonic
WHERE component_mnemonic IN 
('672', 'CNA', 'CNUNA', 'FNA', 'FNAG', 'FNASD', 'L00310', 'L00318', 'L00528',
'MNA', 'MNAG', 'MNAPU', 'MNAPW', 'MNASD', 'NA', 'NAK', 'NAPT', 'NAPU', 'SLYT',
'SNA', 'UNA', 'UNAK', 'WNA', 'WNAK', 'WNAX')
AND tbp_type = 'B'
ORDER BY 1;
-------------------------------------------------------------------------------
SELECT component_mnemonic,mnemonic FROM component_tests WHERE 
component_mnemonic IN 
('ACCODE', 'AG1', 'AG2', 'AG3', 'AG8', 'AGC1', 'AGC2', 'AGC3', 'AGC8',
'AP1COD', 'AP8COD', 'APCODE', 'ASHP1', 'BMP', 'BMPICR', 'CLYT', 'COMP',
'COMPHF', 'ERVG2', 'FDIAL', 'FLYT', 'FNAG', 'FVITRC', 'LYT', 'MCA93', 'MLYT',
'MNAG', 'NAG1', 'NAG2', 'NAG3', 'NAG8', 'NAGC1', 'NAGC2', 'NAGC3', 'NAGC8',
'NAK', 'NVG1', 'NVG2', 'NVG3', 'NVG8', 'NVGC1', 'NVGC2', 'NVGC3', 'NVGC8',
'OAG1', 'OAGC9', 'OVG1', 'OVGC9', 'RENFHF', 'RENFP', 'RS809', 'SCOMP', 'SLYT',
'ULYT', 'UNA', 'UNAK', 'VCCODE', 'VG1', 'VG2', 'VG3', 'VG8', 'VGC1', 'VGC2',
'VGC3', 'VGC8', 'VP1COD', 'VP8COD', 'VPCODE', 'WNAK')
ORDER BY component_mnemonic, mnemonic;
-------------------------------------------------------------------------------
-- What are the grandparents?
+--------+----------+
| parent | GP |
+--------+----------+
| BMP    | CNBMP    | CR100    | CR1025   | CR1026   | CR5001   |
           CR5071   | CR509    | CR5142   | CR5143   | CR5163   |
           CR5164   | CR5191   | CR5201   | CR5202   | CR5217   |
           CR522    | CR5229   | CR5235   | CR525    | CR5275   |
           CR5280   | CR5286   | CR5293   | CR542    | CR577    |
           CR593    | HPOC1    | IPOM     | KBP1     | KEXP1    |
           KPRS     | LUPOB    | LVLTF1   | LVLTF2   | LVOPD1   |
           LVOPP1   | LVPOM    | LVPRS    | LVPRS1   | PBP1     |
           PEXP1    | PRIMB    | ROMI     | RS1037   | RS1067   |
           RS1200   | RS1210   | RS990    | TR4EHP   | TRAUM4   |
           TRAUM5   | TRAUMP   |
| COMP   | CR384    | HLPRS    | HPOB1    | HPOB2    | IPO      |
           IPRE     | KLTF     | KPRE     | LUPOX    | LUWEX2   |
           LUWEX3   | LUWEX4   | LUWEX5   | LVLTF    | LVOPD    |
           LVOPP    | LVPO6    | PEP      | PPRE1    | RS1046   |
           RS1047   | RS1053   | RS1057   | RS1060   | RS1087   |
           RS1134   | RS1136   | RS1170   | RS1176   | RS1177   |
           RS1198   | RS1230   | RS1287   | RS1407   | RS920    |
| COMPHF | RS1199   | RS1212   | RS1256   |
| FDIAL  | FDIALP   |
| FVITRC | FVITRP   |
| LYT    | ITPNP    | RS1033   | RS1034   | RS1035   | RS1055   |
| MCA93  | PRIMC    |
| NAK    | RS1155   |
| RENFHF | CR1066   | SRFHF    |
| RENFP  | SRFM     |
| RS809  | CRSX1    |
| UNA    | USTON1   |
+--------+----------+
104 rows in set (0.02 sec)
All verified. The real query for 'Sodium' is in word.sql since it got too long.
-------------------------------------------------------------------------------
-- sendout stuff here
-- Which one have billing code starting with 10584 (chemistry), or 10585 (micro)
SELECT COUNT(*)
FROM billing_and_cpt_codes
WHERE billing_code LIKE '10584%' OR billing_code LIKE '10585%';
-- 993

-- Of those tests, how many have a department full name that contains the word sendout.
SELECT COUNT(*)
FROM billing_and_cpt_codes b
JOIN oltg ON oltg.mnemonic = b.mnemonic
WHERE
 (billing_code LIKE '10584%' OR billing_code LIKE '10585%')
 AND UPPER(dept_full_name) LIKE '%SENDOUT%';
-- 836

-- Of those tests, how many have a department full name that don't contain the word sendout.
SELECT COUNT(*)
FROM billing_and_cpt_codes b
JOIN oltg ON oltg.mnemonic = b.mnemonic
WHERE
 (billing_code LIKE '10584%' OR billing_code LIKE '10585%')
 AND UPPER(dept_full_name) NOT LIKE '%SENDOUT%';
-- 157

SELECT oltg.mnemonic,dept_full_name
FROM billing_and_cpt_codes b
JOIN oltg ON oltg.mnemonic = b.mnemonic
WHERE
 (billing_code LIKE '10584%' OR billing_code LIKE '10585%')
 AND UPPER(dept_full_name) NOT LIKE '%SENDOUT%';
-- lots of OLD in the department full name!?

-- Now how many SENDOUT departments don't have a matching billing code
SELECT COUNT(*)
FROM billing_and_cpt_codes b
JOIN oltg ON oltg.mnemonic = b.mnemonic
WHERE
 (billing_code NOT LIKE '10584%' AND billing_code NOT LIKE '10585%')
 AND UPPER(dept_full_name) LIKE '%SENDOUT%';
-- 199

-- list them out
SELECT oltg.mnemonic,dept_full_name, b.billing_code
FROM billing_and_cpt_codes b
JOIN oltg ON oltg.mnemonic = b.mnemonic
WHERE
 (billing_code NOT LIKE '10584%' AND billing_code NOT LIKE '10585%')
 AND UPPER(dept_full_name) LIKE '%SENDOUT%';

-- Determine counts for tests that contain SENDOUT and their 5 digit cost centers.
SELECT substr(billing_code, 1, 5) as 'Billing code first 5', count(*) as 'Count'
FROM billing_and_cpt_codes b
JOIN oltg ON oltg.mnemonic = b.mnemonic
WHERE
 (billing_code NOT LIKE '10584%' AND billing_code NOT LIKE '10585%')
 AND UPPER(dept_full_name) LIKE '%SENDOUT%'
group by substr(billing_code, 1, 5);

SELECT oltg.mnemonic, billing_code, dept_full_name
FROM billing_and_cpt_codes b
JOIN oltg ON oltg.mnemonic = b.mnemonic
WHERE
 (billing_code NOT LIKE '10584%' AND billing_code NOT LIKE '10585%')
 AND UPPER(dept_full_name) LIKE '%SENDOUT%'
 AND substr(billing_code, 1, 5) IN ('10651', '10653');

-------------------------------------------------------------------------------
-- Query for Chuck on 9/13/2011
SELECT
  sum(a.`UWMC`) AS 'UWMC Inpatient tally',
  sum(a.`HMC`) AS 'HMC Inpatient tally',
  sum(a.`UWMC`) + sum(a.`HMC`) AS 'Total Inpatient tally',
  a.`Sunquest mnemonic`,
  a.`Sunquest primary name`,
  a.`Sunquest department code`,
  a.`Sunquest Test/Battery/Pkg flag`
 INTO OUTFILE '/tmp/chuck-2011-09-13.csv'
  FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
  LINES TERMINATED BY '\n'
FROM
  ( 
    SELECT
      sum(`Inpt`) AS 'UWMC',
      0 AS 'HMC',
      0 AS 'Total',
      proc_code AS 'Sunquest mnemonic',
      proc_name AS 'Sunquest primary name',
      dptcode AS 'Sunquest department code',
      proc_type AS 'Sunquest Test/Battery/Pkg flag'
    FROM tbp
    LEFT OUTER JOIN dept_tallies t ON t.`Proc Code` = tbp.proc_code
    WHERE medical_center='u'
      AND tally_date >= '2011-01-01'
      AND tally_date <= '2011-08-01'
      AND tbp.orderable = 'Y'
    GROUP BY proc_code
    UNION
    SELECT
      0 AS 'UWMC',
      sum(`Inpt`) AS 'HMC',
      0 AS 'Total',
      proc_code AS 'Sunquest mnemonic',
      proc_name AS 'Sunquest primary name',
      dptcode AS 'Sunquest department code',
      proc_type AS 'Sunquest Test/Battery/Pkg flag'
    FROM tbp
    LEFT OUTER JOIN dept_tallies t ON t.`Proc Code` = tbp.proc_code
    WHERE medical_center='h'
      AND tally_date >= '2011-01-01'
      AND tally_date <= '2011-08-01'
      AND tbp.orderable = 'Y'
    GROUP BY proc_code
  ) AS a
GROUP BY `Sunquest mnemonic`;
-------------------------------------------------------------------------------
-- Tally query for Noah
SELECT oltg.mnemonic, lab_name, total
FROM mastermu_oltg.oltg
JOIN mastermu_oltg.dept_tally_view t ON oltg.mnemonic = t.mnemonic
WHERE (oltg.order_flag = 'Y' OR oltg.order_flag IS NULL)
ORDER BY 3 DESC
LIMIT 10;
-------------------------------------------------------------------------------
-- How many numeric mnemonics are sendouts.
SELECT count(*) FROM oltg WHERE mnemonic REGEXP '^[[:digit:]]*$';
-- 467
SELECT count(*) FROM oltg WHERE mnemonic REGEXP '^[[:digit:]]*$'
AND (oltg.done_uwmc='SO' AND oltg.done_hmc='SO');
-- 394
SELECT count(*)
FROM oltg
LEFT OUTER JOIN billing_and_cpt_codes b ON oltg.mnemonic = b.mnemonic
WHERE oltg.mnemonic REGEXP '^[[:digit:]]*$'
AND ((oltg.done_uwmc='SO' AND oltg.done_hmc='SO') OR
     substr(b.billing_code, 1, 5) IN ('10584','10585'));
-- 394
SELECT count(*)
FROM oltg
LEFT OUTER JOIN billing_and_cpt_codes b ON oltg.mnemonic = b.mnemonic
WHERE oltg.mnemonic REGEXP '^[[:digit:]]*$'
AND ((oltg.done_uwmc!='SO' OR oltg.done_hmc!='SO') OR
     substr(b.billing_code, 1, 5) NOT IN ('10584','10585'));
-- 73 don't fit the pattern.
SELECT oltg.mnemonic, oltg.done_uwmc, oltg.done_hmc
FROM oltg
LEFT OUTER JOIN billing_and_cpt_codes b ON oltg.mnemonic = b.mnemonic
WHERE oltg.mnemonic REGEXP '^[[:digit:]]*$'
AND ((oltg.done_uwmc!='SO' OR oltg.done_hmc!='SO') OR
     substr(b.billing_code, 1, 5) NOT IN ('10584','10585'));
