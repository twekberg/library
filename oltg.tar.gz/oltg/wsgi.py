#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2012 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Code used by the WSGI application function.

The top-level function is 'application', following the WSGI convention.

Note that this file is used by 3 other files:
  oltg.wsgi - the main file used for public access
  oltgs.wsgi - the staff-only version
  oltge.wsgi - the version that allows one to edit the content.
"""


import re
import os
import logging
import logging.handlers
from paste import request
import traceback

from oltg.app import APP
import oltg.config as config
from oltg.controllers.display import display_page
from oltg.controllers.search import search_page
from oltg.controllers.ref_ranges import ref_ranges_page
from oltg.controllers.edit import edit
from oltg.controllers.edit_workflow import edit_workflow
from oltg.controllers.create import create
from oltg.controllers.dept_print import dept_print
from oltg.templates.PageNotFound import PageNotFound
import oltg.models
import oltg.models.object_queries as object_queries


logger = None
## May want to put this in a config file.
log_filename = '/var/tmp/%s.log' % (APP,)

# Map URLs to functions.
base_urls = [
    (r'^$', search_page),
    (r'^display$', display_page),
    (r'refranges$', ref_ranges_page),
    ]
staff_only_urls = [
    (r'^dept_print$', dept_print),
    ]
edit_urls = [
    (r'^edit$', edit),
    (r'^edit_workflow$', edit_workflow),
    (r'^create$', create),
    ]

def application(environ, start_response, staff_only=False, edit_mode=False):
    """
    The main WSGI application. Dispatch the current request to the controller functions
    from above. Form parameters are stored in environ as `oltg.url_args

    If nothing matches call the `not_found` function.
    """
    ## GET and POST parameters in a MultiDict.
    environ['oltg.parameters'] = request.parse_formvars(environ, include_get_vars=True)
    path = environ.get('PATH_INFO', '').lstrip('/')

    script_name = environ.get('SCRIPT_NAME', '').lstrip('/') # oltg, oltgs or oltge
    config_dict = config.read('/home/mastermu/%s/config/oltg.cfg' % (APP,))
    (session, engine) = oltg.models.setup_db_session(config_dict)
    environ['SESSION'] = session
    environ['ENGINE'] = engine
    environ['CONFIG'] = config_dict
    read_mnemonics_from_database = config_dict['read_mnemonics_from_database']
    environ['STAFF_ONLY'] = staff_only or edit_mode
    if read_mnemonics_from_database == 'True' or edit_mode:
        if edit_mode:
            # In edit mode, we need to use the staging tables.
            oltg.models.object_query = object_queries.StagingObjectQueries(session, config_dict['db_type'])
        else:
            # Not in edit mode, we need to use the production tables.
            oltg.models.object_query = object_queries.ProdObjectQueries(session, config_dict['db_type'])
    environ['EDIT_MODE'] = edit_mode

    try:
        # Allow URLs based on the mode.
        urls = base_urls                # Everyone has these
        if staff_only:
            urls += staff_only_urls
        if edit_mode:
            urls += edit_urls
        for regex, callback in urls:
            match = re.search(regex, path)
            if match is not None:
                return callback(environ, start_response, logger)
        return not_found(environ, start_response, path)
    except Exception as e:
        tb = '%s: %s\n%s' % (str(type(e)), e, traceback.format_exc())
        logger.error('TWE caught error %s' % (tb,))
    finally:
        ## We are done with the session. Close it.
        oltg.models.release_session(session, engine)
            

def not_found(environ, start_response, got):
    """Called if no URL matches."""
    start_response('200 OK', [('Content-Type', 'text/html')])
    #TWEstart_response('404 NOT FOUND', [('Content-Type', 'text/html')])
    namespace = dict(got = got,
                     expected = [url[0] for url in base_urls],
                     advanced_actions = False,
                     alternate_web_host = '',
                     background_color = 'default',
                     edit_mode = False,
                     search_type = '',
                     search_text = '',
                     search_as_component = 'False',
                     search_cross_reference = 'False',
                     show_staff_detail = False,
                     page_sub_title = '',
                     page_mode = '- Not found',
                     static_content_home =   '/mastermu/oltg/', # location of static content (css,js)
                     home_page = environ.get('SCRIPT_NAME', '').rstrip('/') or None,
                     version = oltg.__version__,
                     )
    t = PageNotFound(searchList = [namespace])
    return [str(t.respond())]


def initialize_logger():
    """
    Set up the logger.
    """
    global logger

    logger = logging.getLogger(APP)
    handler = logging.handlers.RotatingFileHandler(
        log_filename, maxBytes=1000000, backupCount=5)
    formatter = logging.Formatter(fmt='%(asctime)s %(levelname)s %(module)s@%(lineno)d:%(funcName)s %(message)s')
    handler.setLevel(logging.DEBUG)         # This doesn't seem to work
    handler.setFormatter(formatter)
    logger.addHandler(handler)
    ## Have to do this to get debug and info messages to display.
    ## warning and above seem to work fine.
    logger.setLevel(logging.DEBUG)


initialize_logger()


if __name__ == '__main__':
    d = os.environ.copy()
    d['wsgi.input'] = None
    print '\n'.join(application(d, lambda a, b: None, True, False))
