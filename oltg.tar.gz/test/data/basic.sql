INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('ACID', 'U', 'twe_lab');

INSERT INTO billing_and_cpt_codes_staging (mnemonic, cpt_code, billing_code)
  VALUES('ACID', '84066', '');
INSERT INTO billing_and_cpt_codes_staging (mnemonic, cpt_code, billing_code)
  VALUES('ACID', '', '');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('ACX', 'U', 'twe_lab');

INSERT INTO billing_and_cpt_codes_staging (mnemonic, cpt_code, billing_code)
  VALUES('ACX', '85018', '');
INSERT INTO billing_and_cpt_codes_staging (mnemonic, cpt_code, billing_code)
  VALUES('ACX', '82810', '');
INSERT INTO billing_and_cpt_codes_staging (mnemonic, cpt_code, billing_code)
  VALUES('ACX', '83050', '');
INSERT INTO billing_and_cpt_codes_staging (mnemonic, cpt_code, billing_code)
  VALUES('ACX', '82375', '');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('ACHE', 'U', 'twe_lab');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('ACENBG', 'U', 'twe_lab');

INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACENBG', 'BCENB1', 'Y');
INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACENBG', 'ACENTB', 'N');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('ACODE', 'U', 'twe_lab');

INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACODE', 'ACX', '');
INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACODE', 'ABGC', '');
INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACODE', 'WHCT', '');
INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACODE', 'WNA', '');
INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACODE', 'WK', '');
INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACODE', 'WGLU', '');
INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACODE', 'WIC', '');
INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACODE', 'WALAC', '');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('ACUTRP', 'U', 'twe_lab');

INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACUTRP', 'GBM', 'N');
INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACUTRP', 'ANCAM', 'N');
INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACUTRP', 'ANCAC', 'N');
INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACUTRP', 'DNAQL', 'N');
INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACUTRP', 'ANCAIF', 'N');
INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACUTRP', 'DNAEL', 'N');
INSERT INTO component_tests_staging(mnemonic, component_mnemonic, suppressed)
  VALUES('ACUTRP', 'DNAHS', 'N');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('BALC', 'U', 'twe_lab');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('AFBSEQ', 'U', 'twe_lab');

INSERT INTO caution_urls_staging (mnemonic, address, label)
  VALUES('AFBSEQ', 'http://depts.washington.edu/molmicdx', 'Molecular diagnosis website');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('BRAF', 'U', 'twe_lab');

INSERT INTO caution_urls_staging (mnemonic, address, label)
  VALUES('BRAF', 'http://tests.labmed.washington.edu/BRAF', 'BRAF Test Information');
INSERT INTO caution_urls_staging (mnemonic, address, label)
  VALUES('BRAF', 'http://depts.washington.edu/labweb/referencelab/clinical/TestForms/genetics.pdf',
         'Genetics Requisition');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('ACCNO', 'U', 'twe_lab');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('ACCINR', 'U', 'twe_lab');

INSERT INTO cross_references_staging (mnemonic, cross_reference)
  VALUES('ACCINR', 'Protime INR-Alliance Lab');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('MFC', 'U', 'twe_lab');

INSERT INTO cross_references_staging (mnemonic, cross_reference)
  VALUES('MFC', 'Fungal MIC');
INSERT INTO cross_references_staging (mnemonic, cross_reference)
  VALUES('MFC', 'MIC -Fungal');
INSERT INTO cross_references_staging (mnemonic, cross_reference)
  VALUES('MFC', 'Antifungal MIC');
INSERT INTO cross_references_staging (mnemonic, cross_reference)
  VALUES('MFC', 'Fungicidal Concentration');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('BUFW', 'U', 'twe_lab');

INSERT INTO cross_references_staging (mnemonic, cross_reference)
  VALUES('BUFW', 'Buffy Coat Wright Stain');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('RANN1', 'U', 'twe_lab');

INSERT INTO cross_references_staging (mnemonic, cross_reference)
  VALUES('RANN1', 'Anti HU');
INSERT INTO cross_references_staging (mnemonic, cross_reference)
  VALUES('RANN1', 'ANNA-1');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('ABPATH', 'U', 'twe_lab');

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('ADR', 'U', 'twe_lab');

INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('ADR', 'F', '0-', 'NRN', 'Negative', '', '', 1);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('ADR', 'M', '0-', 'NRN', 'Negative', '', '', 1);

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('RALKT', 'U', 'twe_lab');

INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '0-3y', 'NDEF', 'Not Defined', '', '', 1);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '4-4y',    '', '169-372', '', '', 2);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '5-5y',    '', '162-355', '', '', 3);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '6-6y',    '', '169-370', '', '', 4);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '7-7y',    '', '183-402', '', '', 5);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '8-8y',    '', '199-440', '', '', 6);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '9-9y',    '', '212-468', '', '', 7);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '10-10y',  '', '215-476', '', '', 8);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '11-11y',  '', '178-526', '', '', 9);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '12-12y',  '', '133-485', '', '', 10);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '13-13y',  '', '120-449', '', '', 11);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '14-14y',  '', '153-362', '', '', 12);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '15-15y',  '', '75-274',  '', '', 13);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '16-16y',  '', '61-264',  '', '', 14);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '17-23y',  '', '52-144',  '', '', 15);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '24-45y',  '', '37-98' ,  '', '', 16);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '46-50y',  '', '39-100',  '', '', 17);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '51-55y',  '', '41-108',  '', '', 18);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '56-60y',  '', '46-118',  '', '', 19);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '61-65y',  '', '50-130',  '', '', 20);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '66-150y', '', '55-142',  '', '', 21);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'F', '151y-',   'NEST', 'Not Established', '', '', 22);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '0-3y',    'NDEF', 'Not Defined', '', '', 1);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '4-4y',    '', '149-369', '', '', 2);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '5-5y',    '', '179-416', '', '', 3);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '6-6y',    '', '179-417', '', '', 4);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '7-7y',    '', '172-405', '', '', 5);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '8-8y',    '', '169-401', '', '', 6);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '9-9y',    '', '175-411', '', '', 7);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '10-10y',  '', '191-435', '', '', 8);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '11-11y',  '', '185-507', '', '', 9);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '12-12y',  '', '185-562', '', '', 10);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '13-13y',  '', '182-587', '', '', 11);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '14-14y',  '', '166-571', '', '', 12);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '15-15y',  '', '138-511', '', '', 13);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '16-16y',  '', '102-417', '', '', 14);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '17-17y',  '', '69-311',  '', '', 15);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '18-18y',  '', '52-222',  '', '', 16);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '19-150y', '', '45-115',  '', '', 17);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('RALKT', 'M', '151y-',   'NEST', 'Not Established', '', '', 18);

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('HIPA', 'U', 'twe_lab');

INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('HIPA', 'F', '0-',   'NRN', 'Negative', '', 'POS,STRNP', 1);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('HIPA', 'M', '0-',   'NRN', 'Negative', '', 'POS,STRNP', 1);

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, lab_name) VALUES('AMHB', 'U', 'twe_lab');

INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('AMHB', 'F', '0-', '', '<3.0', '', '0.0-30.0', 1);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('AMHB', 'M', '0-',  '', '<3.0', '', '0.0-30.0', 1);

-- -----------------------------------------------------------------------------

INSERT INTO oltg_staging (mnemonic, hospital, tbp_type, lab_name, dept_code, dept_full_name, unit,
       order_flag, suppress_print_flag, name, specimen_type, reference_range_addendum, collection,
       amount, minimum_amount, specimen_handling,
       done_uwmc, done_hmc, done_other, frequency, processing_instructions,
       method, available_stat, updated_date, security_flag,
       reference_range_effective_date, reference_range_units)
  VALUES('NA', 'U', 'T', 'Sodium', 'CHA', 'Chemistry, Automated Panels', 'mEq/L',
       'Y', 'N', 'Sodium', 'Blood', '', '3 mL blood in a LIME GREEN PST, GOLD SST, RED TOP or GREEN TOP tube<br/><strong>Pediatric draw:</strong> 1 full LIME GREEN, GOLD or RED MICROTAINER',
       '0.5 mL plasma/serum', '0.1 mL plasma/serum', '<P><!-- Generated by XStandard version 1.3.0.0 on 2004-09-02T15:49:34 --></P>',
       'Automated Chemistry', 'Stat Laboratory', 'Roosevelt', 'Daily', 'Refrigerate plasma/serum',
       'Ion Selective Electrode (ISE)', 'Yes', datetime('2011-02-09 00:00:00'), 'E',
       datetime('1999-03-11 00:00:00'), 'mEq/L');

INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('NA', 'F', '0-', '', '136-145', '', '120-160', 1);
INSERT INTO reference_ranges_staging (mnemonic, sex, age_range, reference_text_code, reference_text,
       verify_text_code, verify_text, ordering)
  VALUES('NA', 'M', '0-', '', '136-145', '', '120-160', 1);
INSERT INTO billing_and_cpt_codes_staging (mnemonic, cpt_code, billing_code)
  VALUES('NA', '84295', '1040103000207');
