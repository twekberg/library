--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2011 University of Washington Laboratory Medicine
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Laboratory Medicine and is
--    not to be disclosed to any third party without prior express
--    written permission of University of Washington Laboratory Medicine.
--    University of Washington Laboratory Medicine, as the
--    author and owner under 17 U.S.C. Sec. 201(b) of this work made
--    for hire, claims copyright in this material as an unpublished 
--    work under 17 U.S.C. Sec.s 102 and 104(a)   
-- 
--  *********************************************************************


-- This is a table used to record status messages mostly for database uploading tasks.
-- Recorded are start/stop messages, and errors with stack traces.

CREATE TABLE "mastermu_oltg"."messages" (
  id BIGSERIAL NOT NULL PRIMARY KEY,
  "category" varchar(20) NOT NULL,
  "text" varchar(200) NOT NULL,
  "ok" boolean NOT NULL,
  "created_date" timestamp,
  "failure_detail" text
);

COMMENT ON TABLE "mastermu_oltg"."messages" IS 'Status messages go here.';
COMMENT ON COLUMN "mastermu_oltg"."messages"."category" IS 'General category of the message.';
COMMENT ON COLUMN "mastermu_oltg"."messages"."text" IS 'Supplemental text.';
COMMENT ON COLUMN "mastermu_oltg"."messages"."ok" IS 'OK vs NG status.';
COMMENT ON COLUMN "mastermu_oltg"."messages"."failure_detail" IS 'Stack trace detailing the failure.';
