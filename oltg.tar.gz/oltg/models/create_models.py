"""
This class defines all of the model classes which may be used to access the database.
Just import this module, and the models objects will be defined.
"""

import sys

from oltg.models.BaseModel import BaseModel


def create_model_class(table_name, db_types = None, class_name = None, schema = 'mastermu_oltg'):
    """
    Factory function for generating model classes inheriting from BaseModel.

    see http://stackoverflow.com/questions/2461751/python-class-factory-using-user-input-as-class-names

    The CrossReference objects below are equivalent::

        class CrossReference(BaseModel):
            db_types= None
            schema = 'mastermu_oltg'
            table_name = 'cross_references'

        CrossReference = create_model_class('cross_references', class_name='CrossReference')
    """
    
    # the class name probably doesn't matter, but let's cook one up
    # anyway as a CamelCase version of 'table_name' unless one is
    # provided.
    name = class_name or ''.join(
        [x.title() for x in table_name.split('_')])

    # Put all of the database-specific details in the class.
    cls = type(name, (BaseModel,), {
        'db_types': db_types,
        'schema': schema,
        'table_name': table_name,
        })
    
    return cls


def to_class_name(table_name):
    """
    Convert the table name to a class name.
    The table names are plural, class name are singular.
    Some tables have a '_staging' suffix which need to be handled.
    """
    staging = table_name.endswith('_staging')
    if staging:
        table_name = table_name[:table_name.index('_staging')]
    if table_name.endswith('s'):
        table_name = table_name[:-1]
    return ''.join([t.capitalize() for t in table_name.split('_')]) + ('Staging' if staging else '')


def create_model_classes():
    this_module = sys.modules[__name__]
    table_names = [
        'audit_logs', 
        'billing_and_cpt_codes',
        'billing_and_cpt_codes_staging',
        'caution_urls',
        'caution_urls_staging',
        'cerner_nonplaceholder_synonyms',
        'cerner_orders',
        'cerner_placeholder_maps',
        'cerner_synonym_displays',
        'cerner_synonyms',
        'component_tests',
        'component_tests_staging',
        'cross_references',
        'cross_references_staging',
        'fee_schedules',
        'lis_feed',
        'lis_feed_staging',
        'messages',
        'oltg',
        'oltg_staging',
        'reference_ranges',
        'reference_ranges_staging',
        ]
    
    for table_name in table_names:
        class_name = to_class_name(table_name)
        setattr(this_module, class_name, create_model_class(table_name, class_name=class_name))
    # The old oltg table and the production oltg use the same table name.
    # They are in different schemas (or databases for MySQL).
    setattr(this_module, 'OldOltg', create_model_class('oltg', class_name='OldOltg', schema='mastermu'))


create_model_classes()
