#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
These methods are used to retrieve one or more objects from the database.
"""


from oltg.models.create_models import (OltgStaging as Oltg,
                                       ReferenceRangeStaging as ReferenceRange,
                                       BillingAndCptCodeStaging as BillingAndCptCode,
                                       ComponentTestStaging as ComponentTest,
                                       CautionUrlStaging as CautionUrl,
                                       CrossReferenceStaging as CrossReference)


def get_all_tests(session):
    return session.query(Oltg).filter(Oltg.mnemonic.like('%\_TEST'))


def get_all_oltg(session):
    return list(session.execute('SELECT mnemonic FROM oltg ORDER BY mnemonic'))


def get_oltg(session, mnemonic):
    o = list(session.query(Oltg).filter(Oltg.mnemonic == mnemonic))
    return o[0] if len(o)==1 else None


def get_billing(session, mnemonic):
    return session.query(BillingAndCptCode).filter(BillingAndCptCode.mnemonic == mnemonic)


def get_components(session, mnemonic):
    return session.query(ComponentTest).filter(ComponentTest.mnemonic == mnemonic)


def get_caution_url(session, mnemonic):
    return session.query(CautionUrl).filter(CautionUrl.mnemonic == mnemonic)


def get_xref(session, mnemonic):
    return session.query(CrossReference).filter(CrossReference.mnemonic == mnemonic)


def get_ref_range(session, mnemonic):
    return session.query(ReferenceRange).order_by(ReferenceRange.sex).order_by(ReferenceRange.ordering).filter(ReferenceRange.mnemonic == mnemonic)
