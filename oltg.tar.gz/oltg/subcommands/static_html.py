"""
Generate a static HTML page showing the mnemonics and the cerner names
that appear page for each test.
"""

import argparse
import sys

import oltg.subcommands
import oltg.models
import oltg.models.object_queries as object_queries


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('outfile', nargs='?', type=argparse.FileType('w'),
                                         default=sys.stdout)

def action(args):
    """
    Show the cerner names for a mnemonic.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    try:
        oltg.models.object_query = object_queries.ProdObjectQueries(session, d['db_type'])
        render_header(args.outfile)
        for mnemonic in get_mnemonics(session):
            render_mnemonic(mnemonic, args.outfile)
        render_trailer(args.outfile)
    finally:
        oltg.models.release_session(session, engine)


def get_mnemonics(session):
    sql = """SELECT mnemonic FROM mastermu_oltg.oltg WHERE security_flag != 'N'"""
    return sorted([x[0] for x in list(session.execute(sql))])


def render_header(out):
    title = 'Static Cerner name lookup'
    out.write("""<html>
<head>
<title>%s</title>
</head>
<body>
<h1>%s</h1>
<table
""" % (title, title))


def render_trailer(out):
    out.write("""</table>
<html>
""")


def render_mnemonic(mnemonic, out):
    """
    Render the HTML code for a single mnemonic.
    """

    names = oltg.models.object_query.get_cerner_names(mnemonic)
    if len(names) > 0:
        o = oltg.models.object_query.get_oltg(mnemonic)
        out.write("""<tr>
  <td>
    %s
  </td>
  <td>
    %s
  </td>
  <td>
    %s
  </td>
</tr>\n""" % (o.mnemonic, o.lab_name if o.lab_name else o.name, ', '.join(names)))
