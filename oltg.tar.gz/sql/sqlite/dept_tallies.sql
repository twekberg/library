--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2012 University of Washington Laboratory Medicine
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Laboratory Medicine and is
--    not to be disclosed to any third party without prior express
--    written permission of University of Washington Laboratory Medicine.
--    University of Washington Laboratory Medicine, as the
--    author and owner under 17 U.S.C. Sec. 201(b) of this work made
--    for hire, claims copyright in this material as an unpublished 
--    work under 17 U.S.C. Sec.s 102 and 104(a)   
-- 
--  *********************************************************************


CREATE TABLE IF NOT EXISTS "dept_tallies" (
  "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "Code" varchar(90) DEFAULT NULL,
  "Proc Code" varchar(22) DEFAULT NULL,
  "Procedure Name" varchar(134) DEFAULT NULL,
  "Total" int(11) DEFAULT NULL,
  "Inpt" int(11) DEFAULT NULL,
  "Outpt Total" int(11) DEFAULT NULL,
  "Outpt Roosevelt" int(11) DEFAULT NULL,
  "Outpt SCCA" int(11) DEFAULT NULL,
  "Outpt Antrim" int(11) DEFAULT NULL,
  "Outsd" int(11) DEFAULT NULL,
  "Research Testing" int(11) DEFAULT NULL,
  "LMED" int(11) DEFAULT NULL,
  "XHosp" int(11) DEFAULT NULL,
  "Credit" int(11) DEFAULT NULL,
  "Unk." int(11) DEFAULT NULL,
  "CAP/OrdCode" float DEFAULT NULL,
  "Price/OrdCode" float DEFAULT NULL,
  "tally_date" date DEFAULT NULL,
  "medical_center" varchar(20) DEFAULT NULL
);

CREATE INDEX IF NOT EXISTS "mmu_dept_tallies_proc_code" ON "dept_tallies"("Proc Code");