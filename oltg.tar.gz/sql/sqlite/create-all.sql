--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2010 University of Washington Medical Center
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Medical Center and is not to
--    be disclosed to any third party without prior express written
--    permission of University of Washington Medical Center University
--    of Washington Medical Center, as the author and owner under 17
--    U.S.C. Sec. 201(b) of this work made for hire, claims copyright
--    in this material as an unpublished work under 17 U.S.C. Sec.s 102
--    and 104(a)
-- 
--  ******************************************************************* 


-- No foreign key
.read cerner_placeholder_maps.sql
.read cerner_orders.sql

-- Foreign key on cerner_orders
.read cerner_synonyms.sql

-- Foreign key on cerner_synonyms.
.read cerner_synonym_displays.sql

-- Foreign key on cerner_placeholder_maps and cerner_synonyms.
.read cerner_nonplaceholder_synonyms.sql

.read dept_tallies.sql
.read dept_tally_view.sql
.read messages.sql

-- No foreign key
.read audit_logs.sql
.read oltg.sql
.read oltg_staging.sql
.read component_tests.sql
.read component_tests_staging.sql
.read caution_urls.sql
.read caution_urls_staging.sql
.read reference_ranges.sql
.read reference_ranges_staging.sql
.read billing_and_cpt_codes.sql
.read billing_and_cpt_codes_staging.sql
.read cross_references.sql
.read cross_references_staging.sql
.read lis_feed.sql
.read lis_feed_staging.sql

.read fee_schedules.sql

.read create-indexes.sql
