#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
These functions are used to extract data from various tables and return
(normally) a list of values used by a template.
"""


import oltg.models


def cautions(mnemonic):
    """
    Convert the object into a list with just the URL and href
    """
    return [(str(c.address), str(c.label)) for c in oltg.models.object_query.get_caution_urls(mnemonic)]


def cerner_order(mnemonic):
    pass


def component_tests(session, mnemonic, o):
    """
    Convert the non-suppressed object to the Oltg object for the component.
    """
    return [(oltg.models.object_query.get_oltg(m), level)
            for (m, level) in get_all_component_tests(session, mnemonic, o)]


def reference_ranges(mnemonic):
    return [(f.age_range if f else None, f.reference_text if f else None, f.reference_text_code if f else None,
             m.age_range if m else None, m.reference_text if m else None, m.reference_text_code if m else None)
            for (f, m) in map(None,
                              oltg.models.object_query.get_reference_ranges(mnemonic, 'F'),
                              oltg.models.object_query.get_reference_ranges(mnemonic, 'M'))]


def cross_references(mnemonic):
    """
    Convert the object to a list with just the cross references.
    """
    return [x.cross_reference for x in oltg.models.object_query.get_cross_references(mnemonic)]


def specimen_handling(o):
    """
    The old code looks through the specimen handling words to look for URLs.
    If it finds any, it converts them to <a href="url">url</a>.
    """
    return ' '.join([('<a href="%s">%s</a>' % (w, w)) if is_url(w) else w
                     for w in o.specimen_handling.split(' ')])


def cpt_codes(mnemonic):
    """
    Collect the CPT code from the billing_and_cpt_codes table, and do a
    lookup on each one to get the medicare reimbursement from the
    fee_schedules table. Returns a list of [cpt_code, how_many, reimbursement].
    """
    cpt_codes = [('',0,'')]
    for b in oltg.models.object_query.get_billing_and_cpt_codes(mnemonic):
        # Skip empties.
        if b.cpt_code:
            if b.cpt_code != cpt_codes[-1][0]:
                cpt_codes.append([b.cpt_code, 0, get_medicare_reimbursement(b.cpt_code)])
            cpt_codes[-1][1] += 1           # Bump the count
    return cpt_codes[1:]                # Remove dummy first element


# -----------------------------------------------------------------------------
# These are used by the above collector functions.
# -----------------------------------------------------------------------------

def is_url(name):
    """Returns true if the name looks like a URL. There are other schemes but they are rarely used anymore."""
    if ':' not in name:
        return False
    scheme = name.split(':', 1)[0].lower()
    return scheme in ['http', 'https', 'file', 'ftp']


def get_medicare_reimbursement(cpt_code):
    fs = oltg.models.object_query.get_fee_schedule(cpt_code)
    return fs.reimbursement if fs else 'Unknown'


def get_all_component_tests(session, mnemonic, o):
    """
    This lists the components and subcomponents that are not suppressed.
    Returns a list of (component mnemonic string, level number).
    """
    # Column 1: is the component.
    # Column 2: the level, 1 for direct components, 2 for subcomponents.
    # Column 3: The third column is the shared component mnemonic. For direct
    # components it is the direct component mnemonic. For subcomponents, this
    # is the direct component's mnemonic.
    # Column 4: is the component's id.
    # Sorting is done so the packages are ordered alphabetically, next by level
    # so that level 1s come before level 2s, finally by id so that a battery's
    # component order is maintained.

    # Batteries don't need to order anything. They come properly when there
    # is no ORDER BY clause.
    sql = """
SELECT component_mnemonic, 1 as level, component_mnemonic as base_mnemonic, id
 FROM mastermu_oltg.component_tests WHERE mnemonic=:mnemonic AND suppressed != 'Y'
UNION
SELECT component_mnemonic, 2 as level, mnemonic as base_mnemonic, id
 FROM mastermu_oltg.component_tests WHERE suppressed != 'Y' AND mnemonic IN
 (SELECT component_mnemonic FROM mastermu_oltg.component_tests WHERE mnemonic=:mnemonic AND suppressed != 'Y')
%s;
""" % (('' if o.tbp_type == 'B' else 'ORDER BY base_mnemonic, level, id'),)
    o = session.execute(sql, {'mnemonic':mnemonic})
    # All we care about is the mnemonic of the component and the level.
    return [(rs['component_mnemonic'], rs['level']) for rs in list(o)]


def get_edited_tests(session):
    """
    Get a list of the tests that have been edited for the edit_workflow controller.

    Returns a list of (mnemonic, name, changed_by).
    """
    sql = """SELECT o.mnemonic, CASE o.name WHEN '' THEN o.lab_name ELSE o.name END, a.user
 FROM mastermu_oltg.oltg_staging o
 JOIN mastermu_oltg.audit_logs a ON o.mnemonic = a.mnemonic
 WHERE was_changed
ORDER BY 1, a.updated_date DESC"""
    # Coudn't figure out a query to do this, so have the query generate a list
    # then filter it down with code.
    last_mnemonic = None
    latest = []                         # First in the list
    for (mnemonic,name,user) in list(session.execute(sql)):
        if last_mnemonic != mnemonic:
            last_mnemonic = mnemonic
            latest.append((mnemonic,name,user))
    return latest
