--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2010 University of Washington Medical Center
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Medical Center and is not to
--    be disclosed to any third party without prior express written
--    permission of University of Washington Medical Center University
--    of Washington Medical Center, as the author and owner under 17
--    U.S.C. Sec. 201(b) of this work made for hire, claims copyright
--    in this material as an unpublished work under 17 U.S.C. Sec.s 102
--    and 104(a)
-- 
--  ******************************************************************* 


\i access_logs.sql
\i audit_logs.sql
\i billing_and_cpt_codes.sql
\i billing_and_cpt_codes_staging.sql
\i caution_urls.sql
\i caution_urls_staging.sql
\i cerner_orders.sql
\i cerner_synonyms.sql
\i cerner_nonplaceholder_synonyms.sql
\i cerner_placeholder_maps.sql
\i cerner_synonym_displays.sql
\i component_tests.sql
\i component_tests_staging.sql
\i cross_references.sql
\i cross_references_staging.sql
\i dept_tally_view.sql
\i fee_schedules.sql
\i lis_feed.sql
\i lis_feed_staging.sql
\i messages.sql
\i oltg.sql
\i oltg_staging.sql
\i reference_ranges.sql
\i reference_ranges_staging.sql
\i special_terms.sql
\i tally_rankings.sql

\i create-indexes.sql
\i load_special_terms.sql
\i load_cerner_orders.sql