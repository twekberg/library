"""
Display details for a test.
"""

import re
from decimal import Decimal
from oltg.controllers.db_interface import get_mnemonic_detail
import oltg.subcommands
from oltg import config
import oltg.models
import oltg.models.object_queries as object_queries


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('-e','--edit_mode',
                        action="store_true", default=False,
                        help = 'Look at staging tables for tests that have been edited.')
    parser.add_argument('mnemonic',
                        help = 'The test to display.')


def get_special_name(o, special_terms):
    display_name = object_queries.get_name(o)
    for (match_regex, replacement_string, count) in special_terms:
        display_name = re.sub(match_regex, replacement_string, display_name, count=count)
    return display_name


def break_multiline(v):
    """
    Some of the values need to be displayed on multiple lines. This is done by
    putting 5 or more blanks to separate lines.
    In addition, lines that contain a bullet should start on a new line.
    """
    if v:
        return re.sub(r'\s{5}\s*', '\n', v).replace('&bull;', '\n*')


def do_components(component_tests):
    if len(component_tests) > 0:
        max_name = tuple((len(max(component_tests, key=lambda x: len(x[k]))[k])
                       for k in ['name']))[0]
        fmt = '  %%s%%-%ds%%-%ds%%%ds' % (8+1, max_name+1, 1)
        print fmt % ('', 'Lab Code', 'Component Name', 'Component Type')
        for d in component_tests:
            li = ' '*4*(d['level']-1)
            print fmt % (li, d['mnemonic'], d['name'], d['tbp_type'])



def do_reference_ranges_all(d, reference_ranges):
    print "Reference Range:", ('Effective Dates: %s' %
                               (d['reference_range_effective_date']+' -'
                                if d['reference_range_effective_date']
                                else 'Unknown'))
    print gen_reference_ranges(reference_ranges)
    print "Units:", d['reference_range_units']
    print "Ref Range Comments:", break_multiline(d['reference_range_addendum'])


def gen_reference_ranges(reference_ranges):
    """
    Generate a table showing the reference ranges. The data is a list of tuples of the form 
    (f age_range, f reference_test, m age_range, m reference_test)
    If any of the tuple components are not specified, '' is used.
    """
    if reference_ranges:
        fmt = '%-8s%-22s  %-8s%s\n'
        out = (fmt *2) % ("Female", "", "Male", "", "Age", "Range", "Age", "Range")
        for (f_age,f_range,m_age,m_range) in reference_ranges:
            f_age   = f_age   if f_age   else ''
            f_range = f_range if f_range else ''
            m_age   = m_age   if m_age   else ''
            m_range = m_range if m_range else ''
            out +=  fmt % (f_age, f_range, m_age, m_range)
        return out.strip()              # Remove trailing CR for print
    return ''

def do_performing_lab(d):
    """
    The performing lab combines the UWMC and HMC settings, where they are both
    shown on the same line.
    """
    return '%s%s%s' % (
        ('UWMC: %s' % d['done_uwmc']) if d['done_uwmc'] else '',
        '   ' if d['done_hmc'] and d['done_uwmc'] else '',
        ('HMC: %s' % d['done_hmc']) if d['done_hmc'] else '')


def do_cpt_codes(cpt_codes):
    """
    Top-level function for handling CPT codes. The data passed in is a list of
    tuples of the form (cpt code, count, medicare reimbursement).
    """
    if cpt_codes:
        first = cpt_codes[0]
        cpt_codes_header(first[0], first[1])
        for cpt_code in cpt_codes[1:]:
            cpt_codes_middle(cpt_code[0], cpt_code[1])
        cpt_codes_footer()


def format_medicare(dollar):
    """
    The medicare data is stored with 4 digits of precision to the right of the
    decimal point. Here we want to format it with 2 digits to the right of the
    decimal point. Note that the value we get here most of the time is of type
    Decimal.
    """
    if type(dollar) == type(Decimal(0.0)):
        return '%6.2f' % (dollar,)
    return dollar


def cpt_codes_header(code, medicare):
    """
    Display the first line of CPT codes. This differs from the other lines since
    this line contains the headers and the first piece of data.
    """
    print '%-12s%-10s%-30s%s' % ('CPT Codes:', code, 'Medicare Reimbursement:', format_medicare(medicare))


def cpt_codes_middle(code, medicare):
    """
    Display the other detail lines showing CPT code and medicare amounts.
    """
    print '%-12s%-10s%-30s%s' % ('', code, '', format_medicare(medicare))


def cpt_codes_footer():
    """
    Display the CPT code disclaimer.
    """
    print 'Medicare reimbursements do not reflect charges or costs; CPT codes may not be complete.'


def action(args):
    """
    Write the detail of a test to stdout.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    if args.edit_mode:
        oltg.models.object_query = object_queries.StagingObjectQueries(session,  d['db_type'])
    else:
        oltg.models.object_query = object_queries.ProdObjectQueries(session, d['db_type'])
        d = get_mnemonic_detail(args.mnemonic)
    if 'message' in d:
        print d['message']
    if 'mnemonic' in d:
        print 'Test Information:%s' % (
            ' Not Orderable' if d['order_flag']=='N' else 
            ' Billing Only' if d['order_flag']=='B' else '')
        print 'Name:', d['display_name']
        print 'Cross References:', ', '.join(d['xrefs'])
        print "Specimen Type:", d['specimen_type']
        print "Lab Mnemonic:", d['mnemonic']
        print "CPOE Name:", d['cerner_names']
        print "EPIC Name:", d['epic_name']
        print "General Information:", break_multiline(d['test_info'])
        print "", '\n'.join(['%s | %s' % (address,label) for (address,label) in d['cautions']])
        print "Components:"
        do_components(d['component_tests'])
        do_reference_ranges_all(d, d['reference_ranges'])
        print
        print "Collection and Handling:"
        print "Collection:", d['collection']
        print "Handling:", d['specimen_handling']
        print "Amount:", d['amount']
        print "Minimum:", d['minimum_amount']
        print
        print "Laboratory:"
        print "Processing:", d['processing_instructions'].replace('<br/>','\n') if d['processing_instructions'] else 'None'
        print "Performing Lab:", do_performing_lab(d)
        print "Outside Lab:", d['done_other']
        print "Frequency:", d['frequency']
        print "Available STAT?", d['available_stat']
        print "LIS Dept Code:", d['department']
        print "Last Updated:", d['updated_date']
        print "Method:", d['method']
        do_cpt_codes(d['cpt_codes'])
