"""
Test functions in controllers
"""
import os
import unittest
from datetime import datetime
import time

from oltg.controllers import db_interface as dbi

class TestCleanGarbarge(unittest.TestCase):
    def testIsGarbage(self):
        self.assertTrue(dbi.is_garbage('&nbsp;'))
        self.assertTrue(dbi.is_garbage('<p>&nbsp;</p>'))
        self.assertTrue(dbi.is_garbage('<p>&nbsp;</p>'.upper()))

    def testIsNotGarbage(self):
        self.assertFalse(dbi.is_garbage('hi there&nbsp;'))
        self.assertFalse(dbi.is_garbage(['']))        
        
if __name__ == '__main__':
    unittest.main()
