"""
Search the oltg.
"""

import sys
from math import log10
from itertools import groupby
import os
from os import path
from oltg.controllers.search import search

import oltg.subcommands
from oltg import config
import oltg.models
import oltg.models.object_queries as object_queries


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('-s','--search_text', required=True,
                        nargs='+',      # Allow multiple words
                        help = 'What to search for.')
    parser.add_argument('-t', '--search_type', choices=('mnemonic', 'text'),
                        default = 'text',
                        help = 'Specify what type of search you want to do. (default text)')
    parser.add_argument('-c','--search_as_component',
                        action="store_true", default=False,
                        help = 'Search components of tests that match.')
    parser.add_argument('-x','--search_cross_reference',
                        action="store_true", default=False,
                        help = 'Look at the cross references too.')
    parser.add_argument('-f','--search_staff_only',
                        action="store_true", default=False,
                        help = 'Expand public search to show tests only available to staff.')
    parser.add_argument('-e','--edit_mode',
                        action="store_true", default=False,
                        help = 'Look at staging tables for tests that have been edited.')


def action(args):
    (d, session, engine) = oltg.subcommands.init_args(args)
    try:
        if args.edit_mode:
            oltg.models.object_query = object_queries.StagingObjectQueries(session, d['db_type'])
        else:
            oltg.models.object_query = object_queries.ProdObjectQueries(session, d['db_type'])
        (have_search_results, search_results) = search(session,
                                                       d['db_type'],
                                                       args.search_type,
                                                       ' '.join(args.search_text),
                                                       args.search_as_component,
                                                       args.search_cross_reference,
                                                       args.search_staff_only,
                                                       args.edit_mode)
        print 'Have %s search results' % (str(len(search_results)) if have_search_results else 'no',)
        headers = ('Code', 'Test Name', 'Spec Type', 'Relevance', 'Ordered', 'Sendout')
        # Change the '&bull;'s to '*'s.
        search_results = map(lambda x: x[:3] + (x[3].replace('&bull;', '*'),) + x[4:], search_results)
        # Determine the maximum size for each field, including the headers.
        header_maxes = map(max, *map(lambda x: map(lambda y:len(y) if type(y)==type('') else len(str(y)), x), search_results+[headers]))
        fmt = ' '.join(map(lambda x:'%-' + str(max(1,x)) + 's', header_maxes))
        print fmt % headers
        for r in search_results:
            print fmt % r
    finally:
        oltg.models.release_session(session, engine)
