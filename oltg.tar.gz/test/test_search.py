#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Makes sure that all tests can be displayed.
"""


import os
from os import path
import sys
import unittest
import traceback

import oltg.config as config
import oltg.models
from oltg.controllers import app
from oltg.controllers.search import search_page
import oltg.models.object_queries as object_queries


class AfterConvertOldOltg(unittest.TestCase):
    def test_all(self):
        configfile = path.join('config', os.environ['HOSTNAME'], 'oltg') + '.cfg'
        config_dict = config.read(configfile)
        (session, engine) = oltg.models.setup_db_session(config_dict)
        try:
            oltg.models.object_query = object_queries.ProdObjectQueries(session, config_dict['db_type'])
            environ = dict(SESSION = session,
                           STAFF_ONLY = True,
                           EDIT_MODE = True,
                           CONFIG = config_dict,
                           REMOTE_USER = 'Tester',
                           REMOTE_ADDR = '127.0.0.1')
            parameters = dict(search_type = 'text',
                              search_text = 'MRW',
                              search_as_component = 'yes')
            environ[app + '.parameters'] = parameters
            sea = search_page(environ, lambda ok,atts: None, None)
            self.assertTrue(sea[0].count('>BN MRW Asp/Bx Procedure<') >= 4)
        except Exception as e:
            tb = traceback.format_exc()
            print 'Caught Exception %s\n%s' % (e, tb)
            raise e


if __name__ == '__main__':
    unittest.main()
