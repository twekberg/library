#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Read the spreadsheet that has the mapping from cerner order code to LIS mnemonic.
"""

# Example:
#   ./runoltg import_lis_mnemonic filename


from datetime import datetime
import argparse
import os
import os.path
import sys

from labmed.util.unicode import to_unicode
from labmed.util.date_time_parser import parse_date, STD_DATE_FORMAT
from labmed.util.pluralize import just_pluralize
import labmed.spreadsheet_reader

import oltg.subcommands
import oltg.models
from oltg.models.create_models import CernerOrder
from oltg.models.messages import Messages


def build_parser(parser):
    """
    Get the command line arguments needed by this subcommand.
    """
    oltg.subcommands.default_parser(parser)
    labmed.spreadsheet_reader.spreadsheet_parser(parser, what_file='cerner order code -> LIS')


def action(args):
    """
    Scan Chuck's CERNER mapping file. This should go away in the future when
    the LIS mnemonic is included in the main order spreadsheet.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    messages = Messages(session, 'Load LIS mnemonic')
    try:
        ok = False
        messages.store('started')
        try:
            act = labmed.spreadsheet_reader.Action(args.input_filename,
                                                   RowHandler,
                                                   row_handler_args = {'session': session,
                                                                       'only_print': False},
                                                   csv_sep=args.csv_sep)
            act.loop()
            ok = True
        except Exception as e:
            # Unexpected exception.
            messages.store('Caught exception', ok, e)
        messages.store('completed. act.count=%d, bad codes=%d, mising_mnemonic=%d' % (act.count, act.row_handler.missing_count, act.row_handler.missing_mnemonic), ok)
    finally:
        session.commit()
        oltg.models.release_session(session, engine)
    return 0 if ok else 1               # exit status


class RowHandler(labmed.spreadsheet_reader.BaseRowHandler):
    """
    Default row handler simply copies the data into the object.
    """
    def __init__(self, session, column_names, only_print):
        labmed.spreadsheet_reader.BaseRowHandler.__init__(self, session, None, column_names, only_print)
        self.missing_count = 0          # Couldn't find these order code rows
        self.missing_mnemonic = 0       # No LIS mnemonic in spreadsheet

    def handle(self, row):
        code_value = row[self.column_map['code_value']]
        o = list(self.session.query(CernerOrder).filter(CernerOrder.code == code_value))
        if len(o) == 0:
            self.missing_count += 1
        else:
            # Found an existing object. Adding synonyms or update primary
            o = o[0]
            outbound_alias = row[self.column_map['cv_outbound_alias']]
            if outbound_alias is not None:
                o.lab_mnemonic = outbound_alias
                self.session.commit()
            else:
                self.missing_mnemonic += 1
