#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2012 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Contains activities that are common among controllers.
This avoids having to change each controller when a change is needed.
"""

from HTMLParser import HTMLParser

import oltg
# This is the generic application name.
from oltg.controllers import app
# This is the apache and python app installation name.
# This is used to allow for multiple independent installation locations.
from oltg.app import APP



def common_namespace(environ, config_dict, page_subtitle='', first_time=False):
    """
    Create a dict for the common elements for public, staff only and edit modes.
    page_subtitle is used by the create controller.
    """
    parameters = environ.get(app + '.parameters', {})
    staff_only = environ.get('STAFF_ONLY', False)
    edit_mode = environ.get('EDIT_MODE', False)
    static_page = environ.get('STATIC_PAGE', False)
    page_mode = ''
    background_color = 'default'
    # For Staff Only Test Catalog, Provide Feedback, Install UW Certificate, Show/Hide subcomponents,
    # and hiding search cross reference checkbox from public.
    show_staff_detail = False
    # Show 'Create', 'push2prod' buttons, and have links in search results go to the edit page.
    advanced_actions = False
    search_type = parameters.get('search_type', '')
    if staff_only:
        background_color = 'blue'
        page_mode = '- Staff Only'
        show_staff_detail = True
    if edit_mode:
        advanced_actions = True
        background_color = 'purple'
        page_mode = '- Edit Mode'
        show_staff_detail = True
    if static_page:
        # The page is in the html/ directory. Have to go up one level to get to
        # the css and images directories.
        static_content_home = ''
        if staff_only:
            home_page = 'staff.html'
        else:
            home_page = 'index.html'
    else:
        static_content_home = '/mastermu/' + APP + '/'
        home_page = environ.get('SCRIPT_NAME', '').rstrip('/') or None
    return dict(advanced_actions       = advanced_actions,
                background_color       = background_color,
                page_mode              = page_mode,
                page_sub_title         = page_subtitle,
                show_staff_detail      = show_staff_detail,
                show_javascript        = True,
                static_content_home    = static_content_home, # location of static content (css,js,image)
                static_page            = static_page,
                home_page              = home_page,
                alternate_web_host     = config_dict.get('alternate_web_host', ''),
                version                = oltg.__version__,
                # Retain the search parameters.
                search_type            = search_type,
                search_text            = parameters.get('search_text', ''),
                search_as_component    = parameters.get('search_as_component',    '' if search_type else 'yes'),
                search_cross_reference = parameters.get('search_cross_reference', '' if search_type else 'yes'),
                )


# The following are shared between the create and edit controllers.

def adjust_new_value(new_value):
    """
    Note that new_value has one element for each value on the page. Most only have one
    element. Multivalue cone from grouped checkboxes and SELECT lists.
    """
    adjustments = [("<br>", "<br/>"),
                   ("<BR>", "<br/>"),
                   ("<STRONG>", "<strong>"),
                   ("</STRONG>", "</strong>"),
                   ("<p>", "<P>"),
                   ("</p>", "</P>"),
                   ]
    ret = []
    for nv in new_value:
        for (s, r) in adjustments:
            nv = nv.replace(s, r)
        ret.append(remove_word_cruft(nv))
    # Need to make sure these strings are encoded as utf-8.
    # Not doing this causes trouble with sqlalehcmy:
    #   DataError: (DataError) invalid byte sequence for encoding "UTF8": 0xB0
    # when trying to handle the degree symbol. This has a latin-1 encoding of
    # xB0, but has a 2 byte utf-8 encoding of \xC2, \xB0. The 1 byte encoding
    # \xB0 is not a valid utf-8 encoding.
    return [r.encode('utf-8') for r in ret]


def remove_word_cruft(s):
    """
    If you cut/paste from a word document, it adds a lot of extra trash.  This
    function removes the trash and fixes up the boldface tags that contain
    double quotes (").
    """
    # Handle <b> and <span> tags -> <strong>bold</strong
    #  <b style="mso-bidi-font-weight:normal">bold</b>
    #  <span style="font-weight: bold;">bold</span>
    class OltgHTMLParser(HTMLParser):
        def __init__(self):
            HTMLParser.__init__(self)
            self.tag_translate = dict(b = 'strong')
            self.html = []
            self.bold_span_stack = []   # stack for span tags
        def handle_starttag(self, tag, attrs):
            if tag == 'span':
                attrs = dict(attrs)
                if 'style' in attrs and dict(attrs)['style'] == 'font-weight: bold;':
                    # Change <span...bold> to <strong>.
                    self.bold_span_stack.append(True)
                    tag = 'strong'
                else:
                    # Ordinary <span>
                    self.bold_span_stack.append(False)
            if tag in self.tag_translate:
                tag = self.tag_translate[tag]
            self.html.append('<%s>' % tag)
        def handle_endtag(self, tag):
            if tag == 'span':
                if self.bold_span_stack.pop():
                    # Had a <span...bold> now <strong>. Need to end it with
                    # </strong>.
                    tag = 'strong'
            if tag in self.tag_translate:
                tag = self.tag_translate[tag]
            self.html.append('</%s>' % tag)
        def handle_data(self, data):
            self.html.append(data)
        def get_html(self):
            # Join the lines and convert back-to-back br tags to one.
            # Newlines cause trouble for Javascript. Change them to JS blanks.
            return (''.join(self.html)).replace('<br></br>', '<br/>').replace('\n', ' ').replace('\r', '')

    p = OltgHTMLParser()
    p.feed(s)
    return p.get_html()


