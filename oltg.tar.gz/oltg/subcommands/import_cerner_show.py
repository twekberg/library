#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Read the spreadsheet that has the synonym show flag for various lab mnemonic/synonyn pairs.
"""

# Example:
#   ./runoltg import_cerner_show filename


import argparse
import os
import os.path
import sys

import labmed.spreadsheet_reader
from labmed.util.boolean import to_bool

import oltg.subcommands
import oltg.models
from oltg.models.create_models import (CernerSynonym,
                                       CernerSynonymDisplay)
from oltg.models.messages import Messages


def build_parser(parser):
    """
    Get the command line arguments needed by this subcommand.
    """
    oltg.subcommands.default_parser(parser)
    labmed.spreadsheet_reader.spreadsheet_parser(parser, what_file='cerner show synonym')


def action(args):
    """
    The hidden primaries file I got from Chuck that lists the synonyms
    that have a 'Snow Syn' setting.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    messages = Messages(session, 'Set synonym show')
    try:
        ok = False
        messages.store('started')
        try:
            act = labmed.spreadsheet_reader.Action(args.input_filename,
                                                   RowHandler,
                                                   row_handler_args = {'session': session,
                                                                       'only_print': False},
                                                   csv_sep=args.csv_sep)
            act.loop()
            ok = True
        except Exception as e:
            # Unexpected exception.
            messages.store('Caught exception', ok, e)
        messages.store('completed. count=%d, missing count=%d, duplicates=%d' % (act.count, act.row_handler.missing_count, act.row_handler.duplicates), ok)
    finally:
        session.commit()
        oltg.models.release_session(session, engine)
    return 0 if ok else 1               # exit status


class RowHandler(labmed.spreadsheet_reader.BaseRowHandler):
    """
    Default row handler simply copies the data into the object.
    """
    def __init__(self, session, column_names, only_print):
        labmed.spreadsheet_reader.BaseRowHandler.__init__(self, session, None, column_names, only_print)
        self.missing_count = 0
        self.duplicates = 0

    def handle(self, row):
        synonym_name = row[self.column_map['name']]
        o = list(self.session.query(CernerSynonymDisplay)
                 .join(CernerSynonym)
                 .filter(CernerSynonym.name == synonym_name))
        if len(o) == 0:
            self.missing_count += 1
        elif len(o)>1:
            self.duplicates += 1
        else:
            # Found an existing object. Adding synonyms or update primary
            sd = o[0]
            sd.show = to_bool(row[self.column_map['show_syn']])
