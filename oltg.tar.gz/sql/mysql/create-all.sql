--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2010 University of Washington Medical Center
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Medical Center and is not to
--    be disclosed to any third party without prior express written
--    permission of University of Washington Medical Center University
--    of Washington Medical Center, as the author and owner under 17
--    U.S.C. Sec. 201(b) of this work made for hire, claims copyright
--    in this material as an unpublished work under 17 U.S.C. Sec.s 102
--    and 104(a)
-- 
--  ******************************************************************* 

source dept_tally_view.sql
source messages.sql
source tally_rankings.sql

-- No foreign key
source oltg.sql
source oltg_staging.sql
source component_tests.sql
source component_tests_staging.sql
source caution_urls.sql
source caution_urls_staging.sql
source reference_ranges.sql
source reference_ranges_staging.sql
source billing_and_cpt_codes.sql
source billing_and_cpt_codes_staging.sql
source cross_references.sql
source cross_references_staging.sql
source lis_feed.sql
source lis_feed_staging.sql

source users.sql
source fee_schedules.sql

source create-indexes.sql
