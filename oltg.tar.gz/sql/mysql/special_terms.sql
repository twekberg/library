--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2012 University of Washington Laboratory Medicine
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Laboratory Medicine and is
--    not to be disclosed to any third party without prior express
--    written permission of University of Washington Laboratory Medicine.
--    University of Washington Laboratory Medicine, as the
--    author and owner under 17 U.S.C. Sec. 201(b) of this work made
--    for hire, claims copyright in this material as an unpublished 
--    work under 17 U.S.C. Sec.s 102 and 104(a)   
-- 
--  *********************************************************************


-- Special terms that need to be marked in some way.

-- An example is ColoSeq which needs to be marked with the trademark (TM)
-- symbol. The match_regex would be
--   r'\b(ColoSeq)\b'
-- which matches the word ColoSeq with word boundaries at both ends. A word is
-- defined as a sequence of alphanumeric or underscore characters. The
-- replacement_string would be
--   r'\1&trade;'
-- Count, is the number of replacements allowed, which for this case would be
-- 1  A 0 means to replace all occurrances.

-- This approach allows one to match any text and replace it with any other
-- text, potentially referencing text in the match_regex. These values get
-- passed to the re.sub function.

-- Note that the match_regex must be unique to avoid clashes.
CREATE TABLE IF NOT EXISTS `mastermu_oltg`.`special_terms` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `match_regex` varchar(100) NOT NULL UNIQUE,
  `replacement_string` varchar(100) NOT NULL,
  `count` integer default 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Special terms, like trademarks.';
