.. -*- mode: rst -*-

============
Introduction
============

This program is used to support the display of Online Test Guide data in a
browser. There are two main parts:

  * the web code, which consists of a oltg.wsgi, and the javascript, CSS and image files.
  * the python module. This is a normal python module but, with a parameter
    setting (APP), may be stored in a place other than the production python directory.

================
Building Package
================

All building uses the make command. If you are installing the package to the
normal production python directory (/usr/lib/python2.x/site-packages)
you will need to be root, and specify no special args::

  sudo make package

The package will be build and the changes will be recognized by the apache WSGI
module.

If you want to install the package separate from the production directory, do
something like this instead::

  sudo make package APP=oltg_$USER

The package actually gets installed in /home/mastermu/$APP/lib/python. In
this way multiple users can do testing without interferring with each other.
In addition, one can see which test versions have been built.  Note that with
this approach, before using the package one will have to set PYTHONPATH:

  export PYTHONPATH=/home/mastermu/oltg_$USER/lib/python

Refer to the Installing section for how the Python path should be set for
apache.

==========
Installing
==========

The install make target may update the svn_revision.py file and copy it to the
directory apache references to find code (TARGET). After that it locates with oltg.wsgi
file, Javascript, images and CSS and copies them to the same directory.

If you are performing a production install
you will need to be root, and specify no special args::

  sudo make install

This copies the files to the production area: /var/www/html/mastermu/oltg.

If one specified the APP argument when making the package, one needs to specify
the same argument to install properly::

  sudo make install APP=oltg_$USER

This will insure that the files get copied to the proper place. In addition,
for this case, in the httpd.conf file, the python-path needs to be set so that
python can locate the package. For the user foo, the python-path setting might
be this::

  /var/www/html/mastermu/oltg:/home/mastermu/oltg_foo/lib/python

For apache, the python-path setting is simpler::

    /var/www/html/mastermu/oltg

This is because the package is stored in the standard place::

  /usr/lib/python2.X/site-packages/.

============
Apache Setup
============

For the Online Test Guide, apache uses the WSGI module.  WSGI (Web Server
Gateway Interface) is an interface specification by which server and
application communicate. Both server and application interface sides are
specified. The file /etc/httpd/conf/httpd.conf contains the settings necessary
to display the OLTG data in a browser. The settings for the production version
of the OLTG are::

  WSGIScriptAlias /oltg /var/www/html/mastermu/oltg/oltg.wsgi
  WSGIDaemonProcess mastermu processes=2 threads=15 python-path=/var/www/html/mastermu/oltg home=/var/www/html/mastermu/oltg
  <Directory /var/www/html/mastermu/oltg>
    WSGIProcessGroup mastermu
    WSGIApplicationGroup %{GLOBAL}
  </Directory>

For more details regarding these settings, refer to the WSGI Configuration
Directives page that can be found at::

  http://code.google.com/p/modwsgi/wiki/ConfigurationDirectives

An example of the apache settings for a test version are::

  WSGIScriptAlias /oltg_tom /var/www/html/mastermu/oltg_tom/oltg.wsgi
  WSGIDaemonProcess mastermu_tom processes=2 threads=15 python-path=/var/www/html/mastermu/oltg_tom:/home/mastermu/oltg_tom/lib/python home=/var/www/html/mastermu/oltg_tom
  <Directory /var/www/html/mastermu/oltg_tom>
    WSGIProcessGroup mastermu_tom
    WSGIApplicationGroup %{GLOBAL}
  </Directory>

This is almost identical to the production version except that the name is oltg_tom
instead of oltg and the python-path is different. For the production version,
the oltg package is found in the standard place mentioned earlier. For the test
version the additional python-path setting points to the /home/mastermu
directory that contains the package being tested.

=======
Queries
=======

Here are some queries that you may find useful.

24 Hour Activity
================

Show the activity over the past 24 hours from the access_logs table::

  SELECT
    to_char(date_part('day',updated_date)+date_part('hour',updated_date)/100,'99D99') AS "hour",
    count(*)
  FROM access_logs
  WHERE updated_date >= now()- interval '24 hours'
  GROUP BY to_char(date_part('day',updated_date)+date_part('hour',updated_date)/100,'99D99')
  ORDER BY 1;

Idle Processes
==============

Show the postgres processes that are idle::

  SELECT * FROM pg_stat_activity
  WHERE current_query LIKE '_IDLE_';

Show the postgres processes have been idle for 30 minutes::

  SELECT procpid FROM pg_stat_activity
  WHERE current_query LIKE '_IDLE_' AND now()-query_start >  interval '30 minutes' ORDER BY 1 DESC;

Local development
=================

Certain web pages can be created locally without a database
connection - this is useful for development. For example, to build a
page displaying the information for "CBC"::

  % cd oltg
  % ./runoltg render_template -c .
  % ./runoltg render_template -c . -j testfiles/CBC.json
  % ls *.html
  CBC.html Welcome.html


