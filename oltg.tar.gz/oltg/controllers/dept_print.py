#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Controller for the department print feature.

The main idea is that the user specifies a department or a value for one of the
done_* columns. A SELECT is done to generate a list of mnemonics, then the
detail for those tests are displayed. This is useful for a department to review
all of the tests they are responsible for, all in one place.

The body() function of the Simple template is used to display the test detail.
"""

import oltg
import oltg.controllers.collectors as collectors
from oltg.controllers import app
import oltg.models
import oltg.models.access_log as access_log
from oltg.models.db_specific import insensitive_like
from oltg.models.db_specific import regex
from oltg.templates.DeptPrint import DeptPrint
from oltg.templates.Simple import Simple
from oltg.controllers.common import common_namespace
from oltg.controllers.db_interface import get_mnemonic_detail


def dept_print(environ, start_response, logger):
    """Display test details for a whole department"""
    session = environ.get('SESSION', None)
    parameters = environ[app + '.parameters']
    config_dict = environ['CONFIG']
    db_type = config_dict['db_type']
    action = parameters.get('action', 'menu')
    namespace = common_namespace(environ, config_dict)
    # Retrieve the values for the SELECT menus.
    namespace.update(dict(
        dept_full_name  = parameters.get('dept_full_name', 'All'),
        dept_full_names = get_distinct_names(session, 'dept_full_name'),
        done_uwmc       = parameters.get('done_uwmc', 'All'),
        done_uwmc_names = get_distinct_names(session, 'done_uwmc'),
        done_hmc        = parameters.get('done_hmc', 'All'),
        done_hmc_names  = get_distinct_names(session, 'done_hmc'),
        done_other      = parameters.get('done_other', 'All'),
        numbered_tests  = eval(parameters.get('numbered_tests', 'False')),
        no_show_tests  = eval(parameters.get('no_show_tests', 'False')),
        ))
    t = DeptPrint(searchList = [namespace]).respond()
    if action == 'display':
        loc = t.find('<!-- INSERT TEMPLATE OUTPUT HERE -->')
        if loc >= 0:
            # Insert the bodies from Simple applied to each mnemonic between head and tail
            head = t[0:loc]
            tail = t[loc:]
            simple_namespace = dict(hide_subcomponents=False,
                                    show_staff_detail=False,
                                    show_javascript = True,
                                    show_empty=False,
                                    reference_range_near_top=True,
                                    static_page=True,
                                    )
            bodies = []
            errors = []
            count = 0
            for mnemonic in get_mnemonics(session, parameters, db_type):
                count += 1
                # Some of the mnemonics don't have json files. They are not
                # orderable and aren't linked to a package or battery.
                mnemonic_namespace = get_mnemonic_detail(
                    mnemonic,
                    config_dict['read_mnemonics_from_database'] == 'True',
                    json_dir=config_dict.get('mnemonics_json_dir'))
                if 'error_message' in mnemonic_namespace:
                    errors.append(mnemonic)
                else:
                    bodies.append(Simple(searchList = [simple_namespace, mnemonic_namespace]).body())
                    simple_namespace['show_javascript'] = False # Only generate Javascript the first time.
            error_message = '<br>Got %d errors: %s' % (len(errors), ' '.join(errors)) if errors else ''
            message = '<br>Number of tests: %d.' % (count,)
            t = head + message + error_message + '<hr>'.join(bodies) + tail
    start_response('200 OK', [('Content-Type', 'text/html')])
    return [str(t)]


def get_distinct_names(session, the_name):
    """
    Return a list of names, suitable for an HTML SELECT list.
    """
    sql = 'SELECT DISTINCT(%s) FROM mastermu_oltg.oltg ORDER BY 1' % (the_name,)
    # Return a list of the names.
    return ['All'] + [str(row[0]) for row in session.execute(sql)]


def get_mnemonics(session, parameters, db_type):
    """
    Get a list of mnemonics for the specified department parameters.
    """
    dept_full_name = parameters.get('dept_full_name', 'empty')
    done_uwmc      = parameters.get('done_uwmc',      'empty')
    done_hmc       = parameters.get('done_hmc',       'empty')
    done_other     = parameters.get('done_other',     'empty')
    numbered_tests = eval(parameters.get('numbered_tests', 'False'))
    no_show_tests  = eval(parameters.get('no_show_tests', 'False'))
    where_clauses = []
    if dept_full_name not in ('empty',  'All'):
        where_clauses.append("dept_full_name = '%s'" % (dept_full_name,))
    if done_uwmc not in ('empty', 'All'):
        where_clauses.append("done_uwmc = '%s'" % (done_uwmc,))
    if done_hmc not in ('empty', 'All'):
        where_clauses.append("done_hmc = '%s'" % (done_hmc,))
    if done_other not in ('empty', 'All'):
        # Not likely to get an = match here. Use case insensitive LIKE instead.
        where_clauses.append("done_other %s '%s'" % (insensitive_like(db_type), done_other))
    if numbered_tests:
        where_clauses.append("mnemonic " + regex(db_type, r'^[0-9]+$'))
    if no_show_tests:
        where_clauses.append("security_flag = 'N'")
    if len(where_clauses) == 0:
        where_clauses.append("1=1")
    sql = """SELECT mnemonic FROM mastermu_oltg.oltg WHERE %s 
ORDER BY 1""" % (' AND '.join(where_clauses),)
    # Need to pull the mnemonic out of each row in the resultset.
    return [row[0] for row in session.execute(sql)]


