from os import path

for fname in ['sha', 'rev']:
    pth = path.join(path.dirname(__file__), 'data', fname)
    try:
        with open(pth) as f:
            ver = f.read().strip()
    except Exception, e:
        print 'error reading %s: %s' % (pth, e)        
        ver = ''

    if ver:
        break
    
__version__ = "0.1" + ('.' + ver if ver else '') 
__version_info__ = tuple([int(num) if num.isdigit() else num for num in __version__.split('.')])

