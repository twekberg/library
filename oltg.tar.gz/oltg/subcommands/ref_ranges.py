#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Generate a table of tests that have reference ranges.
"""

import sys

import oltg.models.object_queries as object_queries
from oltg.controllers.db_interface import get_mnemonic_detail
import oltg.subcommands
from oltg.subcommands.display import gen_reference_ranges

def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('-m', '--mnemonics', nargs = '*',
                        help = 'optional list of lab mnemonics; all if not provided.',
                        default = None)
    parser.add_argument('-f', '--format', choices=('text', 'html'), default='text',
                        help="What form the output should be written.  Default [%(default)s]")
    parser.add_argument('-o', '--out_file', action="store", default='-',
                        help="Where to write the output. '-' means stdout. Default [%(default)s]")


def get_mnemonics(session):
    """
    Get the list of mnemonics that have reference ranges.
    """
    # Need to pull the mnemonic out of each row in the resultset.
    return [row[0] for row in session.execute("""
SELECT distinct(mnemonic) FROM mastermu_oltg.reference_ranges""")]


def action(args):
    (d, session, engine) = oltg.subcommands.init_args(args)
    oltg.models.object_query = object_queries.ProdObjectQueries(session, d['db_type'])
    if args.out_file is None:
        args.out_file = '-'
    if args.out_file == '-':
        out_file_closable = False
        out_file = sys.stdout
    else:
        out_file_closable = True
        out_file = open(args.out_file)

    mnemonics = get_mnemonics(session) if args.mnemonics is None else args.mnemonics

    try:
        for mne in [m.upper() for m in mnemonics]:
            data = get_mnemonic_detail(mne)
            if args.format == 'text':
                write_text(out_file, data)
            else:
                write_html(out_file, data)
    finally:
        oltg.models.release_session(session, engine)
        if out_file_closable:
            out_file.close()
    return 0                            # exit status

def write_text(out_file, data):
    out_file.write("""Test Information:%s
Name: %s
Lab Mnemonic: %s
Reference Range: Effective Dates: %s
%s
Units: %s
""" % ((' Not Orderable' if data['order_flag']=='N' else 
        ' Billing Only' if data['order_flag']=='B' else ''),
       data['display_name'],
       data['mnemonic'],
       data['reference_range_effective_date'],
       gen_reference_ranges(data['reference_ranges']),
       data['reference_range_units']))
    
def write_html(out_file, data):
    out_file.write("""<table>
  <tr>
    <td colspan="2">
      Test Information:%s
    </td>
  </tr>
  <tr>
    <td>
      Name:
    </td>
    <td>
      %s
    </td>
  </tr>
  <tr>
    <td>
      Lab Mnemonic:
    </td>
    <td>
      %s
    </td>
  </tr>
  <tr>
    <td>
      Reference Range: Effective Dates:
    </td>
    <td>
    <td>
      %s
    </td>
  </tr>
  <tr>
    <td>
      &nbsp;
    </td>
    <td>
      %s
    </td>
  </tr>
  <tr>
    <td>
      Units:
    </td>
    <td>
      %s
    </td>
  </tr>
</table>
""" % ((' Not Orderable' if data['order_flag']=='N' else 
        ' Billing Only' if data['order_flag']=='B' else ''),
       data['display_name'],
       data['mnemonic'],
       data['reference_range_effective_date'],
       gen_reference_ranges_html(data['reference_ranges']),
       data['reference_range_units']))

def gen_reference_ranges_html(reference_ranges):
    if reference_ranges:
        out = """
      <table class="refrange">
	<tr>
	  <th colspan="2">Female</th>
	  <th colspan="2">Male</th>
	</tr>
	<tr>
	  <th>Age</th><th>Range</th><th>Age</th><th>Range</th>
	</tr>"""
        for (f_age,f_range,m_age,m_range) in reference_ranges:
            if not f_age:   f_age   = '&nbsp;'
            if not f_range: f_range = '&nbsp;'
            if not m_age:   m_age   = '&nbsp;'
            if not m_range: m_range = '&nbsp;'
            out += """
	<tr>
	  <td>%s</td>
          <td>%s</td>
          <td>%s</td>
          <td>%s</td>
	</tr>
      </table>""" % (f_age, f_range, m_age, m_range)
        return out
    return ''
