#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Mark specific cerner order codes as inactive.
"""

# Example:
#   ./runoltg import_cerner filename

from datetime import datetime
import os
import os.path
import random
import re
import sys

from labmed.util.unicode import to_unicode
from labmed.util.date_time_parser import parse_date, STD_DATE_FORMAT
from labmed.util.pluralize import just_pluralize
import labmed.spreadsheet_reader

import oltg.subcommands
import oltg.models
import oltg.models.object_queries as object_queries
from oltg.models.create_models import (Oltg,
                                       CernerOrder,
                                       CernerSynonym,
                                       CernerSynonymDisplay,
                                       CernerNonplaceholderSynonym)
from oltg.models.messages import Messages


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('--codes', nargs='+', help='One or more cerner order codes.',
                        default=[])


def action(args):
    """
    Mark the specified cerner order codes as inactive.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    messages = Messages(session, 'Mark CERNER inactive')
    try:
        ok = False
        count = 0
        messages.store('started')
        if len(args.codes) > 0:
            for o in list(session.query(CernerOrder)
                          .filter(CernerOrder.code.in_(args.codes))
                          .all()):
                o.active = False
                count += 1
            session.commit()
        ok = True
    except Exception as e:
        # Unexpected exception.
        messages.store('Caught exception', ok, e)
    finally:
        messages.store('completed. count=%d' % (count,), ok)
        session.commit()
        oltg.models.release_session(session, engine)
    return 0 if ok else 1               # exit status
