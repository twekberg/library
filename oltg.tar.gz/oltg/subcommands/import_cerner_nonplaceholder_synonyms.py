#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
This loads synonym data for the nonplaceholder tests.
Essentially this loads the cerner_nonplaceholder_synonyms table.
"""

# Example:
#   ./runoltg import_cerner_nonplaceholder_synonyms filename

import os
import os.path
import random
import re
import sys

from labmed.util.boolean import to_bool
from labmed.util.unicode import to_unicode
from labmed.util.pluralize import just_pluralize
import labmed.spreadsheet_reader

import oltg.subcommands
import oltg.models
import oltg.models.object_queries as object_queries
from oltg.models.create_models import (Oltg,
                                       CernerNonplaceholderSynonym,
                                       CernerSynonym)
from oltg.models.messages import Messages


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    labmed.spreadsheet_reader.spreadsheet_parser(parser, what_file='cerner nonplaceholder synonym')


def action(args):
    """
    Scan the plasteholder map table we got from Chuck.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    messages = Messages(session, 'Load nonplaceholder')
    try:
        ok = False
        messages.store('started')
        try:
            act = labmed.spreadsheet_reader.Action(args.input_filename,
                                                   RowHandler,
                                                   row_handler_args = {'session': session,
                                                                       'only_print': False},
                                                   csv_sep=args.csv_sep)
            act.loop()
            ok = True
        except Exception as e:
            # Unexpected exception.
            messages.store('Caught exception', ok, e)
        messages.store('completed. count=%d, missing synonyms=%d' % (act.count, act.row_handler.missing_synonym), ok)
    finally:
        session.commit()
        oltg.models.release_session(session, engine)
    return 0 if ok else 1               # exit status


class RowHandler(labmed.spreadsheet_reader.BaseRowHandler):
    """
    Default row handler simply copies the data into the object.
    """
    def __init__(self, session, column_names, only_print):
        labmed.spreadsheet_reader.BaseRowHandler.__init__(self, session, None, column_names, only_print)
        self.missing_synonym = 0

    def handle(self, row):
        if to_bool(row[self.column_map['display_this_synonym_flag']]):
            nonplaceholder_lab_mnemonic = row[self.column_map['lab_mnemonic']]
            synonym_name = row[self.column_map['synonym_name']]
            o = list(self.session.query(CernerSynonym)
                     .filter(CernerSynonym.name == synonym_name)
                     )
            if len(o) == 0:
                self.missing_synonym +=1
            else:
                cerner_synonym_id = o[0].id
                o = list(self.session.query(CernerNonplaceholderSynonym)
                         .filter(CernerNonplaceholderSynonym.nonplaceholder_lab_mnemonic == nonplaceholder_lab_mnemonic)
                         .filter(CernerNonplaceholderSynonym.placeholder_cerner_synonym_id == cerner_synonym_id)
                         )
                if len(o) == 0:
                    # Not there yet. Need to create one.
                    o = CernerNonplaceholderSynonym()
                    o.nonplaceholder_lab_mnemonic = nonplaceholder_lab_mnemonic
                    o.placeholder_cerner_synonym_id = cerner_synonym_id
                    o.show = True
                    self.session.add(o)
                else:
                    # Found an existing CernerNonplaceholderSynonym object.
                    o = o[0]
                    o.show = True           # Make sure show is True
                o.ready_for_delete = False
                self.session.commit()
