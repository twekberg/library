#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Controller for the Create New Test page.
"""

import oltg
import oltg.models
from oltg.models.create_models import (AuditLog,
                                       CautionUrlStaging as CautionUrl,
                                       CrossReferenceStaging as CrossReference,
                                       OltgStaging as Oltg)
import oltg.controllers.collectors as collectors
from oltg.controllers import app
from oltg.controllers.db_interface import get_mnemonic_detail_from_object
from oltg.controllers.common import common_namespace
from oltg.controllers.common import adjust_new_value
from oltg.templates.EditCreateTest import EditCreateTest
from datetime import datetime
import re
import cgi


def create(environ, start_response, logger):
    """Create details for a test."""
    session = environ.get('SESSION', None)
    engine = environ.get('ENGINE', None)
    config_dict = environ['CONFIG']
    oltg.models.setup_db_models(session, engine)
    parameters = environ[app + '.parameters']
    #raise Exception('dir=%s, parameters=%s' % (dir(parameters), parameters))
    mnemonic = parameters.get('mnemonic', '')
    action = parameters.get('action', '')

    o = oltg.models.object_query.get_oltg(mnemonic)
    display_test = True
    if o:
        # Retain the values entered by the user, in case they just want to change the mnemonic.
        (o, xrefs, cautions) = fill_in_oltg(parameters)
        message = 'That mnemonic (%s) already exists. Either edit that mnemonic or pick a different one.' % (mnemonic,)
    elif action:
        (o, xrefs, cautions) = fill_in_oltg(parameters)
        if mnemonic == '':
            message = 'Please enter a mnemonic for this test.'
        elif parameters.get('test_name', '') == '':
            message = 'Please enter a name for this test.'
        else:
            if action == 'create':
                message = do_create(session, parameters, environ.get('REMOTE_USER', 'Unknown User'),
                                    o, xrefs, cautions)
                display_test = False
            else:
                message = 'Internal error: unknown action "%s"' % (action,)
    else:
        message = ''
        cautions = []
        xrefs = []
    if o is None:
        o = Oltg()
    namespace = get_mnemonic_detail_from_object(o)
    if not bool(namespace['security_flag']):
        # Have the security_flag default to Internal.
        namespace['security_flag'] = 'Internal'

    namespace.update(common_namespace(environ, config_dict, page_subtitle='- create'))
    namespace.update(dict(
        create = True,
        entered_name = o.name,
        all_cerner_lab_mnemonics = oltg.models.object_query.get_all_cerner_lab_mnemonics(),
        display_test = display_test,
        message = message,
        updated_date = datetime.now().strftime('%m/%d/%Y'),

        # The Cerner names probably don't make sense here.
        show_cerner_synonyms = False,
        primary = [],
        synonyms = [],

        # Data entered by data from previous screen.
        oltg = o,
        xrefs = xrefs,
        cautions = cautions,
        ))
    start_response('200 OK', [('Content-Type', 'text/html')])
    with open('/tmp/createout.txt', 'w') as o:
        o.write('namespace=%s' % (namespace,))
    t = EditCreateTest(searchList = [namespace], filter='Filter')
    return [str(t.respond())]


class DoFill(object):
    """
    Helper class to handle putting values into the Oltg object.
    """
    def __init__(self, parameters):
        self.parameters = parameters
        self.o = Oltg()
        self.o.hospital = 'U'
        self.o.tbp_type = 'T'

    def process(self, name, to_upper=False, parameter_name=None):
        """
        Store a value into the Oltg object.
        If to_upper is True then convert it to upper case first.
        name is the name in the Oltg object.
        parameter_name is the name in the HTML form.
        """
        if parameter_name is None:
            parameter_name = name
        if parameter_name in self.parameters:
            new_value = adjust_new_value(self.parameters.getall(parameter_name))[0]
        else:
            new_value = ''
        if to_upper and new_value:
            new_value = new_value.upper()
        self.o.set(name, new_value)


def fill_in_oltg(parameters):
    """
    Creates a new oltg object using values specified by the user.
    Does not interact with the database in any way.

    parameters - values from the form.

    Returns an Oltg object, and the xrefs and cautions.
    """
        
    dc = DoFill(parameters)

    dc.process('name', parameter_name='test_name')
    dc.o.lab_name = dc.o.name
    dc.process('mnemonic', to_upper=True)
    dc.process('orca_name')
    dc.process('epic_name')

    xrefs = sorted(adjust_new_value(parameters.getall('cross_references')))

    dc.process('dept_code')
    dc.process('dept_full_name')
    dc.process('specimen_type')
    dc.process('test_info')

    cautions = zip(parameters.getall('cautions_address'), parameters.getall('cautions_label'))

    dc.process('unit')
    dc.process('security_flag')
    dc.process('collection')
    dc.process('specimen_handling')
    dc.process('amount')
    dc.process('minimum_amount')
    dc.process('processing_instructions')
    dc.process('done_uwmc')
    dc.process('done_hmc')
    dc.process('done_other')
    dc.process('frequency')
    dc.process('available_stat')
    dc.process('order_flag')
    dc.process('suppress_print_flag')
    dc.process('method')
    dc.process('additional_billing')

    new_updated_date = parameters.get('updated_date')
    if new_updated_date:
        try:
            # Convert to a datetime object.
            dc.o.updated_date = datetime.strptime(new_updated_date, '%m/%d/%Y')
        except ValueError as e:
            pass

    new_reference_range_effective_date = parameters.get('reference_range_effective_date')
    if new_reference_range_effective_date:
        try:
            # Convert to a datetime object.
            dc.o.reference_range_effective_date = datetime.strptime(new_reference_range_effective_date, '%m/%d/%Y')
        except ValueError as e:
            pass

    dc.process('reference_range_addendum')
    dc.process('reference_range_units')
    return (dc.o, xrefs, cautions)


def do_create(session, parameters, user, o, xrefs, cautions):
    """
    Store the new test in the staging area.
    """
    mnemonic = o.mnemonic

    # Record the additions in the audit log
    da = DoAudit(session, o, user)
    da.process('name')
    da.process('mnemonic')
    da.process('orca_name')
    da.process('epic_name')

    # Add the new cross references.
    for cross_reference in xrefs:
        cr = CrossReference()
        cr.mnemonic = mnemonic
        cr.cross_reference = cross_reference
        da.process('cross_reference', always=True, value=cr)
        session.add(cr)

    da.process('dept_code')
    da.process('dept_full_name')
    da.process('specimen_type')
    da.process('test_info')

    # Add the new caution URLs.
    for (address, label) in cautions:
        cu = CautionUrl()
        cu.mnemonic = mnemonic
        cu.address = address
        cu.label = label
        da.process('caution', always=True, value=cu)
        session.add(cu)

    da.process('unit')
    da.process('security_flag')
    da.process('collection')
    da.process('specimen_handling')
    da.process('amount')
    da.process('minimum_amount')
    da.process('processing_instructions')
    da.process('done_uwmc')
    da.process('done_hmc')
    da.process('done_other')
    da.process('frequency')
    da.process('available_stat')
    da.process('order_flag')
    da.process('suppress_print_flag')
    da.process('method')
    da.process('additional_billing')
    da.process('updated_date')
    da.process('reference_range_effective_date')
    da.process('reference_range_addendum')
    da.process('reference_range_units')

    o.was_changed = True

    session.add(o)
    session.commit()
    return 'Test %s was created in the staging area.' % (o.mnemonic,)


class DoAudit(object):
    """
    Handles generating an audit record for each field added.
    """
    def __init__(self, session, o, user):
        self.session = session
        self.o = o
        self.mnemonic = o.mnemonic
        self.user = user
    def has_value(self, value):
        if value is None:
            return False
        if type(value) == type(''):
            if value == '':
                return False
            if value == '<br/>':
                return False
        return True

    def process(self, column_name, always=False, value=None):
        new_value = value if value is not None else self.o.get(column_name)
        if type(new_value) != type(''):
            new_value = str(new_value)
        if always or self.has_value(new_value):
            al = AuditLog()
            al.mnemonic = self.mnemonic
            al.user = self.user
            al.updated_date = datetime.now()
            al.column_name = column_name
            if new_value is None:
                new_value = ''
            if len(new_value) > al.get_db_type_length('new_value'):
                al.new_value_big = new_value
                al.new_value = None
            else:
                al.new_value = new_value
                al.new_value_big = None
            self.session.add(al)
