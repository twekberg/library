--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2011 University of Washington Laboratory Medicine
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Laboratory Medicine and is
--    not to be disclosed to any third party without prior express
--    written permission of University of Washington Laboratory Medicine.
--    University of Washington Laboratory Medicine, as the
--    author and owner under 17 U.S.C. Sec. 201(b) of this work made
--    for hire, claims copyright in this material as an unpublished 
--    work under 17 U.S.C. Sec.s 102 and 104(a)   
-- 
--  *********************************************************************


-- Audit log to keep track of who makes what changes when. If
-- necessary this table could be used to reverse changes. Of course it
-- would have to record those changes too.

-- Store a single change in this column. If the user is making several
-- changes at the same time then multiple rows will be created with
-- the same updated_date.
CREATE TABLE IF NOT EXISTS "audit_logs" (
  "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "mnemonic" varchar(16) NOT NULL,
  "user" varchar(100) NOT NULL,
  --                                         12345678901234567890123
  "updated_date" varchar(23) NOT NULL,    -- YYYY-MM-DD HH:MM:SS.SSS format
  -- May be the name of the auxiliary table instead.
  "column_name" varchar(50) NOT NULL,
  "old_value" varchar(300),
  "new_value" varchar(300),
  -- If the values are too large, store them here.
  "old_value_big" text,
  "new_value_big" text
);
