"""
Load configuration data and initialize other configuration values.
"""


from os import path
from ConfigParser import SafeConfigParser


def read(fname, app = None):
    """
    Read a configuration file and return an OrderedDict.
    """
    
    cfg = SafeConfigParser()
    # The read method silently ignores files it can't read.
    cfg.read(fname)

    d = cfg.defaults()    
    try:
        d.update(cfg.items(d['db_type']))
    except KeyError:
        msg = "Unable to locate key 'db_type' in config file %s."
        try:
            with open(fname) as f:
                pass
        except IOError as e:
            if str(e).lower().find('permission denied') >= 0:
                msg = """Unable to open file %s. This is because either
    (1) the file permissions along the path do not permit access to the file, or
    (2) selinix is prohibiting access.
You can check the selinux setting with this command:
  sudo getsebool httpd_enable_homedirs
If it is 'off' and if the file is in a home directory, run this command to permit access:
  sudo setsebool -P httpd_enable_homedirs 1
If this is not the case, check all file permissions along the path."""
        raise KeyError(msg % (fname, ))
    # if not provided, infer the app name from fname
    d['app'] = app or path.splitext(path.basename(fname))[0]

    return d
    
def build_url(**kwargs):
    """
    Build the database URL for either sqlite or any other database.
    """
    if 'db_file' in kwargs:
        return '%(db_type)s:///%(db_file)s' % kwargs
    return '%(db_type)s://%(db_user)s:%(db_password)s@%(db_host)s:%(db_port)s/%(db_name)s' % kwargs

