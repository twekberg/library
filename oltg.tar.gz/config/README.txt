Configuration files are located in the subdirectories here. The idea is that if
you are working on a particular host, you may need a different configuration
file for that host. Also, if you have a special configuration (sudo make
package APP=oltg_nh) it will be selected independently of the default one.
