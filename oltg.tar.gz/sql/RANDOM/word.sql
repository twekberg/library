-- Word search, with parents and grandparents.
SELECT oltg.mnemonic,
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total'
FROM oltg
LEFT OUTER JOIN cross_references c ON oltg.mnemonic = c.mnemonic
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
  WHERE
  (MATCH(oltg.mnemonic, oltg.name, oltg.lab_name, oltg.cerner_name, oltg.epic_name)
   AGAINST ('Sodium' IN BOOLEAN MODE)
   OR
   MATCH( c.cross_reference) AGAINST ('Sodium' IN BOOLEAN MODE)
  )
  AND (oltg.order_flag = 'Y' OR oltg.order_flag IS NULL)
GROUP BY oltg.mnemonic
UNION DISTINCT
-- Go up one level. Get T -> B and T -> P.
SELECT oltg.mnemonic,
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total'
FROM oltg
JOIN component_tests c ON oltg.mnemonic = c.mnemonic
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
WHERE c.component_mnemonic IN 
  (SELECT o2.mnemonic
   FROM oltg o2
   LEFT OUTER JOIN cross_references c2 ON o2.mnemonic = c2.mnemonic
   WHERE
   MATCH(o2.mnemonic, o2.name, o2.lab_name, o2.cerner_name, o2.epic_name)
   AGAINST ('Sodium' IN BOOLEAN MODE)
   OR
   MATCH( c2.cross_reference) AGAINST ('Sodium' IN BOOLEAN MODE)
  )
  AND (oltg.order_flag = 'Y' OR oltg.order_flag IS NULL)
UNION DISTINCT
-- Going from parent batteries to grandparent packages: T -> B -> P
SELECT oltg.mnemonic,
  if(oltg.name IS NOT NULL AND oltg.name != '',oltg.name, oltg.lab_name) AS 'name',
  if(oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '', oltg.specimen_type, '') AS 'specimen_type',
  ifnull(t.total,0) AS 'total'
FROM oltg
JOIN component_tests c ON oltg.mnemonic = c.mnemonic
LEFT OUTER JOIN dept_tally_view t ON oltg.mnemonic = t.mnemonic
WHERE c.component_mnemonic IN
  (SELECT distinct(o2.mnemonic)
   FROM component_tests c2
   JOIN oltg o2 ON o2.mnemonic = c2.mnemonic
   WHERE c2.component_mnemonic IN 
     (SELECT o3.mnemonic
      FROM oltg o3
      LEFT OUTER JOIN cross_references c3 ON o3.mnemonic = c3.mnemonic
      WHERE
      MATCH(o3.mnemonic, o3.name, o3.lab_name, o3.cerner_name, o3.epic_name)
      AGAINST ('Sodium' IN BOOLEAN MODE)
      OR
      MATCH( c3.cross_reference) AGAINST ('Sodium' IN BOOLEAN MODE)
     )
     AND o2.tbp_type = 'B'
  )
  AND (oltg.order_flag = 'Y' OR oltg.order_flag IS NULL)
ORDER BY 4 DESC,1;
