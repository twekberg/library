"""
Generate a static HTML page for each Public and Staff Only test.

The idea is that http://menu.labmed.washington.edu/search/MNEMONIC goes to
one of these pages instead of going to the OLTG.
These pages are stand-alone, and can be place anywhere.

Generates an index page for Public and Staff Only since search isn't supported.
"""

import argparse
import os
import os.path
import shutil
import sys

import oltg.models
import oltg.controllers.collectors as collectors
import oltg.subcommands
import oltg.models.object_queries as object_queries
from oltg.controllers.display import display_page
from oltg.templates.StaticIndex import StaticIndex
from oltg.controllers.common import common_namespace
from oltg.models.messages import Messages


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('outdir', action='store', nargs='?',
                        help="""What directory to place the HTML files.
The css, image and js files go into a subdirectory. Default: %(default)s""",
                        default='/var/www/html/mastermu/static_oltg')
    parser.add_argument('--no-css', action="store_true", default=False,
                        help="Don't copy CSS files. Default: %(default)s")
    parser.add_argument('--no-images', action="store_true", default=False,
                        help="Don't copy image files. Default: %(default)s")
    parser.add_argument('--no-js', action="store_true", default=False,
                        help="Don't copy javascript files. Default: %(default)s")
    parser.add_argument('--no-html', action="store_true", default=False,
                        help="Don't generate HTML files for the individual tests. Use this to generate only the index pages. Default: %(default)s")
    parser.add_argument('--no-index', action="store_true", default=False,
                        help="Don't generate the two index files. Use this to only generate HTML files for the individual tests. Default: %(default)s")
    parser.add_argument('-p', '--public-mnemonics', nargs = '*',
                        help = 'optional list of public lab mnemonics. If not specified pages are generated for all public tests.',
                        default = None)
    parser.add_argument('-s', '--staff-mnemonics', nargs = '*',
                        help = 'optional list of Staff Only lab mnemonics. If not specified pages are generated for all Staff Only tests.',
                        default = None)

def action(args):
    """
    Generate individual HTML pages for public and staff only tests.
    """
    # Turn the negatives into positives.
    gen_css    = not args.no_css
    gen_images = not args.no_images
    gen_js     = not args.no_js
    gen_html   = not args.no_html
    gen_index  = not args.no_index
    session = None
    try:
        check_directories(args.outdir)
        if gen_css:
            copy_css(args.outdir)
        if gen_images:
            copy_dot_files(args.outdir, 'images/')
        if gen_js:
            copy_dot_files(args.outdir, 'js/')
        if gen_html or gen_index:
            (config_dict, session, engine) = oltg.subcommands.init_args(args)
            messages = Messages(session, 'static pages')
            messages.store('started')
            oltg.models.object_query = object_queries.ProdObjectQueries(session, config_dict['db_type'])
            if args.public_mnemonics:
                public_mnemonics = [m.upper() for m in args.public_mnemonics]
            else:
                public_mnemonics = get_public_mnemonics(session)
            public_mnemonics = get_component_mnemonics(session, public_mnemonics)
            if args.staff_mnemonics:
                staff_mnemonics = [m.upper() for m in args.staff_mnemonics]
            else:
                staff_mnemonics = get_staff_mnemonics(session)
            staff_mnemonics = get_component_mnemonics(session, staff_mnemonics)
            if gen_index:
                render_index(args.outdir, config_dict, public_mnemonics, 'index')
                render_index(args.outdir, config_dict, staff_mnemonics, 'staff', staff=True)
            if gen_html:
                environ = dict(SESSION = session,
                               HTTP_USER_AGENT = 'Chrome 15.0',
                               REMOTE_USER = 'subcommand',
                               SCRIPT_NAME = 'oltg',
                               CONFIG = config_dict,
                               STATIC_PAGE = True, # Used to not fill up the log
                               show_sidebar = False,
                               show_footer = False,
                               )
                environ['oltg.parameters'] = {'print_mode': True}
                for mnemonic in public_mnemonics:
                    render_mnemonic(mnemonic, args.outdir, environ)
                environ['STAFF_ONLY'] = True
                # Render the pages that are only viewable from the staff only page.
                for mnemonic in set(staff_mnemonics) - set(public_mnemonics):
                    render_mnemonic(mnemonic, args.outdir, environ)
    finally:
        if session:
            messages.store('completed', True)
            oltg.models.release_session(session, engine)


def check_directories(out_dir):
    """
    Make sure the needed directories have been created.
    """
    for p in ['', '/css', '/images', '/js']:
        path = out_dir + p
        if not os.path.exists(path):
            os.mkdir(path)


def copy_css(out_dir):
    """
    Copy the existing css files in css/.
    """
    for css in os.listdir('css/'):
        if os.path.splitext(css)[-1] == '.css':
            shutil.copyfile(os.path.join('css/', css), os.path.join(out_dir, 'css/', css))


def copy_dot_files(out_dir, in_dir):
    """
    Copy the existing dot files from in_dir.
    """
    for dot_file in os.listdir(in_dir):
        if '.' in dot_file:
            shutil.copyfile(os.path.join(in_dir, dot_file), os.path.join(out_dir, in_dir, dot_file))


def get_public_mnemonics(session):
    sql = """SELECT mnemonic FROM mastermu_oltg.oltg WHERE security_flag = 'E' ORDER BY 1"""
    # Grab the first element (the mnemonic) from every row.
    return [x[0] for x in list(session.execute(sql))]


def get_staff_mnemonics(session):
    sql = """SELECT mnemonic FROM mastermu_oltg.oltg WHERE security_flag != 'N' ORDER BY 1"""
    # Grab the first element (the mnemonic) from every row.
    return [x[0] for x in list(session.execute(sql))]


def get_component_mnemonics(session, mnemonics):
    """
    Get a list of mnemonics that are either components of the specified
    mnemonics, or are subcomponents of the components.
    This is needed in case the user clicks on a subcomponent or component.
    """
    sql = """SELECT distinct(component_mnemonic) FROM mastermu_oltg.component_tests WHERE mnemonic IN('%s')"""
    components    = [x[0] for x in list(session.execute(sql % ("','".join(mnemonics),)))]
    subcomponents = [x[0] for x in list(session.execute(sql % ("','".join(components),)))]
    return sorted(list(set(mnemonics + components + subcomponents)))

def get_mnemonic_detail(mnemonic):
    """
    Get the mnemonic detail to show in the index.
    """
    o = oltg.models.object_query.get_oltg(mnemonic)
    if o:
        return [mnemonic,
                o.name or o.lab_name,
                # Combine the cerner names in the template.
                oltg.models.object_query.get_cerner_names(mnemonic),
                ', '.join(collectors.cross_references(mnemonic))]
    else:
        return [mnemonic,
                '', 
                oltg.models.object_query.get_cerner_names(mnemonic),
                ', '.join(collectors.cross_references(mnemonic))]


def render_index(out_dir, config_dict, mnemonics, index_name, staff=False):

    """
    Output the index.html page.
    This page contains a static listing of links to all pages.
    """
    allow_robot = True
    other_text = ''
    other_loc = ''
    if staff:
        allow_robot = False
        other_loc= 'index.html'
        other_text = 'Public Index'
    with open('%s/%s.html' % (out_dir, index_name), 'w') as out:
        mnemonic_data = [get_mnemonic_detail(mnemonic) for mnemonic in mnemonics]
        namespace = common_namespace(dict(STAFF_ONLY=staff), config_dict)
        
        data = dict(
            mnemonics = mnemonic_data,
            other_loc = other_loc,
            other_text = other_text,
            allow_robot = allow_robot,
            )
        out.write(str(StaticIndex(searchList = [data, namespace])))


def start_response(a,b):
    pass


def render_mnemonic(mnemonic, out_dir, environ):
    """
    Render the HTML code for a single mnemonic.
    """
    environ['oltg.parameters']['mnemonic'] =  mnemonic
    with open('%s/%s.html' % (out_dir, mnemonic), 'w') as out:
        out.write('\n'.join(display_page(environ, start_response, None)))
