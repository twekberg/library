//  @(#) $Id:  $  

//  *********************************************************************
// 
//    Copyright (c) 2011 University of Washington Laboratory Medicine
//    All Rights Reserved
// 
//    The information contained herein is confidential to and the
//    property of University of Washington Laboratory Medicine and is
//    not to be disclosed to any third party without prior express
//    written permission of University of Washington Laboratory Medicine.
//    University of Washington Laboratory Medicine, as the
//    author and owner under 17 U.S.C. Sec. 201(b) of this work made
//    for hire, claims copyright in this material as an unpublished 
//    work under 17 U.S.C. Sec.s 102 and 104(a)   
// 
//  *********************************************************************


// Helper code to manage a list of values.
// Use addRow when there is a single value (e.g. a component).
// Use multipleAddRow when there is more than a single value (e.g. a URL and text)
// Tested with FireFox 7, Internet Explorer 6 and 9, Chrome and Safari.

// It is assume that the JS variable static_content_home is set to the home page.
// For example: '/mastermu/oltg/'.

// addRow - ad a new row to a table.
//   name - the name of the attribute (e.g. 'cross_reference').
//   value - the text value to add.
// adds the vale and an X icon to allow one to delete the vale.
function addRow(name, value) {
    var tableID = name + '_id'
    var table = document.getElementById(tableID);
    var row = table.insertRow(table.rows.length);
    var i_cell = 0;
    var cell = row.insertCell(i_cell++);
    var element = document.createElement("img");
    element.src = static_content_home + "images/delete-icon-16x16.jpg";
    element.alt = "Delete";
    element.title = 'Delete ' + value;
    element.onclick = function(e) {
        var target;
        if (!e) {
            // IE
            target = window.event.srcElement;
        } else {
            // FF
            target = e.currentTarget;
        }
        deleteRow(tableID, target.parentNode.parentNode);
    }
    cell.colSpan = 2;
    cell.appendChild(element);
 
    element = document.createElement("span");
    element.innerHTML = '&nbsp;' + value;
    cell.appendChild(element);

    // Value for <form>.
    //cell = row.insertCell(i_cell++);
    element = document.createElement("input");
    element.type = "hidden";
    element.name = name;
    element.value = value;
    cell.appendChild(element); 
}
 

// Delete a row. Normally not called by user-written code.
//   tableID - the table's ID attribute.
//   row_element - the HTMLElement object to delete from the table.
function deleteRow(tableID, row_element) {
    try {
        var table = document.getElementById(tableID);
        var rowCount = table.rows.length;
 
        for(var i=0; i<rowCount; i++) {
            var row = table.rows[i];
            if (row == row_element) {
                table.deleteRow(i);
                break;
            }
        }
    }catch(e) {
        alert(e);
    }
}


// When several form elements have the same name, one needs special code like
// this to retrieve the values.
// This works fine for URLs since RFC 2396 (section 2.4.3) says that # is an
// excluded character.
// The return value is an array.
function getMultipleSameValues(elements) {
    values = new Array();
    for(var i=0; i<elements.length; i++) {
        values.push(elements.item(i).value);
    }
    return values;
}


function multipleAddRow(name, values, value_names) {
    if (values.length != value_names.length) {
        alert('Internal error in multipleAddRow: values.length != value_names.length: '
              + values.length + ' != ' + value_names.length
              + '\nvalues=[' + values.join(', ') + ']'
              + '\nvalue_names=[' + value_names.join(', ') + ']')
    }
    var tableID = name + "_id";
    var table = document.getElementById(tableID);
    var row = table.insertRow(table.rows.length);
    var i_cell = 0;                     // Place to incert new cell
    var cell = row.insertCell(i_cell++);
    var element = document.createElement("img");
    element.src = static_content_home + "images/delete-icon-16x16.jpg";
    element.alt = "Delete";
    element.title = 'Delete ' + values.join(', ');
    element.onclick = function(e) {
        var target;
        if (!e) {
            // IE
            target = window.event.srcElement;
        } else {
            // FF
            target = e.currentTarget;
        }
        deleteRow(tableID, target.parentNode.parentNode);
    }
    cell.appendChild(element);

    cell = row.insertCell(i_cell++);
    cell.innerHTML = values.join('<br>');

    // Value for <form>.
    for (var j=0; j<value_names.length; j++) {
        cell = row.insertCell(i_cell++);
        element = document.createElement("input");
        element.type = "hidden";
        element.name = name + '_' + value_names[j].toLowerCase();
        element.value = values[j];
        cell.appendChild(element);
    }
}
