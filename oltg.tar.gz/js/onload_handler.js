/* There are fragments of javascript that want something to happen when the page is loaded.
   Unfortunately only one value can be assigned to window.onload and it must be a function.

   This code allows mulitple actions to occur after the page is loaded.
*/

var onload_handlers = [];

function onload_handler() {
    var i;
    for(i=0; i<onload_handlers.length; i++) {
        onload_handlers[i]()
    }
}
window.onload = onload_handler;

function add_onload_handler(new_handler) {
    var i;
    for(i=0; i<onload_handlers.length; i++) {
        if (new_handler == onload_handlers[i]) {
            return;
        }
    }
    onload_handlers[onload_handlers.length] = new_handler;
}
