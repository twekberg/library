/*
Table sorting script  by Joost de Valk, check it out at http://yoast.com/articles/sortable-table/.
Based on a script from http://www.kryogenix.org/code/browser/sorttable/.
Distributed under the MIT license: http://www.kryogenix.org/code/browser/licence.html .

Copyright (c) 1997-2007 Stuart Langridge, Joost de Valk.

Version 1.5.7
*/

/* You can change these values */
var europeandate = false;
var alternate_row_colors = true;

/* Optional secondary sort column. -1 disables it.*/
var SECONDARY_SORT_COLUMN_INDEX = -1;

/* Don't touch these. */
var SORT_COLUMN_INDEX;
var thead = false;

/* Function to call to perform the secondary sort. */
var secondary_sort_fn = null;

var SORT_DIR = "down";


/* Don't change anything below this unless you know what you're doing */
function alternate(table) {
	var tableBodies, tableRows, i, j;
	// Take object table and get all it's tbodies.
	tableBodies = table.getElementsByTagName("tbody");
	// Loop through these tbodies
	for (i = 0; i < tableBodies.length; i++) {
		// Take the tbody, and get all it's rows
		tableRows = tableBodies[i].getElementsByTagName("tr");
		// Loop through these rows
		// Start at 1 because we want to leave the heading row untouched
		for (j = 0; j < tableRows.length; j++) {
			// Check if j is even, and apply classes for both possible results
			if ((j % 2) == 0) {
				if (tableRows[j].className.indexOf('odd') != -1) {
					tableRows[j].className = tableRows[j].className.replace('odd', 'even');
				} else {
					if (tableRows[j].className.indexOf('even') == -1) {
						tableRows[j].className += "_even";
					}
				}
			} else {
				if (tableRows[j].className.indexOf('even') != -1) {
					tableRows[j].className = tableRows[j].className.replace('even', 'odd');
				} else {
					if (tableRows[j].className.indexOf('odd') == -1) {
						tableRows[j].className += "_odd";
					}
				}
			} 
		}
	}
}

function mark_sorted_column(table) {
    var tableBodies, tableRows, tableCols, colClass, i, j, even_odd;
    // Take object table and get all it's tbodies.
    tableBodies = table.getElementsByTagName("tbody");
    // Loop through these tbodies
    for (i = 0; i < tableBodies.length; i++) {
        // Take the tbody, and get all it's rows
        tableRows = tableBodies[i].getElementsByTagName("tr");
        // Loop through these rows
        // Start at 1 because we want to leave the heading row untouched
        for (j = 1; j < tableRows.length; j++) {
            even_odd = (j % 2) == 0 ? 'even' : 'odd';
            tableCols = tableRows[j].getElementsByTagName("td");
            for(k = 0; k < tableCols.length; k++) {
                colClass = 'search_' + DATA_COLUMN_CLASS_NAMES[k] + '_' +
                    BACKGROUND_COLOR + '_' + ((k == SORT_COLUMN_INDEX) ? 'sorted' : even_odd);
                tableCols[k].className = colClass;
            }
        }
    }
}

function ts_getInnerText(el) {
	var str, cs, l, i;
	if (typeof el == "string") {
		return el;
	}
	if (typeof el == "undefined") {
		return el;
	}
	if (el.innerText) {
		return el.innerText;	//Not needed but it is faster
	}
	str = "";
	
	cs = el.childNodes;
	l = cs.length;
	for (i = 0; i < l; i++) {
		switch (cs[i].nodeType) {
		case 1: //ELEMENT_NODE
			str += ts_getInnerText(cs[i]);
			break;
		case 3:	//TEXT_NODE
			str += cs[i].nodeValue;
			break;
		}
	}
	return str;
}

// IE changes &nbsp; in the HTML file into a blank (character code 32) for some
// reason. This code puts it back. Once it is back it sticks so we don't have
// to do it again later on in the code in ts_resortTable.
function put_back_nbsp(s) {
	return s.replace(/ /g, '&nbsp');
}

function ts_makeSortable(t) {
	var firstRow, i, cell, txt;
	if (t.rows && t.rows.length > 0) {
		if (t.tHead && t.tHead.rows.length > 0) {
			firstRow = t.tHead.rows[t.tHead.rows.length - 1];
			thead = true;
		} else {
			firstRow = t.rows[0];
		}
	}
	if (!firstRow) {
		return;
	}
	// We have a first row: assume it's the header, and make its contents clickable links
	for (i = 0; i < firstRow.cells.length; i++) {
		cell = firstRow.cells[i];
		txt = ts_getInnerText(cell);
		if (cell.className != "unsortable" && cell.className.indexOf("unsortable") == -1) {
			cell.innerHTML = '<a href="#" class="sortheader" onclick="ts_resortTable(this, ' + i + ');return false;"><span class="sortarrow" sortdir="down">' + put_back_nbsp(trim(txt)) + '&nbsp;&nbsp;&darr;</span></a>';
		}
	}
	if (alternate_row_colors) {
		alternate(t);
	}
}

function sortables_init() {
	var tables, ti, thisTbl;
	// Find all tables with class sortable and make them sortable
	// The previous version required that the table also have an ID attribute.
	// I got rid of that test since the class name is enough.
	if (!document.getElementsByTagName) {
		return;
	}
	tables = document.getElementsByTagName("table");
	for (ti = 0; ti < tables.length; ti++) {
		thisTbl = tables[ti];
		if (((' ' + thisTbl.className + ' ').indexOf("sortable") != -1)) {
			ts_makeSortable(thisTbl);
		}
	}
}

function getParent(el, pTagName) {
	if (el == null) {
		return null;
	} else if (el.nodeType == 1 && el.tagName.toLowerCase() == pTagName.toLowerCase()) {
		return el;
	} else {
		return getParent(el.parentNode, pTagName);
	}
}

function trim(s) {
        if (s == null) {
          return s;
        }
	return s.replace(/^\s+|\s+$/g, "");
}

function ts_sort_caseinsensitive(a, b) {
	var aa, bb;
        var sort_index, is_primary_sort;
        if (arguments.length == 2) {
            sort_index = SORT_COLUMN_INDEX;
            is_primary_sort = true;
        } else {
            sort_index = arguments[2];
            is_primary_sort = false;
        }
	aa = ts_getInnerText(a.cells[sort_index]).toLowerCase();
	bb = ts_getInnerText(b.cells[sort_index]).toLowerCase();
	if (aa == bb) {
                if (SECONDARY_SORT_COLUMN_INDEX >= 0 && is_primary_sort) {
                    var keep_asc = SORT_DIR == "down" ? -1 : 1;
                    return keep_asc * secondary_sort_fn(a, b, SECONDARY_SORT_COLUMN_INDEX);
                } else {
		    return 0;
                }
	}
	if (aa < bb) {
		return -1;
	}
	return 1;
}

// Not used, but here for completeness.
function ts_sort_default(a, b) {
	var aa, bb;
        var sort_index;
        if (arguments.length == 2) {
            sort_index = SORT_COLUMN_INDEX;
        } else {
            sort_index = arguments[2];
        }
        aa = ts_getInnerText(a.cells[sort_index]);
	bb = ts_getInnerText(b.cells[sort_index]);
	if (aa == bb) {
                if (SECONDARY_SORT_COLUMN_INDEX >= 0) {
                    var keep_asc = SORT_DIR == "down" ? -1 : 1;
                    return keep_asc * secondary_sort_fn(a, b, SECONDARY_SORT_COLUMN_INDEX);
                } else {
		    return 0;
                }
	}
	if (aa < bb) {
		return -1;
	}
	return 1;
}

function clean_num(str) {
	str = str.replace(new RegExp(/[^\-?0-9.]/g), "");
	return str;
}

function ts_sort_numeric(a, b) {
	var aa, bb;
        var sort_index;
        if (arguments.length == 2) {
            sort_index = SORT_COLUMN_INDEX;
        } else {
            sort_index = arguments[2];
        }
        aa = clean_num(ts_getInnerText(a.cells[sort_index]));
	bb = clean_num(ts_getInnerText(b.cells[sort_index]));

        ret = compare_numeric(aa, bb);
        if (ret == 0) {
                if (SECONDARY_SORT_COLUMN_INDEX >= 0) {
                    var keep_asc = SORT_DIR == "down" ? -1 : 1;
                    return keep_asc * secondary_sort_fn(a, b, SECONDARY_SORT_COLUMN_INDEX);
                } else {
		    return 0;
                }
        }
	return ret;
}

function compare_numeric(a, b) {
	var aa, bb;
	aa = parseFloat(a);
	aa = (isNaN(aa) ? 0 : aa);
	bb = parseFloat(b);
	bb = (isNaN(bb) ? 0 : bb);
	return aa - bb;
}

function sort_date(date) {	
	var mt, mtstr, dt, is_fmt1, yr;
	// y2k notes: two digit years less than 50 are treated as 20XX, greater than 50 are treated as 19XX
	dt = "00000000";
	if (date.length == 11) {
		// 01234567890
		// dd-mmm-yyyy
		mtstr = date.substr(3, 3);
		mtstr = mtstr.toLowerCase();
		switch (mtstr) {
		case "jan": mt = "01"; break;
		case "feb": mt = "02"; break;
		case "mar": mt = "03"; break;
		case "apr": mt = "04"; break;
		case "may": mt = "05"; break;
		case "jun": mt = "06"; break;
		case "jul": mt = "07"; break;
		case "aug": mt = "08"; break;
		case "sep": mt = "09"; break;
		case "oct": mt = "10"; break;
		case "nov": mt = "11"; break;
		case "dec": mt = "12"; break;
		// default: mt = "00";
		}
		dt = date.substr(7, 4) + mt + date.substr(0, 2);
		return dt;
	} else if (date.length == 10) {
		// 0123456789    0123456789
		// mm-dd-yyyy or yyyy-mm-dd
		// fmt1          fmt2
		is_fmt1 = "0123456789".indexOf(date.substr(2, 1)) == -1;
		if (europeandate == false) {
			if (is_fmt1) {
				dt = date.substr(6, 4) + date.substr(0, 2) + date.substr(3, 2);
			} else {
				dt = date.substr(0, 4) + date.substr(5, 2) + date.substr(8, 2);
			}
		} else {
			//        0123456789    0123456789
			// Either dd-mm-yyyy or yyyy-dd-mm
			//        fmt1          fmt2
			if (is_fmt1) {
				dt = date.substr(6, 4) + date.substr(3, 2) + date.substr(0, 2);
			} else {
				dt = date.substr(0, 4) + date.substr(8, 2) + date.substr(5, 2);
			}
		}
		return dt;
	} else if (date.length == 8) {
		// 01234567
		// mm-dd-yy
		yr = date.substr(6, 2);
		if (parseInt(yr, 10) < 50) { 
			yr = '20' + yr; 
		} else { 
			yr = '19' + yr; 
		}
		if (europeandate == true) {
			dt = yr + date.substr(3, 2) + date.substr(0, 2);
		} else {
			dt = yr + date.substr(0, 2) + date.substr(3, 2);
		}
		return dt;
	}
	return dt;
}

function ts_sort_date(a, b) {
	var dt1, dt2;
        var sort_index;
        if (arguments.length == 2) {
            sort_index = SORT_COLUMN_INDEX;
        } else {
            sort_index = arguments[2];
        }
        dt1 = sort_date(ts_getInnerText(a.cells[sort_index]));
        dt2 = sort_date(ts_getInnerText(b.cells[sort_index]));
	
	if (dt1 == dt2) {
                if (SECONDARY_SORT_COLUMN_INDEX >= 0) {
                    var keep_asc = SORT_DIR == "down" ? -1 : 1;
                    return keep_asc * secondary_sort_fn(a, b, SECONDARY_SORT_COLUMN_INDEX);
                } else {
		    return 0;
                }
	}
	if (dt1 < dt2) { 
		return -1;
	}
	return 1;
}

function is_numeric(a) {
	// x80 = 128. = &euro;
	// xDB = 218. = &Ucirc;
	// xA2 = 216. = &cent;
	// xA3 = 217. = &pound;
	// xA5 = 219. = &yen;
	// xB4 = 180. = &acute;
	return a.match(/^-?[\x80\xDB\xA2\xA3\xA5\xB4$]\d/) || a.match(/^-?(\d+[,\.]?)+(E[\-+][\d]+)?%?$/);
}

function is_date(d) {
	return (d.match(/^\d\d([\/\.\-])[a-zA-z][a-zA-Z][a-zA-Z]\1\d\d\d\d$/) ||
	        d.match(/^\d\d([\/\.\-])\d\d\1\d\d\d{2}?$/) ||
	        d.match(/^\d{4}([\/\.\-])\d\d\1\d\d$/));
}


function determine_column_type(t, column) {
    var n_data_rows;
    var n_numeric, n_empty, n_dates, n_rows;
    // Had to make this go through all of the rows for this column to
    // determine the data type. The reason for this is that some test
    // mnemonics look like a number, and generally sort to the top. Just
    // looking at the first data row is not enough. That is what the old
    // code did.
    n_numeric = 0;
    n_empty = 0;
    n_dates = 0;
    n_rows = t.tBodies[0].rows.length;
    n_data_rows = 0;

    // Start at 1 to skip over the column headers.
    for (i = 1; i < n_rows; i++) {
	n_data_rows++;
	itm = ts_getInnerText(t.tBodies[0].rows[i].cells[column]);
	itm = trim(itm);
        if (itm == null) {
            // Skip empty values.
            continue;
        }
	if (itm.substr(0, 4) == "&lt;!--" || itm.length == 0) {
	    itm = "";
	}
	if (itm == '') {
	    n_empty++;
	} else if (is_date(itm)) {
	    n_date++;
	} else if (is_numeric(itm)) {
	    n_numeric++;
	} else {
	    // Neither empty, numeric, nor date. Must be alpha.
	    // No need to look any further.
	    n_numeric = n_rows + 1;
	    n_date = n_rows + 1;
	    break;
	}
    }
    if (n_empty == n_data_rows) {
	// All are empty - nothing to sort.
	return null;
    }
    if (n_dates + n_empty == n_data_rows) {
	return ts_sort_date;
    } else if (n_numeric + n_empty == n_data_rows) {
	return ts_sort_numeric;
    } else {
	return ts_sort_caseinsensitive;
    }
}


function ts_resortTable(lnk, clid) {
	var span, span_all_text, span_text, ci, spantext, td, column, t, itm;
	var i, j, k, firstRow, newRows, allspans, sortfn, ARROW, new_sort_dir;
	var n_rows;
	for (ci = 0; ci < lnk.childNodes.length; ci++) {
		if (lnk.childNodes[ci].tagName && lnk.childNodes[ci].tagName.toLowerCase() == 'span') {
			span = lnk.childNodes[ci];
		}
	}
	spantext = ts_getInnerText(span);
	td = lnk.parentNode;
	column = clid || td.cellIndex;
	t = getParent(td, 'TABLE');
	// Work out a type for the column
	if (t.rows.length <= 1) {
		return;
	}
	itm = "";
        if (SECONDARY_SORT_COLUMN_INDEX >= 0) {
            secondary_sort_fn = determine_column_type(t, SECONDARY_SORT_COLUMN_INDEX);
        }
        sortfn = determine_column_type(t, column);
        if (sortfn === null) {
	    // All are empty - nothing to sort.
            return;
        }

	SORT_COLUMN_INDEX = column;
	firstRow = [];
	newRows = [];
	for (k = 0; k < t.tBodies.length; k++) {
		for (i = 0; i < t.tBodies[k].rows[0].length; i++) { 
			firstRow[i] = t.tBodies[k].rows[0][i]; 
		}
	}
	for (k = 0; k < t.tBodies.length; k++) {
		if (!thead) {
			// Skip the first row
			for (j = 1; j < t.tBodies[k].rows.length; j++) { 
				newRows[j - 1] = t.tBodies[k].rows[j];
			}
		} else {
			// Do NOT skip the first row
			for (j = 0; j < t.tBodies[k].rows.length; j++) { 
				newRows[j] = t.tBodies[k].rows[j];
			}
		}
	}
	SORT_DIR = span.getAttribute("sortdir");
	newRows.sort(sortfn);
        span_all_text = span.innerHTML;
        span_text = span_all_text.substring(0, span_all_text.lastIndexOf('&nbsp;&nbsp;'));
	if (span.getAttribute("sortdir") == 'down') {
		ARROW = span_text + '&nbsp;&nbsp;&darr;';
		new_sort_dir = 'up';
	} else {
		newRows.reverse();
		ARROW = span_text + '&nbsp;&nbsp;&uarr;';
		new_sort_dir = 'down';
	} 
	// We appendChild rows that already exist to the tbody, so it moves them rather than creating new ones
	// don't do sortbottom rows
	for (i = 0; i < newRows.length; i++) { 
		if (!newRows[i].className || (newRows[i].className && (newRows[i].className.indexOf('sortbottom') == -1))) {
			t.tBodies[0].appendChild(newRows[i]);
		}
	}
	// do sortbottom rows only
	for (i = 0; i < newRows.length; i++) {
		if (newRows[i].className && (newRows[i].className.indexOf('sortbottom') != -1)) {
			t.tBodies[0].appendChild(newRows[i]);
		}
	}
	// Delete any other arrows there may be showing
	allspans = document.getElementsByTagName("span");
	for (ci = 0; ci < allspans.length; ci++) {
		if (allspans[ci].className == 'sortarrow') {
			if (getParent(allspans[ci], "table") == getParent(lnk, "table")) { // in the same table as us?
			        span_all_text = allspans[ci].innerHTML;
			        span_text = span_all_text.substring(0, span_all_text.lastIndexOf('&nbsp;&nbsp;'));
				allspans[ci].innerHTML = span_text + '&nbsp;&nbsp;&nbsp;';
				allspans[ci].setAttribute('sortdir', 'up');
			}
		}
	}		
	span.innerHTML = ARROW;
	span.setAttribute('sortdir', new_sort_dir);
        mark_sorted_column(t)
	alternate(t);
}

function addEvent(elm, evType, fn, useCapture) {
	// addEvent and removeEvent
	// cross-browser event handling for IE5+,	NS6 and Mozilla
	// By Scott Andrew

	var r;
	if (elm.addEventListener) {
		elm.addEventListener(evType, fn, useCapture);
		return true;
	} else if (elm.attachEvent) {
		elm['e' + evType + fn] = fn;
		elm[evType + fn] = function () {elm['e' + evType + fn](window.event); };
		r = elm.attachEvent("on" + evType, elm[evType + fn]);
		//	var r = elm.attachEvent("on" + evType, fn);
		return r;
	} else {
		alert("Handler on" + evType + "could not be added,");
	}
}

addEvent(window, "load", sortables_init);
