#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Controller for the Cerner synonym page: CernerNames.tmpl
"""

from labmed.util.pluralize import just_pluralize

import oltg
import oltg.controllers.collectors as collectors
from oltg.controllers import app
import oltg.models
import oltg.models.access_log as access_log
from oltg.templates.CernerNames import CernerNames


def cerner(environ, start_response, logger):
    """Allow an edit user to change some cerner display parameters."""
    session = environ.get('SESSION', None)
    parameters = environ[app + '.parameters']
    mnemonic = parameters.get('mnemonic', '')
    action = parameters.get('action', '')
    access_log.record_access(session, staff_only=environ.get('STAFF_ONLY', False),
                             edit_mode=environ.get('EDIT_MODE', False),
                             user=environ.get('REMOTE_USER', 'Unknown'),
                             ip_address=environ.get('REMOTE_ADDR', 'Unknown'),
                             action='cerner edit',
                             details='mnemonic=%s, action=%s' % (mnemonic, action))
    namespace = make_namespace(session, mnemonic, action, parameters)
    # Retain the search parameters.
    for parameter in ('search_type', 'search_cross_reference', 'search_text', 'search_as_component'):
        namespace[parameter] = parameters.get(parameter, '')
    namespace['search_staff_only'] = environ.get('STAFF_ONLY', False)
    namespace['edit_mode']         = environ.get('EDIT_MODE', False)
    namespace['home_page']         = environ.get('SCRIPT_NAME', '').rstrip('/') or None
    namespace['http_protocol']     = environ.get('wsgi.url_scheme', 'http')
    namespace['print_mode']        = parameters.get('print_mode', '')
    namespace['version'] = oltg.__version__
    start_response('200 OK', [('Content-Type', 'text/html')])
    t = CernerNames(searchList = [namespace])
    return [str(t.respond())]


def make_namespace(session, mnemonic, action, parameters):
    """
    Retrieve the cerner details for mnemonic. Only details related specifically to the
    test are shown here. The caller can add other details related to the
    current settings.

    Returns a namespace map suitable for a template.
    """
    data = oltg.models.object_query.get_cerner_name_details(mnemonic.upper())
    if data:
        n_synonym_displays_changed = 0;
        if action == 'cerner_edit':
            # See if any of the 'show' values changed.
            for synonym in data:
                if bool(parameters.get('synonym_id_%s' % (synonym['cerner_synonym_id'],), '')) != synonym['show']:
                    synonym['show'] = not synonym['show']
                    sd = oltg.models.object_query.get_cerner_synonym_display(synonym['cerner_synonym_id'])
                    sd.show = synonym['show']
                    n_synonym_displays_changed += 1
            if n_synonym_displays_changed > 0:
                session.commit()
        namespace = {'primary': data[0],
                     'synonyms': data[1:],
                     'show_cerner': True,
                     'message': ('%d cerner show %s changed' % (n_synonym_displays_changed, just_pluralize(n_synonym_displays_changed, 'setting'))) if n_synonym_displays_changed>0 else '',
                     }
    else:
        namespace = {'show_cerner': False,
                     'message': 'This mnemonic (%s) has no corresponding cerner order' % (mnemonic,),
                     }
    namespace['mnemonic'] = mnemonic
    return namespace
