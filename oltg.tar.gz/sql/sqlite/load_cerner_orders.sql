--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2012 University of Washington Laboratory Medicine
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Laboratory Medicine and is
--    not to be disclosed to any third party without prior express
--    written permission of University of Washington Laboratory Medicine.
--    University of Washington Laboratory Medicine, as the
--    author and owner under 17 U.S.C. Sec. 201(b) of this work made
--    for hire, claims copyright in this material as an unpublished 
--    work under 17 U.S.C. Sec.s 102 and 104(a)   
-- 
--  *********************************************************************


-- This is a dummy cerner_orders row that causes the OLTG to display
-- 'orderable by lab only' for the cerner detail.

INSERT INTO cerner_orders
  (code, lab_mnemonic, primary_name, primary_name_hidden, active, updated_date)
  VALUES(0, 'ANY', 'orderable by lab only', 0, 1, '2000-01-01 00:00:00.000');
INSERT INTO cerner_synonyms
  (cerner_order_code, name, is_primary, updated_date)
  VALUES(0, 'orderable by lab only', 1, '2000-01-01 00:00:00.000');
INSERT INTO cerner_synonym_displays
  (cerner_synonym_id, show) VALUES (last_insert_rowid(), 1);
