#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Controller for the edited test workflow.

For each test selected by the user:
  The test's table rows are pushed from the staging tables to the public tables.
  The oltg_staging.was_changed boolean is set to False
  The json file for the test is regenerated
"""

import oltg
import oltg.models
from oltg.models.create_models import (AuditLog,
                                       OltgStaging as Oltg)
import oltg.controllers.collectors as collectors
from oltg.controllers import app
from oltg.controllers.common import common_namespace
from oltg.templates.EditWorkflow import EditWorkflow
from datetime import datetime
from oltg.subcommands.push_to_prod import action as push_action
from oltg.subcommands.tojson import action as tojson_action
import re
import cgi
from labmed.util.pluralize import just_pluralize

def edit_workflow(environ, start_response, logger):
    """Allow the user to push individual tests from staging to public."""
    session = environ.get('SESSION', None)
    engine = environ.get('ENGINE', None)
    config_dict = environ['CONFIG']
    oltg.models.setup_db_models(session, engine)
    parameters = environ[app + '.parameters']
    #raise Exception('dir=%s, parameters=%s' % (dir(parameters), parameters))
    action = parameters.get('action', '')

    if action == "push":
        push_tests = [parameters.get(k) for k in parameters.keys() if k.startswith('push_')]
        if push_tests:
            class Args(object):
                def __init__(self):
                    self.config = '/home/mastermu/%s/config/%s.cfg' % (app, app)
                    self.hostname = None
                    self.app = app
                    self.mnemonics = push_tests
                    self.outdir = None      # For tojson
                    self.verbose = 1        # For tojson
            status_p = push_action(Args())
            status_j = tojson_action(Args())
            bad_message = ' Consult logs for details at time %s. Push status=%s, tojson status=%s' % (datetime.now().strftime('%Y-%m-%d %H:%M:%S'), status_p, status_j)

            message = 'Operation to push changes for %s %s to production was %ssuccessful.%s' % (
                just_pluralize(len(push_tests), 'test'),
                ', '.join(push_tests),
                '' if status_p == 0 and status_j == 0 else 'not ',
                '' if status_p == 0 and status_j == 0 else bad_message)
        else:
            message = 'No tests were selected to be pushed.'
    else:
        message = ''

    namespace = common_namespace(environ, config_dict)
    namespace.update(dict(
        edited_tests = collectors.get_edited_tests(session),
        message = message,
        ))
    start_response('200 OK', [('Content-Type', 'text/html')])
    t = EditWorkflow(searchList = [namespace], filter='Filter')
    return [str(t.respond())]
    
