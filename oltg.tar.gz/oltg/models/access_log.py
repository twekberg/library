#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished
###   work under 17 U.S.C. Sec.s 102 and 104(a)
###
### ******************************************************************* 


from datetime import datetime


class Writer(object):
    """
    Record that an access has been made to the OLTG. Previously this was stored
    in the database. Writing to a file instead is just as useful.
    """
    def __init__(self, out_filename):
        self.out_filename = out_filename

    def write(self, staff_only, edit_mode, user, ip_address, action, details):
        with open(self.out_filename, 'a') as log:
            # write a dict so if we need to load it into the
            # database for analysis, the reader is a simple
            # read/eval combination.
            log.write('%s\n' % (dict(staff_only=staff_only,
                                     access_date=datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                                     edit_mode=edit_mode,
                                     user=user,
                                     ip_address=ip_address,
                                     action=action,
                                     details=details)))
