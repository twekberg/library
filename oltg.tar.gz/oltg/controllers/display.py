#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Controller for the display page.
"""

import oltg
import oltg.controllers.collectors as collectors
from oltg.controllers import app
from oltg.controllers.db_interface import get_mnemonic_detail
from oltg.controllers.common import common_namespace
import oltg.models
import oltg.models.access_log as access_log
from oltg.templates.Simple import Simple
from oltg.templates.DisplayError import DisplayError


def display_page(environ, start_response, logger):
    """Display details for a test."""
    session = environ.get('SESSION', None)
    static_page = environ.get('STATIC_PAGE', False)
    parameters = environ[app + '.parameters']
    mnemonic = parameters.get('mnemonic', '')
    staff_only = environ.get('STAFF_ONLY', False)
    edit_mode = environ.get('EDIT_MODE', False)
    config_dict = environ['CONFIG']
    if not static_page:
        # Don't fill up the access log when we generate the static pages.
        access_log.Writer(config_dict['access_log_file']).write(staff_only, edit_mode,
                                                                environ.get('REMOTE_USER', 'Unknown'),
                                                                environ.get('REMOTE_ADDR', 'Unknown'),
                                                                'display',
                                                                mnemonic)
    namespace = get_mnemonic_detail(mnemonic,
                                    from_database=config_dict['read_mnemonics_from_database'] == 'True',
                                    json_dir=config_dict.get('mnemonics_json_dir'))
    reference_range_near_top = True     # Placement of RR
    show_empty = False                  # Show empty fields
    hide_subcomponents = False          # Initially hide subcomponents
    namespace.update(common_namespace(environ, config_dict))
    if staff_only:
        reference_range_near_top = False
        show_empty = True
        hide_subcomponents = True
    if edit_mode:
        reference_range_near_top = False
        show_empty = True
    namespace.update(reference_range_near_top = reference_range_near_top,
                     show_empty = show_empty,
                     hide_subcomponents = hide_subcomponents,
                     static_page = static_page,
                     )

    start_response('200 OK', [('Content-Type', 'text/html')])
    if 'error_message' in namespace:
        t = DisplayError(searchList = [namespace])
    else:
        t = Simple(searchList = [namespace, environ])
    return [str(t.respond())]
