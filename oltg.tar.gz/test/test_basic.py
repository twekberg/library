#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2012 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Using data loaded into an sqlite database, checks various tests to make sure
they are placed into the new OLTG schema properly.
"""


import os
import unittest
from labmed.util.pluralize import just_pluralize
from datetime import datetime
import time

import getters
import db_setup
import oltg.models


class AfterConvertOldOltg(unittest.TestCase):
    session = None
    @classmethod
    def setUpClass(cls):
        (cls.session, cls.engine) = db_setup.init('basic.cfg', 'basic.sql')

    @classmethod
    def tearDownClass(cls):
        # These transfer changes from the sqlite journal file.
        oltg.models.release_session(cls.session, cls.engine)

    def test_one_cpt_code(self):
        object_type = 'BillingAndCptCode'
        mnemonic = 'ACID'
        expected_values = ['84066', '']
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_billing(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d: %s' %
                         (expected_count, object_type, just_pluralize(expected_count, 'object'), mnemonic,
                          len(list(codes)), [str(code) for code in list(codes)]))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].cpt_code, expected_values[i])

    def test_several_cpt_code(self):
        object_type = 'BillingAndCptCode'
        mnemonic = 'ACX'
        expected_values = ['85018', '82810', '83050', '82375']
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_billing(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].cpt_code, expected_values[i])

    def test_no_cpt_code(self):
        object_type = 'BillingAndCptCode'
        mnemonic = 'ACHE'
        expected_values = []
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_billing(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].cpt_code, expected_values[i])

    def test_no_components(self):
        object_type = 'ComponentTest'
        mnemonic = 'ACHE'
        expected_values = []
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_components(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].cpt_code, expected_values[i])

    def test_two_components(self):
        object_type = 'ComponentTest'
        mnemonic = 'ACENBG'
        expected_values = [{'mnemonic':'BCENB1', 'suppressed':'Y'},
                           {'mnemonic':'ACENTB', 'suppressed':'N'}]
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_components(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].component_mnemonic, expected_values[i]['mnemonic'])
            self.assertEqual(codes[i].suppressed, expected_values[i]['suppressed'])

    def test_components_no_suppressed(self):
        object_type = 'ComponentTest'
        mnemonic = 'ACODE'
        expected_values = [{'mnemonic':'ACX',   'suppressed':''},
                           {'mnemonic':'ABGC',  'suppressed':''},
                           {'mnemonic':'WHCT',  'suppressed':''},
                           {'mnemonic':'WNA',   'suppressed':''},
                           {'mnemonic':'WK',    'suppressed':''},
                           {'mnemonic':'WGLU',  'suppressed':''},
                           {'mnemonic':'WIC',   'suppressed':''},
                           {'mnemonic':'WALAC', 'suppressed':''}]
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_components(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].component_mnemonic, expected_values[i]['mnemonic'])
            self.assertEqual(codes[i].suppressed, expected_values[i]['suppressed'])

    def test_components_not_suppressed(self):
        object_type = 'ComponentTest'
        mnemonic = 'ACUTRP'
        expected_values = [{'mnemonic':'GBM',    'suppressed':'N'},
                           {'mnemonic':'ANCAM',  'suppressed':'N'},
                           {'mnemonic':'ANCAC',  'suppressed':'N'},
                           {'mnemonic':'DNAQL',  'suppressed':'N'},
                           {'mnemonic':'ANCAIF', 'suppressed':'N'},
                           {'mnemonic':'DNAEL',  'suppressed':'N'},
                           {'mnemonic':'DNAHS',  'suppressed':'N'}]
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_components(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].component_mnemonic, expected_values[i]['mnemonic'])
            self.assertEqual(codes[i].suppressed, expected_values[i]['suppressed'])

    def test_no_caution_urls(self):
        object_type = 'CautionUrl'
        mnemonic = 'BALC'
        expected_values = []
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_caution_url(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].address[i], expected_values[i]['address'])
            self.assertEqual(codes[i].label, expected_values[i]['label'])

    def test_1_caution_urls(self):
        object_type = 'CautionUrl'
        mnemonic = 'AFBSEQ'
        expected_values = [{'address':'http://depts.washington.edu/molmicdx', 'label':'Molecular diagnosis website'}]
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_caution_url(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].address, expected_values[i]['address'])
            self.assertEqual(codes[i].label, expected_values[i]['label'])

    def test_2_caution_urls(self):
        object_type = 'CautionUrl'
        mnemonic = 'BRAF'
        expected_values = [{'address':'http://tests.labmed.washington.edu/BRAF',
                            'label':'BRAF Test Information'},
                           {'address':'http://depts.washington.edu/labweb/referencelab/clinical/TestForms/genetics.pdf',
                            'label':'Genetics Requisition'}]
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_caution_url(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].address, expected_values[i]['address'])
            self.assertEqual(codes[i].label, expected_values[i]['label'])

    def test_no_xrefs(self):
        object_type = 'CrossReference'
        mnemonic = 'ACCNO'
        expected_values = []
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_xref(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].cross_reference[i], expected_values[i])

    def test_1_xref(self):
        object_type = 'CrossReference'
        mnemonic = 'ACCINR'
        expected_values = ['Protime INR-Alliance Lab']
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_xref(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].cross_reference, expected_values[i])

    def test_xrefs_trailing_blank(self):
        object_type = 'CrossReference'
        mnemonic = 'MFC'
        expected_values = ['Fungal MIC', 'MIC -Fungal', 'Antifungal MIC', 'Fungicidal Concentration']
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_xref(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].cross_reference, expected_values[i])

    def test_xrefs_internal_multiple_blank(self):
        object_type = 'CrossReference'
        mnemonic = 'BUFW'
        expected_values = ['Buffy Coat Wright Stain']
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_xref(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].cross_reference, expected_values[i])

    def test_xrefs_leading_blank(self):
        object_type = 'CrossReference'
        mnemonic = 'RANN1'
        expected_values = ['Anti HU', 'ANNA-1']
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_xref(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].cross_reference, expected_values[i])

    def test_no_reference_range(self):
        object_type = 'ReferenceRange'
        mnemonic = 'ABPATH'
        expected_values = []
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_ref_range(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].sex, expected_values[i]['sex'])
            self.assertEqual(codes[i].age_range, expected_values[i]['age_range'])
            self.assertEqual(codes[i].reference_text_code, expected_values[i]['reference_text_code'])
            self.assertEqual(codes[i].reference_text, expected_values[i]['reference_text'])
            self.assertEqual(codes[i].verify_text_code, expected_values[i]['verify_text_code'])
            self.assertEqual(codes[i].verify_text, expected_values[i]['verify_text'])
            self.assertEqual(codes[i].ordering, expected_values[i]['ordering'])

    def test_one_reference_range(self):
        object_type = 'ReferenceRange'
        mnemonic = 'ADR'
        expected_values = [{'sex':'F', 'age_range':'0-', 'reference_text_code':'NRN', 'reference_text':'Negative', 'verify_text_code':'', 'verify_text':'', 'ordering':1},
                           {'sex':'M', 'age_range':'0-', 'reference_text_code':'NRN', 'reference_text':'Negative', 'verify_text_code':'', 'verify_text':'', 'ordering':1}]
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_ref_range(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].sex, expected_values[i]['sex'])
            self.assertEqual(codes[i].age_range, expected_values[i]['age_range'])
            self.assertEqual(codes[i].reference_text_code, expected_values[i]['reference_text_code'])
            self.assertEqual(codes[i].reference_text, expected_values[i]['reference_text'])
            self.assertEqual(codes[i].verify_text_code, expected_values[i]['verify_text_code'])
            self.assertEqual(codes[i].verify_text, expected_values[i]['verify_text'])
            self.assertEqual(codes[i].ordering, expected_values[i]['ordering'])

    def test_many_reference_ranges(self):
        """
        Used this select to view the values in the reference_ranges_staging table.

SELECT mnemonic,sex,age_range,reference_text_code AS RTC,reference_text,
  ordering, verify_text_code AS VTC, verify_text AS VT
FROM reference_ranges_staging
WHERE mnemonic='RALKT'
ORDER BY sex, ordering;
        """
        object_type = 'ReferenceRange'
        mnemonic = 'RALKT'
        expected_values = [
            {'sex':'F', 'age_range':'0-3y', 'reference_text_code':'NDEF', 'reference_text':'Not Defined', 'verify_text_code':'', 'verify_text':'', 'ordering':1},
            {'sex':'F', 'age_range':'4-4y',    'reference_text_code':'', 'reference_text':'169-372', 'verify_text_code':'', 'verify_text':'', 'ordering':2},
            {'sex':'F', 'age_range':'5-5y',    'reference_text_code':'', 'reference_text':'162-355', 'verify_text_code':'', 'verify_text':'', 'ordering':3},
            {'sex':'F', 'age_range':'6-6y',    'reference_text_code':'', 'reference_text':'169-370', 'verify_text_code':'', 'verify_text':'', 'ordering':4},
            {'sex':'F', 'age_range':'7-7y',    'reference_text_code':'', 'reference_text':'183-402', 'verify_text_code':'', 'verify_text':'', 'ordering':5},
            {'sex':'F', 'age_range':'8-8y',    'reference_text_code':'', 'reference_text':'199-440', 'verify_text_code':'', 'verify_text':'', 'ordering':6},
            {'sex':'F', 'age_range':'9-9y',    'reference_text_code':'', 'reference_text':'212-468', 'verify_text_code':'', 'verify_text':'', 'ordering':7},
            {'sex':'F', 'age_range':'10-10y',  'reference_text_code':'', 'reference_text':'215-476', 'verify_text_code':'', 'verify_text':'', 'ordering':8},
            {'sex':'F', 'age_range':'11-11y',  'reference_text_code':'', 'reference_text':'178-526', 'verify_text_code':'', 'verify_text':'', 'ordering':9},
            {'sex':'F', 'age_range':'12-12y',  'reference_text_code':'', 'reference_text':'133-485', 'verify_text_code':'', 'verify_text':'', 'ordering':10},
            {'sex':'F', 'age_range':'13-13y',  'reference_text_code':'', 'reference_text':'120-449', 'verify_text_code':'', 'verify_text':'', 'ordering':11},
            {'sex':'F', 'age_range':'14-14y',  'reference_text_code':'', 'reference_text':'153-362', 'verify_text_code':'', 'verify_text':'', 'ordering':12},
            {'sex':'F', 'age_range':'15-15y',  'reference_text_code':'', 'reference_text':'75-274',  'verify_text_code':'', 'verify_text':'', 'ordering':13},
            {'sex':'F', 'age_range':'16-16y',  'reference_text_code':'', 'reference_text':'61-264',  'verify_text_code':'', 'verify_text':'', 'ordering':14},
            {'sex':'F', 'age_range':'17-23y',  'reference_text_code':'', 'reference_text':'52-144',  'verify_text_code':'', 'verify_text':'', 'ordering':15},
            {'sex':'F', 'age_range':'24-45y',  'reference_text_code':'', 'reference_text':'37-98' ,  'verify_text_code':'', 'verify_text':'', 'ordering':16},
            {'sex':'F', 'age_range':'46-50y',  'reference_text_code':'', 'reference_text':'39-100',  'verify_text_code':'', 'verify_text':'', 'ordering':17},
            {'sex':'F', 'age_range':'51-55y',  'reference_text_code':'', 'reference_text':'41-108',  'verify_text_code':'', 'verify_text':'', 'ordering':18},
            {'sex':'F', 'age_range':'56-60y',  'reference_text_code':'', 'reference_text':'46-118',  'verify_text_code':'', 'verify_text':'', 'ordering':19},
            {'sex':'F', 'age_range':'61-65y',  'reference_text_code':'', 'reference_text':'50-130',  'verify_text_code':'', 'verify_text':'', 'ordering':20},
            {'sex':'F', 'age_range':'66-150y', 'reference_text_code':'', 'reference_text':'55-142',  'verify_text_code':'', 'verify_text':'', 'ordering':21},
            {'sex':'F', 'age_range':'151y-',   'reference_text_code':'NEST', 'reference_text':'Not Established', 'verify_text_code':'', 'verify_text':'', 'ordering':22},

            {'sex':'M', 'age_range':'0-3y',    'reference_text_code':'NDEF', 'reference_text':'Not Defined', 'verify_text_code':'', 'verify_text':'', 'ordering':1},
            {'sex':'M', 'age_range':'4-4y',    'reference_text_code':'', 'reference_text':'149-369', 'verify_text_code':'', 'verify_text':'', 'ordering':2},
            {'sex':'M', 'age_range':'5-5y',    'reference_text_code':'', 'reference_text':'179-416', 'verify_text_code':'', 'verify_text':'', 'ordering':3},
            {'sex':'M', 'age_range':'6-6y',    'reference_text_code':'', 'reference_text':'179-417', 'verify_text_code':'', 'verify_text':'', 'ordering':4},
            {'sex':'M', 'age_range':'7-7y',    'reference_text_code':'', 'reference_text':'172-405', 'verify_text_code':'', 'verify_text':'', 'ordering':5},
            {'sex':'M', 'age_range':'8-8y',    'reference_text_code':'', 'reference_text':'169-401', 'verify_text_code':'', 'verify_text':'', 'ordering':6},
            {'sex':'M', 'age_range':'9-9y',    'reference_text_code':'', 'reference_text':'175-411', 'verify_text_code':'', 'verify_text':'', 'ordering':7},
            {'sex':'M', 'age_range':'10-10y',  'reference_text_code':'', 'reference_text':'191-435', 'verify_text_code':'', 'verify_text':'', 'ordering':8},
            {'sex':'M', 'age_range':'11-11y',  'reference_text_code':'', 'reference_text':'185-507', 'verify_text_code':'', 'verify_text':'', 'ordering':9},
            {'sex':'M', 'age_range':'12-12y',  'reference_text_code':'', 'reference_text':'185-562', 'verify_text_code':'', 'verify_text':'', 'ordering':10},
            {'sex':'M', 'age_range':'13-13y',  'reference_text_code':'', 'reference_text':'182-587', 'verify_text_code':'', 'verify_text':'', 'ordering':11},
            {'sex':'M', 'age_range':'14-14y',  'reference_text_code':'', 'reference_text':'166-571', 'verify_text_code':'', 'verify_text':'', 'ordering':12},
            {'sex':'M', 'age_range':'15-15y',  'reference_text_code':'', 'reference_text':'138-511', 'verify_text_code':'', 'verify_text':'', 'ordering':13},
            {'sex':'M', 'age_range':'16-16y',  'reference_text_code':'', 'reference_text':'102-417', 'verify_text_code':'', 'verify_text':'', 'ordering':14},
            {'sex':'M', 'age_range':'17-17y',  'reference_text_code':'', 'reference_text':'69-311',  'verify_text_code':'', 'verify_text':'', 'ordering':15},
            {'sex':'M', 'age_range':'18-18y',  'reference_text_code':'', 'reference_text':'52-222',  'verify_text_code':'', 'verify_text':'', 'ordering':16},
            {'sex':'M', 'age_range':'19-150y', 'reference_text_code':'', 'reference_text':'45-115',  'verify_text_code':'', 'verify_text':'', 'ordering':17},
            {'sex':'M', 'age_range':'151y-',   'reference_text_code':'NEST', 'reference_text':'Not Established', 'verify_text_code':'', 'verify_text':'', 'ordering':18},
            ]
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        codes = getters.get_ref_range(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(o.mnemonic, mnemonic)
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].sex, expected_values[i]['sex'])
            self.assertEqual(codes[i].age_range, expected_values[i]['age_range'])
            self.assertEqual(codes[i].reference_text_code, expected_values[i]['reference_text_code'])
            self.assertEqual(codes[i].reference_text, expected_values[i]['reference_text'])
            self.assertEqual(codes[i].verify_text_code, expected_values[i]['verify_text_code'])
            self.assertEqual(codes[i].verify_text, expected_values[i]['verify_text'])
            self.assertEqual(codes[i].ordering, expected_values[i]['ordering'])

    def test_non_numeric_verify_range(self):
        object_type = 'ReferenceRange'
        mnemonic = 'HIPA'
        expected_values = [
            {'sex':'F', 'age_range':'0-', 'reference_text_code':'NRN', 'reference_text':'Negative', 'verify_text_code':'', 'verify_text':'POS,STRNP', 'ordering':1},
            {'sex':'M', 'age_range':'0-', 'reference_text_code':'NRN', 'reference_text':'Negative', 'verify_text_code':'', 'verify_text':'POS,STRNP', 'ordering':1},
            ]
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        self.assertEqual(o.mnemonic, mnemonic)
        codes = getters.get_ref_range(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].sex, expected_values[i]['sex'])
            self.assertEqual(codes[i].age_range, expected_values[i]['age_range'])
            self.assertEqual(codes[i].reference_text_code, expected_values[i]['reference_text_code'])
            self.assertEqual(codes[i].reference_text, expected_values[i]['reference_text'])
            self.assertEqual(codes[i].verify_text_code, expected_values[i]['verify_text_code'])
            self.assertEqual(codes[i].verify_text, expected_values[i]['verify_text'])
            self.assertEqual(codes[i].ordering, expected_values[i]['ordering'])


    def test_numeric_verify_range(self):
        object_type = 'ReferenceRange'
        mnemonic = 'AMHB'
        expected_values = [
            {'sex':'F', 'age_range':'0-', 'reference_text_code':'', 'reference_text':'<3.0', 'verify_text_code':'', 'verify_text':'0.0-30.0', 'ordering':1},
            {'sex':'M', 'age_range':'0-', 'reference_text_code':'', 'reference_text':'<3.0', 'verify_text_code':'', 'verify_text':'0.0-30.0', 'ordering':1},
            ]
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        codes = getters.get_ref_range(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(o.mnemonic, mnemonic)
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.'
                         % (expected_count, object_type, just_pluralize(expected_count, 'object'),
                            mnemonic, len(list(codes))))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].sex, expected_values[i]['sex'])
            self.assertEqual(codes[i].age_range, expected_values[i]['age_range'])
            self.assertEqual(codes[i].reference_text_code, expected_values[i]['reference_text_code'])
            self.assertEqual(codes[i].reference_text, expected_values[i]['reference_text'])
            self.assertEqual(codes[i].verify_text_code, expected_values[i]['verify_text_code'])
            self.assertEqual(codes[i].verify_text, expected_values[i]['verify_text'])
            self.assertEqual(codes[i].ordering, expected_values[i]['ordering'])

    def test_sodium(self):
        """
        Completely test everything related to sodium.
        """
        object_type = 'Oltg'
        mnemonic = 'NA'
        expected_values = [
            {'sex':'F', 'age_range':'0-', 'reference_text_code':'', 'reference_text':'136-145', 'verify_text_code':'', 'verify_text':'120-160', 'ordering':1},
            {'sex':'M', 'age_range':'0-', 'reference_text_code':'', 'reference_text':'136-145', 'verify_text_code':'', 'verify_text':'120-160', 'ordering':1},
            ]
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))

        object_type = 'ReferenceRange'
        codes = getters.get_ref_range(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s, got %d.\n%s' % (expected_count, object_type, just_pluralize(expected_count, 'object'), mnemonic, len(list(codes)), list(codes)))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].sex,                 expected_values[i]['sex'])
            self.assertEqual(codes[i].age_range,           expected_values[i]['age_range'])
            self.assertEqual(codes[i].reference_text_code, expected_values[i]['reference_text_code'])
            self.assertEqual(codes[i].reference_text,      expected_values[i]['reference_text'])
            self.assertEqual(codes[i].verify_text_code,    expected_values[i]['verify_text_code'])
            self.assertEqual(codes[i].verify_text,         expected_values[i]['verify_text'])
            self.assertEqual(codes[i].ordering,            expected_values[i]['ordering'])

        expected_values = [
            {'cpt_code':'84295', 'billing_code':'1040103000207'},
            ]
        expected_count = len(expected_values)
        object_type = 'BillingAndCptCode'
        codes = getters.get_billing(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s' % (expected_count, object_type, just_pluralize(expected_count, 'object'), mnemonic))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].cpt_code,     expected_values[i]['cpt_code'])
            self.assertEqual(codes[i].billing_code, expected_values[i]['billing_code'])

        object_type = 'ComponentTest'
        expected_values = []
        expected_count = len(expected_values)
        codes = getters.get_components(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s' % (expected_count, object_type, just_pluralize(expected_count, 'object'), mnemonic))

        object_type = 'CautionUrl'
        expected_values = []
        expected_count = len(expected_values)
        codes = getters.get_caution_url(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s' % (expected_count, object_type, just_pluralize(expected_count, 'object'), mnemonic))

        object_type = 'CrossReference'
        expected_values = []
        expected_count = len(expected_values)
        codes = getters.get_caution_url(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s' % (expected_count, object_type, just_pluralize(expected_count, 'object'), mnemonic))

        # Finally test the main Oltg object.
        object_type = 'Oltg'
        # The shipping and stability columns are in the old OLTG table, but are
        # all null and there is no GUI for them.
        expected_values = {'mnemonic':mnemonic,
                            'hospital':'U',
                            'tbp_type':'T',
                            'lab_name':'Sodium',
                            'dept_code':'CHA',
                            'dept_full_name':'Chemistry, Automated Panels',
                            'test_info':None,
                            'unit':'mEq/L',
                            'order_flag':'Y',
                            'suppress_print_flag':'N',
                            'name':'Sodium',
                            'specimen_type':'Blood',
                            'reference_range_addendum':'',
                            'collection':'3 mL blood in a LIME GREEN PST, GOLD SST, RED TOP or GREEN TOP tube<br/><strong>Pediatric draw:</strong> 1 full LIME GREEN, GOLD or RED MICROTAINER',
                            'amount':'0.5 mL plasma/serum',
                            'minimum_amount':'0.1 mL plasma/serum',
                            'specimen_handling':'<P><!-- Generated by XStandard version 1.3.0.0 on 2004-09-02T15:49:34 --></P>',
                            'done_uwmc':'Automated Chemistry',
                            'done_hmc':'Stat Laboratory',
                            'done_other':'Roosevelt',
                            'frequency':'Daily',
                            'processing_instructions':'Refrigerate plasma/serum',
                            'method':'Ion Selective Electrode (ISE)',
                            'available_stat':'Yes',
                            'updated_date':datetime(2011, 2, 9),
                            'security_flag':'E',
                            'reference_range_effective_date':datetime(1999, 3, 11),
                            'reference_range_units':'mEq/L',
                            }
        self.assertIsNotNone(o, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        for k in expected_values.keys():
            self.assertEqual(o.get(k), expected_values[k],
                             'Failed %s comparison of %s to %s' % (k, o.get(k), expected_values[k]))


if __name__ == '__main__':
    unittest.main()
