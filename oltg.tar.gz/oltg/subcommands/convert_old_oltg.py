#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
This subcommand is used to convert data in the old OLTG table to the new schema.
Inserts status messages into the messages table when it starts and completes.

The data is placed in the staging tables. Run the push_to_prod program to put
the data in the production tables.

With a sample size of 1, a run took 97.1 minutes.
"""


import sys
reload(sys)
sys.setdefaultencoding('8859')

from datetime import datetime
import hashlib
import re
import scan_lis
import os
import traceback

from labmed.util.unicode import to_unicode

import oltg.subcommands
import oltg.models
import oltg.models.object_queries as object_queries
from oltg.models.create_models import (LisFeedStaging as LisFeed,
                                       OltgStaging as Oltg,
                                       ReferenceRangeStaging as ReferenceRange,
                                       BillingAndCptCodeStaging as BillingAndCptCode,
                                       ComponentTestStaging as ComponentTest,
                                       CautionUrlStaging as CautionUrl,
                                       CrossReferenceStaging as CrossReference,
                                       OldOltg)
from oltg.models.messages import Messages


import logging
log = logging.getLogger(__name__)

debug = False
FS = '\t'
# Separator for caution elements.
CAUTION_SEP = '~'

# Map the old OLTG DB column names to the names used by the LIS feed.
# All of the columns that are empty in the LIS feed are present in the HTML
# data entry page. There are a few columns listed at the end which are easier
# to retrieve from a dict but are not part of the LIS feed. These are also
# present in the HTML data entry page.
old_to_feed = {'reclen':'recLen',
               'number':'number',
               'mnemonic':'mnemonic',
               'hosp':'hosp',
               'type':'type',
               'lab_name':'lab-name',
               'dept':'dept',
               'dept_name':'dept-name',
               'unit':'unit',
               'oflg':'oFlg',
               'spflg':'spFlg',
               'bcodenumbercpt':'bCode#cpt',
               'components':'components',
               'name1':'name1',           # empty feed cells
               'sptype':'spType',         # empty feed cells
               'bcrr_1':'bcRR-1',         # empty feed cells
               'collect_1':'collect-1',   # empty feed cells
               'amount':'amount',         # empty feed cells
               'minimum':'minimum',       # empty feed cells
               'sphand_1':'spHand-1',     # empty feed cells
               'done_uwmc':'done-UWMC',   # empty feed cells
               'done_hmc':'done-HMC',     # empty feed cells
               'done_oth_1':'done-Oth-1', # empty feed cells
               'freq_1':'freq-1',         # empty feed cells
               'avlstat':'avlStat',       # empty feed cells
               'xref':'xRef',             # empty feed cells
               'updated':'updated',       # empty feed cells
               'secflg':'SecFlg',         # empty feed cells
               'cautions':'cautions',     # empty feed cells
               'rreffdate':'rrEffDate',
               'rrunits':'rrUnits',
               # These are not in the feed, but are in the DB
               'testinfo':'testinfo',
               'processing':'processing',
               'method':'method'}
for sex in 'mf':
    for i in xrange(1,25+1):
        old_to_feed['%s_refrng%02d' % (sex, i)] = '%s-RefRng%02d' % (sex.upper(), i)
        old_to_feed['%s_agerng%02d' % (sex, i)] = '%s-AgeRng%02d' % (sex.upper(), i)


# Names in old OLTG DB but not in LIS feed. Those with an 'h' are present in
# the HTML data entry page.
#   h testinfo - 1759
#   h processing - 3175
#   h method - 1325
# All NUll:
#   cis_name
#   h orca_name
#   shipping
#   stability
#   col145


# Names in LIS feed but not in old OLTG DB. All LIS feed cells are empty.
#   name2
#   bcRR-2
#   bcRR-3
#   collect-2
#   spHand-2
#   spHand-3
#   spHand-4
#   spHand-5
#   spHand-6 
#   done-Oth-2
#   done-Oth-3
#   done-Oth-4
#   freq-2


lis_feed_columns = [
    'recLen',
    'number',
    'mnemonic',
    'hosp',
    'type',
    'lab-name',
    'dept',
    'dept-name',
    'unit',
    'oFlg',
    'spFlg',
    'bCode#cpt',
    'components',
    'name1',
    'name2',
    'spType',
    'bcRR-1',
    'bcRR-2',
    'bcRR-3',
    'collect-1',
    'collect-2',
    'amount',
    'minimum',
    'spHand-1',
    'spHand-2',
    'spHand-3',
    'spHand-4',
    'spHand-5',
    'spHand-6',
    'done-UWMC',
    'done-HMC',
    'done-Oth-1',
    'done-Oth-2',
    'done-Oth-3',
    'done-Oth-4',
    'freq-1',
    'freq-2',
    'avlStat',
    'xRef',
    'updated',
    'SecFlg',
    'cautions',
    'rrEffDate',
    'rrUnits'
    ]
for sex in 'FM':
    for i in xrange(1,25+1):
        lis_feed_columns.append('%s-AgeRng%02d' % (sex, i))
        lis_feed_columns.append('%s-RefRng%02d' % (sex, i))


def build_parser(parser):
    oltg.subcommands.default_parser(parser)


def action(args):
    """
    Top level function that performs the conversion.
    """
    (config_dict, session, engine) = oltg.subcommands.init_args(args)
    try:
        # Set this output to be unbuffered. Unbuffering stdout makes tail -f
        # show the latest mnemonics that were processed.
        sys.stdout = os.fdopen(sys.stdout.fileno(), 'w', 0)
        oltg.models.object_query = object_queries.StagingObjectQueries(session, config_dict['db_type'])
        handler = Handler(session)
        handler.messages.store('started')
        for old_row in session.query(OldOltg).all():
            handler.handle(old_row)
        handler.close()
        print 'Fixing unicode'
        (ok, unicode_exception) = fix_unicode(session)
        if not ok:
            handler.n_errors += 1
            handler.messages.store('started', ok, unicode_exception)
        handler.messages.store('completed', ok)
    finally:
        try:
            oltg.models.release_session(session, engine)
        except Exception as e:
            handler.n_errors += 1
            tb = traceback.format_exc()
            print 'Error %d, Caught exception %s: %s\n%s' % (self.n_errors, str(type(e)), e, tb)
    return handler.n_errors             # exit status


class Handler(scan_lis.Handler):
    def __init__(self, session):
        self.session = session
        scan_lis.Handler.__init__(self, session)
        for c in (LisFeed, Oltg, ComponentTest, CautionUrl, ReferenceRange, CrossReference, BillingAndCptCode):
            self.session.execute('truncate table mastermu_oltg.%s' % (c.table_name,))
        self.n_errors = 0
        self.mnemonics = []
        self.messages = Messages(session, 'Convert OLTG old>new')


    def handle(self, old_row):
        """
        Override the base class's handle method to read from the database instead of a file.
        """
        d = old_row.row_to_dict(old_to_feed)
        mnemonic = d['mnemonic']
        self.mnemonics.append(mnemonic)
        if self.count > 0 and self.count % 20 == 0:
            print ' '.join(self.mnemonics)
            self.mnemonics = []
        line = self.combine_row(d)
        (something_changed, o) = scan_lis.Handler.handle(self, d, line, do_commit=False)
        # Change the other values that don't come from the feed.
        try:
            if debug:
                print 'TWE o=%s' % (o,)
            if d['testinfo']:
                something_changed = True
                o.test_info = d['testinfo']
            if d['processing']:
                something_changed = True
                o.processing_instructions = d['processing']
            if d['method']:
                something_changed = True
                o.method = d['method']
            if d['cautions']:
                something_changed = True
                self.handle_cautions(mnemonic, d['cautions'])
            if d['xRef']:
                something_changed = True
                self.handle_xrefs(mnemonic, d['xRef'])
        except Exception as e:
            self.n_errors += 1
            self.messages.store('Error %d, Caught exception %s: %s, Skipping %s' %
                           (self.n_errors, str(type(e)), e, mnemonic), ok, e)
        if something_changed:
            self.commit()


    def combine_row(self, d):
        """
        Combine the values so that it looks like a line from the LIS feed.
        """
        try:
            # Same conversions done in fix_unicode()
            d['xRef']       = to_unicode(d['xRef'])
            d['amount']     = to_unicode(d['amount'])
            d['collect-1']  = to_unicode(d['collect-1'])
            d['done-Oth-1'] = to_unicode(d['done-Oth-1'])
            d['freq-1']     = to_unicode(d['freq-1'])
            d['lab-name']   = to_unicode(d['lab-name'])
            d['method']     = to_unicode(d['method'])
            d['minimum']    = to_unicode(d['minimum'])
            d['name1']      = to_unicode(d['name1'])
            d['processing'] = to_unicode(d['processing'])
            d['bcRR-1']     = to_unicode(d['bcRR-1'])
            d['spHand-1']   = to_unicode(d['spHand-1'])
            d['testinfo']   = to_unicode(d['testinfo'])
            return '\t'.join([str(d[col]) if col in d and d[col] is not None else '' for col in lis_feed_columns])
        except UnicodeEncodeError:
            print [(k, d[k]) for k in sorted(d.keys())]
            raise

    def handle_cautions(self, mnemonic, cautions):
        """
        Break up the cautions into individual web addresses and label components.
        The form is
        address#label~...
        """
        if cautions[-1] == CAUTION_SEP:
            cautions = cautions[:-1]
        try:
            for caution in cautions.split('~'):
                (address, label) = caution.split('#', 1)
                c = CautionUrl()
                c.mnemonic = mnemonic
                c.address = address
                c.label = label
                self.session.add(c)
        except ValueError as e:
            self.messages.store('Warning', True, 'Malformed caution was found in test %s: "%s". The LIS staff needs to be informed regarding this problem (after the size of the cautions colums is increased).' % (mnemonic, caution))



    def handle_xrefs(self, mnemonic, xrefs):
        """
        Break up the cross references into individual entries.
        Cross references for the old OLTG table are entered by hand, and so the
        formatting is not neccessarily consistent.  By convention, individual
        cross reference entries are separated by a ', '. For this OLTG, cross
        references are added indidually. A list of cross references in the old
        oltg table that contain a comma was generated using the following
        query:
          select xref from oltg where xref like '%,%' into outfile '/tmp/xref.txt';
        Then this list was run through grep:
          grep -P ',[^ 0-9]' /tmp/xref.txt
        to determine which cross references contain a comma not followed by a
        space. There are several chemical names like 1,5-AG that contain a
        comma followed by a digit which are OK.  When this was last done there
        were 20 of these entries. By scanning through this short list one can
        verify that the usage of a comma is correct.
        """
        xrefs = xrefs.strip()           # Remove leading/trailing whitespace
        if xrefs[-1] == ',':
            xrefs = xrefs[:-1]          # Remove trailing comma
        for xref in xrefs.split(', '):
            xref = xref.strip().replace('  ', ' ')
            c = CrossReference()
            c.mnemonic = mnemonic
            c.cross_reference = xref
            self.session.add(c)

# -----------------------------------------------------------------------------
# The following fixes a unicode problem that happens when using data
# from the old OLTG. It contains some characters (e.g. 176) that get
# an error when displayed. This code code changes those single
# characters with a replacement, when appropriate or a corresponding
# character class (e.g. &deg;).

def fix_unicode(session):
    """
    Look for unicode errors.

    Returns a tuple (ok, unicode_exception). unicode_exception will be None if ok is True.
    """
    ok = False
    mnemonic = None
    tb = None
    try:
        for cr in session.query(CrossReference).all():
            mnemonic = cr.mnemonic
            needs_adding = False
            if cr.cross_reference:
                old_cross_reference = cr.cross_reference
                new_cross_reference = to_unicode(cr.cross_reference)
                if old_cross_reference != new_cross_reference:
                    cr.cross_reference = new_cross_reference
                    needs_adding = True

            if needs_adding:
                session.add(cr)
        session.commit()


        for o in session.query(Oltg).all():
            mnemonic = o.mnemonic
            needs_adding = False

            if o.amount:
                old_amount = o.amount
                new_amount = to_unicode(o.amount)
                if old_amount != new_amount:
                    o.amount = new_amount
                    needs_adding = True

            if o.collection:
                old_collection = o.collection
                new_collection = to_unicode(o.collection)
                if old_collection != new_collection:
                    o.collection = new_collection
                    needs_adding = True

            if o.done_other:
                old_done_other = o.done_other
                new_done_other = to_unicode(o.done_other)
                if old_done_other != new_done_other:
                    o.done_other = new_done_other
                    needs_adding = True

            if o.frequency:
                old_frequency = o.frequency
                new_frequency = to_unicode(o.frequency)
                if old_frequency != new_frequency:
                    o.frequency = new_frequency
                    needs_adding = True

            if o.lab_name:
                old_lab_name = o.lab_name
                new_lab_name = to_unicode(o.lab_name)
                if old_lab_name != new_lab_name:
                    o.lab_name = new_lab_name
                    needs_adding = True

            if o.method:
                old_method = o.method
                new_method = to_unicode(o.method)
                if old_method != new_method:
                    o.method = new_method
                    needs_adding = True

            if o.minimum_amount:
                old_minimum_amount = o.minimum_amount
                new_minimum_amount = to_unicode(o.minimum_amount)
                if old_minimum_amount != new_minimum_amount:
                    o.minimum_amount = new_minimum_amount
                    needs_adding = True

            if o.name:
                old_name = o.name
                new_name = to_unicode(o.name)
                if old_name != new_name:
                    o.name = new_name
                    needs_adding = True

            if o.processing_instructions:
                old_processing_instructions = o.processing_instructions
                new_processing_instructions = to_unicode(o.processing_instructions)
                if old_processing_instructions != new_processing_instructions:
                    o.processing_instructions = new_processing_instructions
                    needs_adding = True

            if o.reference_range_addendum:
                old_reference_range_addendum = o.reference_range_addendum
                new_reference_range_addendum = to_unicode(o.reference_range_addendum)
                if old_reference_range_addendum != new_reference_range_addendum:
                    o.reference_range_addendum = new_reference_range_addendum
                    needs_adding = True

            if o.specimen_handling:
                old_specimen_handling = o.specimen_handling
                new_specimen_handling = to_unicode(o.specimen_handling)
                if old_specimen_handling != new_specimen_handling:
                    o.specimen_handling = new_specimen_handling
                    needs_adding = True

            if o.test_info:
                old_test_info = o.test_info
                new_test_info = to_unicode(o.test_info)
                if old_test_info != new_test_info:
                    o.test_info = new_test_info
                    needs_adding = True


            if needs_adding:
                session.add(o)
        session.commit()
        ok = True
        unicode_exception = None
    except Exception as e:
        # Unexpected exception.
        unicode_exception = e
    return (ok, unicode_exception)
