#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Basic queries for the objects.
"""


import sqlalchemy as sa

import oltg.models
from oltg.models.db_specific import lpad
from oltg.models.create_models import (BillingAndCptCode,
                                       BillingAndCptCodeStaging,
                                       CautionUrl,
                                       CautionUrlStaging,
                                       CernerNonplaceholderSynonym,
                                       CernerOrder,
                                       CernerPlaceholderMap,
                                       CernerSynonym,
                                       CernerSynonymDisplay,
                                       ComponentTest,
                                       ComponentTestStaging,
                                       CrossReference,
                                       CrossReferenceStaging,
                                       FeeSchedule,
                                       LisFeed,
                                       LisFeedStaging,
                                       Oltg,
                                       OltgStaging,
                                       ReferenceRange,
                                       ReferenceRangeStaging)


def get_tbp_type(tbp_type):
    """
    Convert the test type code into its meaning.
    """
    return dict(T='Test', B='Battery', P='Package').get(tbp_type,'')


def get_order_flag(order_flag):
    """
    Convert the order flag into its meaning.
    """
    return {'Y':'', '': 'Orderable', 'N':'Not Orderable', 'B':'Billing Only', }.get(order_flag,'')


def get_security_flag(security_flag):
    """
    Convert the security flag into its meaning.
    """
    return {'E':'External', 'I':'Internal', 'N':'Not Shown', }.get(security_flag,'')


def get_foreign_column_lengths():
    """
    Return the maximum lengths of an individual cross reference, the
    caution_url address and caution_url label as a dict.
    """
    x = CrossReference()
    c = CautionUrl()
    return dict(cross_reference = x.get_db_type_length('cross_reference'),
                address = c.get_db_type_length('address'),
                label = c.get_db_type_length('label'),
                )

class BaseObjectQueries(object):
    """
    The edit version needs to look at the staging tables. The non-edit version
    looks at the production tables. This class provides the methods that are
    common to both version.
    """
    def __init__(self, session, db_type):
        self.session = session
        self.db_type = db_type


    def get_objects(self, mnemonic, DBObject):
        """
        Look up one or more records for a specific database, by mnemonic.
        This is only used internally.
        """
        o = self.session.query(DBObject).filter(DBObject.mnemonic == mnemonic)
        # The list(o) has the side effect of executing the query, and changing to
        # a result set.
        return list(o)


    def create_oltg_object(self):
        """
        Create an Oltg object.
        """
        return self.OltgClass()


    def create_billing_and_cpt_code_object(self):
        """
        Create an BillingAndCptCode object.
        """
        return self.BillingAndCptCodeClass()


    def create_component_test_object(self):
        """
        Create an ComponentTest object.
        """
        return self.ComponentTestClass()


    def create_lis_feed_object(self):
        """
        Create an LisFeed object.
        """
        return self.LisFeedClass()


    def create_reference_range_object(self):
        """
        Create an ReferenceRange object.
        """
        return self.ReferenceRangeClass()


    def get_name(self, o):
        """
        Get the name of the test. If someone entered a value for 'name',
        use that, otherwise use 'lab_name'.
        """
        return o.name or o.lab_name


    def get_billing_and_cpt_codes(self, mnemonic):
        """
        A list BillingAndCptCode objects is returned, or an empty list if there are none.
        """
        return self.get_objects(mnemonic, self.BillingAndCptCodeClass)


    def get_caution_urls(self, mnemonic):
        """
        A list CautionUrl objects is returned, or an empty list if there are none.
        """
        return self.get_objects(mnemonic, self.CautionUrlClass)


    def get_cross_references(self, mnemonic):
        """
        A list CrossReference objects is returned, or an empty list if there are none.
        """
        return self.get_objects(mnemonic, self.CrossReferenceClass)


    def get_oltg(self, mnemonic):
        """
        Looks for an oltg record for the specified mnemonic. If it isn't there then None is returned.
        Otherwise the object is returned.
        """
        o = self.get_objects(mnemonic, self.OltgClass)
        if len(list(o)) == 0:
            return None
        return o[0]


    def get_reference_ranges(self, mnemonic, sex):
        """
        Looks for any reference ranges for the specified mnemonic and sex.
        If there aren't any then an empty list is returned. Otherwise a list of
        self.ReferenceRangeClass objects is returned.
        """
        o = self.session.query(self.ReferenceRangeClass).filter(self.ReferenceRangeClass.mnemonic == mnemonic).filter(self.ReferenceRangeClass.sex == sex)
        # The list(o) has the side effect of executing the query, and changing to
        # a result set.
        x = list(o)
        return o


    def delete_reference_ranges(self, mnemonic):
        self.session.query(self.ReferenceRangeClass).filter(self.ReferenceRangeClass.mnemonic == mnemonic).delete()


    def delete_billing_and_cpt_codes(self, mnemonic):
        self.session.query(self.BillingAndCptCodeClass).filter(self.BillingAndCptCodeClass.mnemonic == mnemonic).delete()


    def delete_component_tests(self, mnemonic):
        self.session.query(self.ComponentTestClass).filter(self.ComponentTestClass.mnemonic == mnemonic).delete()


    def get_lis_feed(self, mnemonic):
        return self.session.query(self.LisFeedClass).filter(self.LisFeedClass.mnemonic == mnemonic)


    def get_department(self, o):
        """
        Get the department mnemonic and its full name.
        """
        if o.dept_code and o.dept_full_name:
            return '%s (%s)' % (o.dept_full_name, o.dept_code)
        else:
            return o.dept_code or o.dept_full_name


    def get_fee_schedule(self, cpt_code):
        """
        Looks for a record for the specified cpt_code. If it isn't there then None is returned.
        Otherwise the object is returned.
        """
        o = self.session.query(FeeSchedule).filter(FeeSchedule.cpt_code == cpt_code)
        # The list(o) has the side effect of executing the query, and changing to
        # a result set.
        if len(list(o)) == 0:
            return None
        return o[0]


    def get_component_tests(self, mnemonic):
        """
        Returns an iterator of dicts with keys
        ['mnemonic','name','level','tbp_type'] describing components of
        mnemonic.
        """
        suffix = '' if self.is_prod else '_staging'

        # Column 1: is the component.
        # Column 2: the level, 1 for direct components, 2 for subcomponents.
        # Column 3: The third column is the shared component mnemonic. For direct
        # components it is the direct component mnemonic. For subcomponents, this
        # is the direct component's mnemonic.
        # Column 4: is the component's id.
        # Sorting is done so the packages are ordered alphabetically, next by level
        # so that level 1s come before level 2s, finally by id so that a battery's
        # component order is maintained.
        #
        # Battery components are ordered by insertion order (i.e. by id).
        #
        # Note that this query is more complicated than normal because
        # the tbp_type is not passed to this function.
        sql = """
SELECT component_mnemonic, level, base_mnemonic, id
FROM
 (
  SELECT ct.component_mnemonic, 1 as level, ct.component_mnemonic as base_mnemonic, ct.id, o.tbp_type
   FROM mastermu_oltg.component_tests%s ct
   JOIN mastermu_oltg.oltg%s o ON o.mnemonic=:mnemonic
   WHERE ct.mnemonic=:mnemonic AND suppressed != 'Y'
  UNION
  SELECT ct.component_mnemonic, 2 as level, ct.mnemonic as base_mnemonic, ct.id, o.tbp_type
   FROM mastermu_oltg.component_tests%s ct
   JOIN mastermu_oltg.oltg%s o ON o.mnemonic=:mnemonic
  WHERE ct.suppressed != 'Y' AND ct.mnemonic IN
   (SELECT component_mnemonic FROM mastermu_oltg.component_tests%s WHERE mnemonic=:mnemonic AND suppressed != 'Y')
 ) x
  ORDER BY CASE WHEN tbp_type='B' THEN %s ELSE base_mnemonic||'_'||level||'_'||%s END;
""" % ((suffix,) * 5 + (lpad(self.db_type, 'id', 20),) * 2)
        # Given the mnemonic and level of each component, get any
        # additional information we want.

        # TODO: seems like we would want to perform some sort of
        # substituition on these test names as well (until unicode
        # problems are fixed)?    
        for result in self.session.execute(sql, {'mnemonic': mnemonic}):
            o = self.get_oltg(result['component_mnemonic'])
            yield dict(
                mnemonic = result['component_mnemonic'], 
                name     = self.get_name(o),
                level    = result['level'],
                tbp_type = get_tbp_type(o.tbp_type)
            )


    # -------------------------------------------------------------------------
    # The rest of the methods relate to cerner names and synonyms.
    # -------------------------------------------------------------------------


    def get_cerner_name_details(self, mnemonic):
        """
        Get details related to cerner names.

        Returns a list of dictionaries. The first element of the list is the primary name,
        The other elements are sorted by name.
        """
        ret = []
        for (o,s,sd) in list(self.session.query(CernerOrder,CernerSynonym,CernerSynonymDisplay)
                             .join(CernerSynonym)
                             .join(CernerSynonymDisplay)
                             .filter(CernerOrder.lab_mnemonic==mnemonic)
                             .filter(CernerOrder.active==True)
                             .all()):
            ret.append({'primary_name_hidden': o.primary_name_hidden,
                        'cerner_synonym_id':   s.id,
                        'name': s.name,
                        'is_primary': s.is_primary,
                        'show': sd.show})
        return sorted(ret, cmp=lambda a,b: cmp(a['name'], b['name']) if (a['is_primary'] == b['is_primary'])
                          else -1 if a['is_primary'] else 1)


    def get_synonyms_from_cerner_placeholder_maps(self, mnemonic):
        """
        Get details related to cerner names, via the cerner_placeholder_maps table.

        Returns a list of dictionaries. The first element of the list is the primary name,
        The other elements are sorted by name.
        """
        ret = []
        for (cpm,cns,s) in list(self.session.query(CernerPlaceholderMap,CernerNonplaceholderSynonym,CernerSynonym)
                             .join(CernerNonplaceholderSynonym)
                             .join(CernerSynonym)
                             .filter(CernerPlaceholderMap.lab_mnemonic==mnemonic)
                             .all()):
            ret.append({'primary_name_hidden': True,
                        'cerner_synonym_id':   s.id,
                        'name': s.name,
                        'is_primary': s.is_primary,
                        'show': cns.show})
        return sorted(ret, cmp=lambda a,b: cmp(a['name'], b['name']) if (a['is_primary'] == b['is_primary'])
                          else -1 if a['is_primary'] else 1)


    def get_cerner_names(self, mnemonic):
        """
        Get only the primary/synonym names for cerner.  If this is mnemonic has
        no cerner name, then look in the cerner_placeholder_maps table to see if
        there is one there. If not there then look in the cerner_lab_orders table.

        Returns a list of strings. The first element of the list is the primary name,
        The other elements are sorted by name.
        """
        syms = self.get_synonyms_from_cerner_placeholder_maps(mnemonic)
        if len(syms) == 0:
            # Don't have any detail in the placeholder map, try the normal place.
            syms = self.get_cerner_name_details(mnemonic)
        return [e['name'] for e in syms if e['show']]


    def get_cerner_order(self, cerner_order_code):
        """
        Get the CernerOrder objects for a cerner_order_code.
        """
        return list(self.session.query(CernerOrder)
                    .filter(CernerOrder.code==cerner_order_code)
                    .all())[0]


    def get_max_cerner_order_code(self):
        """
        Get the highest cerner_order_code from the cerner_orders table.
        This is used to compute a new unique cerner_order_code.
        """
        o = list(self.session.query(sa.func.max(CernerOrder.code)))
        if o is None or len(o) != 1:
            return 2**32
        # Return first element of first row.
        return o[0][0]


    def get_cerner_synonyms(self, cerner_order_code):
        """
        Get the CernerSynonym objects for a cerner_order_code.
        """
        return list(self.session.query(CernerSynonym)
                    .filter(CernerSynonym.cerner_order_code==cerner_order_code)
                    .all())


    def get_cerner_synonym_displays(self, cerner_order_code):
        """
        Get the CernerSynonymDisplay objects for a cerner_order_code.
        """
        return list(self.session.query(CernerSynonymDisplay)
                    .join(CernerSynonym)
                    .filter(CernerSynonym.cerner_order_code==cerner_order_code)
                    .all())


    def get_cerner_synonym_display(self, cerner_synonym_id):
        """
        Get just a CernerSynonymDisplay database object.
        """
        sd = list(self.session.query(CernerSynonymDisplay)
                  .filter(CernerSynonymDisplay.cerner_synonym_id==cerner_synonym_id)
                  .all())
        if sd is None or len(sd) != 1:
            return None
        return sd[0]


    def get_all_cerner_synonyms(self):
        """
        Get a list of all synonym objects that have an associated active cerner order.
        Used to construct a list of name/ids for FilterSelect.
        """
        return list(self.session.query(CernerSynonym)
                    .join(CernerOrder)
                    .filter(CernerOrder.active==True)
                    .filter(sa.not_(CernerSynonym.name.like('zz%')))
                    .order_by(CernerSynonym.name)
                    .all())


    def get_all_cerner_lab_mnemonics(self):
        """
        Get a list of all lab mnemonics that have an associated active cerner order.
        Used to construct a list of name/ids for FilterSelect.
        """
        return list(self.session.query(CernerOrder)
                    .filter(CernerOrder.active==True)
                    .filter(sa.not_(CernerOrder.primary_name.like('zz%')))
                    .filter(CernerOrder.lab_mnemonic != None)
                    .order_by(CernerOrder.lab_mnemonic)
                    .all())


# The following two subclasses modify the basic queries in the base class
# to pull data from either the production or staging tables.
class ProdObjectQueries(BaseObjectQueries):
    """
    Pull objects from the production tables.
    """
    def __init__(self, *args, **kwargs):
        super(ProdObjectQueries, self).__init__(*args, **kwargs)
        self.is_prod = True
        self.BillingAndCptCodeClass = BillingAndCptCode
        self.CautionUrlClass        = CautionUrl
        self.CrossReferenceClass    = CrossReference
        self.LisFeedClass           = LisFeed
        self.OltgClass              = Oltg
        self.ReferenceRangeClass    = ReferenceRange
        self.ComponentTestClass     = ComponentTest


class StagingObjectQueries(BaseObjectQueries):
    """
    Pull objects from the staging tables.
    """
    def __init__(self, *args, **kwargs):
        super(StagingObjectQueries, self).__init__(*args, **kwargs)
        self.is_prod = False
        self.BillingAndCptCodeClass = BillingAndCptCodeStaging
        self.CautionUrlClass        = CautionUrlStaging
        self.CrossReferenceClass    = CrossReferenceStaging
        self.LisFeedClass           = LisFeedStaging
        self.OltgClass              = OltgStaging
        self.ReferenceRangeClass    = ReferenceRangeStaging
        self.ComponentTestClass     = ComponentTestStaging
