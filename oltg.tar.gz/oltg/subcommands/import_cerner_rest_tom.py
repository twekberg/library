#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
This loads defaults for the tests not known by cerner specifying where in a single column.
"""

# Example:
#   ./runoltg import_cerner_rest filename

import os
import os.path
import random
import re
import sys

from labmed.util.boolean import to_bool
from labmed.util.unicode import to_unicode
from labmed.util.pluralize import just_pluralize
import labmed.spreadsheet_reader

import oltg.subcommands
import oltg.models
import oltg.models.object_queries as object_queries
from oltg.models.create_models import (Oltg,
                                       CernerNonplaceholderSynonym,
                                       CernerSynonym,
                                       CernerPlaceholderMap,
                                       CernerOrder)
from oltg.models.messages import Messages

def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    labmed.spreadsheet_reader.spreadsheet_parser(parser, what_file='rest of lab_mnemonics')


def action(args):
    """
    Scan the plasteholder map table we got from Chuck.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    messages = Messages(session, 'Load rest tom')
    try:
        ok = False
        messages.store('started')
        try:
            act = labmed.spreadsheet_reader.Action(args.input_filename,
                                                   RowHandler,
                                                   row_handler_args = {'session': session,
                                                                       'only_print': False},
                                                   csv_sep=args.csv_sep)
            act.loop()
            ok = True
        except Exception as e:
            # Unexpected exception.
            messages.store('Caught exception', False, e)
        messages.store('completed. count=%d, missing synonyms=%d' % (act.count, act.row_handler.missing_synonym), ok)
    finally:
        oltg.models.release_session(session, engine)
    return 0 if ok else 1               # exit status


class RowHandler(labmed.spreadsheet_reader.BaseRowHandler):
    """
    Default row handler simply copies the data into the object.
    """
    def __init__(self, session, column_names, only_print):
        labmed.spreadsheet_reader.BaseRowHandler.__init__(self, session, None, column_names, only_print)
        self.bad_test_name = 0
        self.missing_synonym = 0
        self.name_to_mnemonic = {'contact lab':'contact_lab'}

    def handle(self, row):
        mnemonic = row[self.column_map['mnemonic']]
        test_name = row[self.column_map['test_name']]
        if test_name in self.name_to_mnemonic:
            placeholder_mnemonic = self.name_to_mnemonic[test_name]
            # First deal with the cerner_placeholder_maps table.
            o = list(self.session.query(CernerPlaceholderMap)
                     .filter(CernerPlaceholderMap.lab_mnemonic == mnemonic)
                     .filter(CernerPlaceholderMap.placeholder_lab_mnemonic == placeholder_mnemonic)
                     )
            need_commit = False
            if len(o) == 0:
                # Not there, create one
                o = CernerPlaceholderMap()
                o.lab_mnemonic = mnemonic
                o.placeholder_lab_mnemonic = placeholder_mnemonic
                self.session.add(o)
                need_commit = True
            # Now deal with the cerner_nonplaceholder_synonyms table.
            # First get the cerner_synonym_id(s).
            o = list(self.session.query(CernerSynonym)
                     .join(CernerOrder)
                     .filter(CernerOrder.lab_mnemonic == placeholder_mnemonic)
                     )
            if len(o) == 0:
                # Not there.
                self.missing_synonym +=1
            else:
                for s in o:
                    # Found a CernerSynonym. Use the ID to look for the
                    # CernerNonplaceholderSynonym.
                    cerner_synonym_id = s.id
                    nps = list(self.session.query(CernerNonplaceholderSynonym)
                               .filter(CernerNonplaceholderSynonym.placeholder_cerner_synonym_id == cerner_synonym_id)
                               .filter(CernerNonplaceholderSynonym.nonplaceholder_lab_mnemonic == mnemonic)
                               )
                    if len(nps) == 0:
                        # Not there - create one
                        n = CernerNonplaceholderSynonym()
                        n.nonplaceholder_lab_mnemonic = mnemonic
                        n.placeholder_cerner_synonym_id = cerner_synonym_id
                        n.show = True
                        n.ready_for_delete = False
                        self.session.add(n)
                        need_commit = True
            if need_commit:
                self.session.commit()
        else:
            self.bad_test_name += 1

