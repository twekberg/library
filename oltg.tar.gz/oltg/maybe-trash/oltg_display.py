#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Used to display the OLTG detail.

Uses composition instead of inheritance.
"""


from decimal import Decimal
import models
from models.oltg import Oltg
from models.billing_and_cpt_code import BillingAndCptCode
from models.caution_url import CautionUrl
from models.component_test import ComponentTest
from models.cross_reference import CrossReference
from models.reference_range import ReferenceRange
from models.fee_schedule import FeeSchedule


class OltgDisplay(object):
    def __init__(self, oltg):
        """
        Initialize the object by getting all of the related data.
        """
        self.oltg = oltg
        # We are going to reference this a few times. Might as well make it class local.
        self.mnemonic = self.oltg.mnemonic
        self.billing_and_cpt_codes = self.get_billing_and_cpt_codes()
        self.caution_urls = self.get_caution_urls()
        self.component_tests = self.get_component_tests()
        self.cross_references = self.get_cross_references()
        self.reference_ranges = self.get_reference_ranges()


    def get_billing_and_cpt_codes(self):
        return list(models.session.query(BillingAndCptCode).filter(BillingAndCptCode.mnemonic == self.mnemonic))

    def get_caution_urls(self):
        return list(models.session.query(CautionUrl).filter(CautionUrl.mnemonic == self.mnemonic))

    def get_component_tests(self):
        return list(models.session.query(ComponentTest).filter(ComponentTest.mnemonic == self.mnemonic))

    def get_cross_references(self):
        return list(models.session.query(CrossReference).filter(CrossReference.mnemonic == self.mnemonic))

    def get_reference_ranges(self):
        return list(models.session.query(ReferenceRange).filter(ReferenceRange.mnemonic == self.mnemonic).order_by(ReferenceRange.ordering,ReferenceRange.sex))

    def get_fee_schedule(self, cpt_code):
        o = list(models.session.query(FeeSchedule).filter(FeeSchedule.cpt_code == cpt_code))
        if len(o) != 1:
            raise Exception('Expected 1 FeeSchedule object to match cpt CODE %s, got %d: %s' % cpt_code, (len(o), o))
        return o[0]                         # Get the one object.


    def get_name(self, o):
        return o.name if o.name else o.lab_name

    def to_html(self):
        """
        Generate HTML code for the Oltg object, and its sub-objects.
        """

        extra = ''
        if self.oltg.tbp_type == 'T':
            if self.oltg.order_flag == 'N':
                extra = '&nbsp;Not Orderable'
            elif self.oltg.order_flag == 'B':
                extra = '&nbsp;Billing Only'
        html = self.generate_group('%s Information:%s' % ({'T':'Test', 'B':'Battery', 'P':'Package'}[self.oltg.tbp_type], extra),
                                   [('Name',self.get_name(self.oltg)),
                                    ('Cross References', '' if len(self.cross_references)==0 else (
                                        ', '.join([c.cross_reference for c in self.cross_references]))),
                                    ('Specimen Type', self.oltg.specimen_type),
                                    ('Lab Mnemonic', self.oltg.mnemonic),
                                    ('ORCA Name', self.oltg.cerner_name),
                                    ('EPIC Name', self.oltg.epic_name),
                                    ('General Information', self.oltg.test_info),
                                    ('', '' if len(self.caution_urls)==0 else (
                                        ''.join(['<a href="%s">%s</a>' % (cu.url, cu.href) for cu in self.oltg.caution_urls])
                                        )),
                                    ('Components', '' if len(self.component_tests)==0 else (
                                        ''.join(['' if c.suppressed!='N' else self.get_name(get_oltg(c.component_mnemonic)) for c in self.component_tests])
                                        )),
                                    ])
                                    
        html += self.generate_group('Collection and Handling:',
                                    [('Collection', self.oltg.collection),
                                     ('Handling', self.replace_urls(self.oltg.specimen_handling)),
                                     ('Amount', self.oltg.amount),
                                     ('Minimum', self.oltg.minimum_amount),
                                     ])
        html += self.generate_group('Laboratory:',
                                    [('Processing', self.oltg.processing_instructions),
                                     ('Performing Lab', '' if len(self.oltg.done_uwmc)+len(self.oltg.done_hmc)==0 else (
                                         '' if len(self.oltg.done_uwmc)==0 else '<b>UWMC:</b>%s&nbsp;' % (self.oltg.done_uwmc,)
                                         +
                                         '' if len(self.oltg.done_hmc)==0 else '<b>HMC:</b>%s' % (self.oltg.done_hmc,)
                                         )),
                                     ('Outside Lab', '' if len(self.oltg.done_other)<=3 else self.oltg.done_other),
                                     ('Frequency', self.oltg.frequency),
                                     ('Available STAT?', self.oltg.available_stat),
                                     ('LIS Dept Code', '%s (%s)' % (self.oltg.dept_full_name, self.oltg.dept_code)),
                                     ('Last Updated', self.oltg.updated_date),
                                     ('Method', self.oltg.method),
                                     self.generate_cpt(),
                                     ])
        html += self.generate_reference_ranges()
        return html


    def generate_reference_ranges(self):
        """
        Generate the HTML for the reference ranges, if there are any.
        """
        html = """
 <table class="textpadding" width="567px">
  <tr vAlign="top">
    <td height="55" width="100%">
      <table class="notes" width="100%">
"""
        if self.oltg.reference_range_effective_date:
            html += """
        <tr>
          <td align="right"><b>Reference&nbsp;Range:</b></td><td valign="bottom">Effective Dates: %s&nbsp;- </td>
        </tr>
""" % (self.oltg.reference_range_effective_date.strftime('%m/%d/%Y'),)
        html_1 = """
        <tr>
          <td align="right">&nbsp;</td>
          <td>
            <table border="1" cellspacing="0" cellpadding="1" class="notes" width="440px">
              <tr>
                <td align="center" colspan="2" bgcolor="LightGrey"><b>Female</b></td>
                <td align="center" colspan="2" bgcolor="LightGrey"><b>Male</b></td>
              </tr>
              <tr>
                <td align="center">Age</td>
                <td align="center">Range</td>
                <td align="center">Age</td>
                <td align="center">Range</td>
              </tr>
"""
        i = 0
        rr_data = self.reference_ranges
        more_rr_data = True
        html_2 = ''
        while i < len(rr_data):
            html_2 += '<tr>'
            if rr_data[i].sex == 'F':
                html_2 += '<td>%s</td><td>%s%s</td>' % (rr_data[i].age_range, rr_data[i].reference_text,
                                                      ('&nbsp;[%s]' % rr_data[i].reference_text_code)
                                                      if rr_data[i].reference_text_code else '')
                i += 1
            else:
                html_2 += '<td>%s</td><td>%s</td>' % ('&nbsp;', '&nbsp;')
            if i < len(rr_data) and rr_data[i].sex == 'M':
                html_2 += '<td>%s</td><td>%s%s</td>' % (rr_data[i].age_range, rr_data[i].reference_text,
                                                        ('&nbsp;[%s]' % rr_data[i].reference_text_code)
                                                        if rr_data[i].reference_text_code else '')
                i += 1
            else:
                html_2 += '<td>%s</td><td>%s</td>' % ('&nbsp;', '&nbsp;')
            html += '</tr>'
        html_3 = """        
            </table>
          </td>
        </tr>
"""
        if html_2 != '':
            html += html_1 + html_2 + html_3

        html += self.generate_item('Units',              self.oltg.reference_range_units)
        html += self.generate_item('Ref Range Comments', self.oltg.reference_range_notes)
        html += """
      </table>
    </td>
  </tr>
</table>"""
        return html


    def generate_cpt(self):
        """
        Generate the HTML for CPT codes and medicare reimbursements.
        """
        if len(self.billing_and_cpt_codes)==0:
            return ''
        cpt_codes = [o.cpt_code for o in self.billing_and_cpt_codes]
        med_reimb = [self.get_fee_schedule(cpt_code).reimbursement.quantize(Decimal('.01')) for cpt_code in cpt_codes]
        html = """
<tr>
  <td>&nbsp;</td>
  <td>
    <table class="notes">
      <tr>
        <td><b>CPT Codes:</b></td>
        <td><b>Medicare Reimbursement:</b></td>
      </tr>"""
        for (cpt,med) in zip(cpt_codes, med_reimb):
            html += '<tr><td>%s</td><td>%s</td></tr>' % (cpt,med)
        html += '</table></td></tr>'
        html += '<tr><td colspan=2><i>Medicare reimbursements do not reflect charges or costs; CPT codes may not be complete.</i></td></tr>'
        return html

    def is_url(self, word):
        """
        Look at a string to see if it looks like a URL. Do not use the urlparse package
        since it thinks any ordinary word is a URL.
        """
        prefixes = ['HTTP:/', 'FILE:/', 'MAILTO:/', 'FTP:/', 'GOPHER:/', 'NEWS:/', 'HTTPS:/', 'TELNET:/', 'NNTP:/']
        for prefix in prefixes:
            if word.startswith(prefix):
                return True
        return False

    def replace_urls(self, s):
        """
        Replace URLs with the proper HTML code.
        """
        words = s.split(' ')
        changed = False
        for i in xrange(len(words)):
            word = words[i]
            if self.is_url(word):
                words[i] = '<a href="%s">%s</a>' % (word, word)
                changed = True
        if changed:
            s = ' '.join(words)
        return s

    def generate_item(self, name, value):
        if value:
            return """<tr>
<td align="right" valign="top"><b>%s:</b></td><td valign="bottom">%s</td>
</tr>""" % (name, value)

        else:
            return ""

    def generate_group(self, title, items):
        return """
 <table class="textpadding" width="567px">
  <tr vAlign="top">
        <td height="55" width="100%%"><table class="textpadding" cellSpacing="0" align="left" bgColor="LightGrey" border="0" width="100%%">
<tbody>
          <tr>
            <td height="37"><table class="textpadding" cellSpacing="0" cellPadding="5" bgColor="#ffffff" border="0" width="100%%">
<tbody>
              <tr bgColor="LightGrey">
                <td id="textpaddingtitle" noWrap align="middle" bgColor="LightGrey" height="14" width="100%%">
                  <font face="arial" color="Black" size="-1">
                    <b>
                      <p align="left">
%s
                      </p>
                    </b>
                  </font>
                </td>
              </tr>
              <tr vAlign="top">
                <td class="notes"><table class="notes">
%s
                </table>

                </td>
              </tr>
</tbody>
            </table>
            </td>
          </tr>
</tbody>
        </table>
        </td>
      </tr><!-- End -->

 </table>""" % (title,
                # If an item is a string, it is already HTML, if not, call generate_item to get the HTML.
                ''.join([self.generate_item(*item) if item.__class__.__name__=='tuple' else item for item in items]))


def get_oltg(mnemonic):
    o = list(models.session.query(Oltg).filter(Oltg.mnemonic == mnemonic))
    if len(o) != 1:
        raise Exception('Expected 1 Oltg object to match mnemonic %s, got %d: %s' % mnemonic, (len(o), o))
    return o[0]                         # Get the one object.


if __name__ == '__main__':
    mnemonic = 'NA'                     # General good test
    mnemonic = 'RALKT'                  # Many reference ranges, F-M diff in len
    o = get_oltg(mnemonic)
    d = OltgDisplay(o)
    with open('/tmp/o.html', 'w') as out:
        out.write("""
<html>
  <head>
    <title>
    %s
    </title>
  </head>
  <meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
  <link href="http://www.washington.edu/favicon.ico" rel="shortcut icon">
  <link href="http://byblos.labmed.washington.edu/bcard/LMstyle_home.css" type="text/css" rel="stylesheet">
  <style type="text/css"></style>
  <body>
%s
  </body>
</html>
""" % (mnemonic, d.to_html()))
    print o
