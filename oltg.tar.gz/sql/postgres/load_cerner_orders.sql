--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2012 University of Washington Laboratory Medicine
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Laboratory Medicine and is
--    not to be disclosed to any third party without prior express
--    written permission of University of Washington Laboratory Medicine.
--    University of Washington Laboratory Medicine, as the
--    author and owner under 17 U.S.C. Sec. 201(b) of this work made
--    for hire, claims copyright in this material as an unpublished 
--    work under 17 U.S.C. Sec.s 102 and 104(a)   
-- 
--  *********************************************************************


-- These are dummy cerner_orders rows that causes the OLTG to display
-- "Orderable by lab only" or "Order Using 'Lab Undefined Order'" for the
-- cerner detail.

INSERT INTO mastermu_oltg.cerner_orders
  (code, lab_mnemonic, primary_name, primary_name_hidden, active, updated_date, ready_for_delete)
  VALUES(0, 'lab_only', 'Orderable by lab only', FALSE, TRUE, timestamp '2000-01-01', FALSE);
INSERT INTO mastermu_oltg.cerner_synonyms
  (cerner_order_code, name, is_primary, updated_date, ready_for_delete)
  VALUES(0, 'Orderable by lab only', TRUE, timestamp '2000-01-01', FALSE);
INSERT INTO mastermu_oltg.cerner_synonym_displays
  (cerner_synonym_id, show) VALUES (currval('cerner_synonyms_id_seq'), TRUE);


INSERT INTO mastermu_oltg.cerner_orders
  (code, lab_mnemonic, primary_name, primary_name_hidden, active, updated_date, ready_for_delete)
  VALUES(1, 'using_labund', E'Order Using \'Lab Undefined Order\'', FALSE, TRUE, timestamp '2000-01-01', FALSE);
INSERT INTO mastermu_oltg.cerner_synonyms
  (cerner_order_code, name, is_primary, updated_date, ready_for_delete)
  VALUES(1, E'Order Using \'Lab Undefined Order\'', TRUE, timestamp '2000-01-01', FALSE);
INSERT INTO mastermu_oltg.cerner_synonym_displays
  (cerner_synonym_id, show) VALUES (currval('cerner_synonyms_id_seq'), TRUE);


INSERT INTO mastermu_oltg.cerner_orders
  (code, lab_mnemonic, primary_name, primary_name_hidden, active, updated_date, ready_for_delete)
  VALUES(2, 'contact_lab', '(Contact Lab For Information)', FALSE, TRUE, timestamp '2000-01-01', FALSE);
INSERT INTO mastermu_oltg.cerner_synonyms
  (cerner_order_code, name, is_primary, updated_date, ready_for_delete)
  VALUES(2, '(Contact Lab For Information)', TRUE, timestamp '2000-01-01', FALSE);
INSERT INTO mastermu_oltg.cerner_synonym_displays
  (cerner_synonym_id, show) VALUES (currval('cerner_synonyms_id_seq'), TRUE);
