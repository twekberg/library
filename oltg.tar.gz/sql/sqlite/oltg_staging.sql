--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2011 University of Washington Laboratory Medicine
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Laboratory Medicine and is
--    not to be disclosed to any third party without prior express
--    written permission of University of Washington Laboratory Medicine.
--    University of Washington Laboratory Medicine, as the
--    author and owner under 17 U.S.C. Sec. 201(b) of this work made
--    for hire, claims copyright in this material as an unpublished 
--    work under 17 U.S.C. Sec.s 102 and 104(a)   
-- 
--  *********************************************************************


CREATE TABLE IF NOT EXISTS "oltg_staging" (
  "mnemonic" varchar(16) NOT NULL PRIMARY KEY,
  "name" varchar(100),                  -- name1
  "lab_name" varchar(100) NOT NULL,     -- lab_name
  "orca_name" varchar(100),
  "orca_name_updated" datetime,
  "epic_name" varchar(100),
  "hospital" varchar(1) NOT NULL,       -- hosp
  "tbp_type" varchar(1),                -- type
  "dept_code" varchar(6),               -- dept
  "dept_full_name" varchar(50),         -- dept_name
  "test_info" text,                     -- testinfo
  "unit" varchar(30),                   -- unit
  "order_flag" varchar(1),              -- oflg
  "suppress_print_flag" varchar(1),     -- spflg
  "specimen_type" varchar(300),         -- sptype
  "specimen_handling" text,             -- sphand_1
  "collection" text,                    -- collect_1
  "amount" varchar(300),                -- amount
  "minimum_amount" varchar(300),        -- minimum
  "done_uwmc" varchar(100),             -- done_uwmc
  "done_hmc"  varchar(100),             -- done_hmc
  "done_other"  varchar(300),           -- done_oth_1
  "frequency" varchar(500),             -- freq_1
  "processing_instructions" text,       -- processing
  "method" varchar(500),                -- method
  "available_stat" varchar(500),        -- avlstat
  "updated_date" datetime,              -- updated
  "security_flag" varchar(1),           -- secflg
  "reference_range_addendum" text,      -- bcRR-1
  "reference_range_notes" varchar(50),  -- text in rrEffDate
  "reference_range_effective_date" datetime,-- rreffdate
  "reference_range_units" varchar(50),  -- rrunits
  "was_changed" boolean NOT NULL DEFAULT FALSE, -- User edited this test
  "additional_billing"  varchar(300)            -- compliance requirement
);
