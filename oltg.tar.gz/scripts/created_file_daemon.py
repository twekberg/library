#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
This daemon looks for a file to be created and closed.
This was written to automatically update the OLTG database using the LIS feed
file bcDump.  When that happens, the program that processes that feed is
executed.

Example:
sudo python scripts/created_file_daemon.py start scan_lis \
  --cd /home/tekberg/src/mastermu/trunk/oltg \
  /home/cstaff/bcDump-LABA.lis /home/transfers/bcDump-LABA.lis

It is possible to have other files be checked and processed.  That, of course,
would require a code change.
"""

import pydaemonize.inotify
import pyinotify
import syslog
import argparse
import traceback
import os
import sys

from oltg.runoltg import main as oltg_main


DESCRIPTION = __doc__.strip()
# Relocate the pidfile_directory since /var/run (the default) is owned by root
# and does not allow group/other to write.
pidfile_directory = '/var/tmp/run'


class FileDaemon(object):
    def __init__(self, arguments, handler, state_transitions, event_mask_mapper):
        self.handler = handler
        self.current_state = 0
        self.state_transitions = state_transitions
        self.event_mask_mapper = event_mask_mapper
        file = arguments.file if 'file' in arguments else []
        cwd = arguments.cd if 'cd' in arguments else None
        pydaemonize.inotify.daemon(file,
                                   name='created_file_daemon',
                                   user=os.environ.get('USER', 'daemon'),
                                   pidfile_directory = pidfile_directory,
                                   # os.chdir() # returns None
                                   callback=lambda _, event: (os.chdir(cwd) if cwd else None) or self.callback(event))


    def callback(self, event):
        """Called on each event from inotify."""
        if self.handle_event(event.mask):
            self.handler(event.path)


    def handle_event(self, event_mask):
        """
        Transitions to the next state based on the event mask.
        Returns the action True/False flag.
        """
        (self.current_state, action) = self.state_transitions[self.current_state][self.event_mask_mapper(event_mask)]
        return action


def parse_arguments(argv):
    """
    Look at the command line arguments.
    """
    parser = argparse.ArgumentParser(description=DESCRIPTION,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)

    subparsers = parser.add_subparsers(dest='subparser_name')

    parser_help = subparsers.add_parser(
        'help', help='Detailed help for actions using `help <action>`')

    parser_help.add_argument('action', nargs=1)

    start_parser = subparsers.add_parser('start', help='Start daemon')
    start_parser.add_argument('--cd', action="store",
                              help="Use this when the subcommand must be running in a specific directory.")
    start_parser.add_argument('subcommand', action="store",
                        help="""This is the runoltg subcommand to call when the file is created.
For example: scan_lis.
To determine the possible subcommands execute this from the command line: ./runoltg -h
""")
    start_parser.add_argument('file', action="store", nargs='+',
                        help='This is the file whose creation is to be checked.')


    stop_parser = subparsers.add_parser('stop', help='Stop daemon')

    restart_parser = subparsers.add_parser('restart', help='Stop/Start daemon')

    arguments = parser.parse_args(argv)
    action = arguments.subparser_name

    # Support help <action> by simply having this function call itself and
    # translate the arguments into something that argparse can work with.
    if action == 'help':
        return parse_arguments([str(arguments.action[0]), '-h'])
    return (action, arguments)


# Simple state transition table for creating a file.
# Starts with IN_OPEN, then one or more IN_MODIFY followed by IN_CLOSE_WRITE.
# Each row corresponds to a particular state.
# Each column corresponds to an event mask.
# Each tuple contains the next state, and a boolean indicating whether
# the action needs to be performed or not.
create_transitions = [
        # IN_OPEN   IN_MODIFY  IN_CLOSE_WRITE  Unknown
        [(1,False), (0,False), (0, False),     (0, False)],  # 0 scan for IN_OPEN
        [(1,False), (2,False), (0, False),     (0, False)],  # 1 scan for IN_MODIFY
        [(1,False), (2,False), (0, True),      (0, False)],  # 2 >=1 IN_MODIFY and IN_CLOSE_WRITE
        ]


def create_event_mask_mapper(event_mask):
    cols = {pyinotify.IN_OPEN:0,
            pyinotify.IN_MODIFY:1,
            pyinotify.IN_CLOSE_WRITE:2,
            }
    if event_mask in cols:
        return cols[event_mask]
    return max(cols.values()) + 1       # Last state column


if __name__ == '__main__':
    (action, arguments) = parse_arguments(sys.argv[1:])
    # The pydaemonize code gets the arguments from sys.argv.
    sys.argv = [sys.argv[0], action]
    try:
        FileDaemon(arguments,
                   lambda file: oltg_main([arguments.subcommand, file]),
                   #lambda file: syslog.syslog(syslog.LOG_NOTICE, 'Performing action for file %s' % (file,)),
                   create_transitions, create_event_mask_mapper)
    except Exception as e:
        tb = traceback.format_exc()
        syslog.syslog(syslog.LOG_NOTICE, 'Error encountered: %s: %s' % (e, tb))
