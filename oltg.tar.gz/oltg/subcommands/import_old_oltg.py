#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Import the old OLTG that came from byblos into MySQL.
"""

# Example:
#   python python/scan_fee_schedule.py ~/SANDBOX/CLAB2011_Fee.xls

import sys
reload(sys)
sys.setdefaultencoding('8859')

import argparse
from datetime import datetime
import os
import os.path
import re
import sys
import warnings
import xlrd

import sqlalchemy.exc

import oltg.models
import oltg.models.object_queries as object_queries
from oltg.models.create_models import OldOltg
from oltg.models.messages import Messages
import oltg.subcommands


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('oltg_file', action="store",
                        help='This is the file that contains the old OLTG CSV data.')


def action(args):
    """
    Scan the old OLTG file.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    messages = Messages(session, 'Load old OLTG')
    try:
        filename = args.oltg_file
        ok = False
        messages.store('started')
        session.query(OldOltg).delete()
        session.commit()
        try:
            count = 0
            if d['db_type'] == 'postgresql':
                messages.store('Use scripts/import-old-oltg to import old OLTG data into postgres. It is much faster.')
            else:
                session.execute('TRUNCATE TABLE mastermu.oltg')
                with open(filename) as in_file:
                    first_line = True
                    for line in in_file:
                        if first_line:
                            first_line = False
                            # Get the column headers.
                            column_headers = [sqlify(col) for col in line.split(',')]
                        else:
                            row = re.findall(r'"([^"]*)"(?:,|$)', line)
                            o = OldOltg()
                            for (name,value) in zip(column_headers, row):
                                o.set(name, value)
                            session.add(o)
                            count += 1
                session.commit()
                ok = True
        except Exception as e:
            # Unexpected exception.
            messages.store('Caught exception', ok, e)
        messages.store('completed. count=%d' % (count,), ok)
    finally:
        oltg.models.release_session(session, engine)
    return 0 if ok else 1               # exit status


def sqlify(col):
    """
    Convert to name suitable for SQL.
    """
    # Remove leading/trailing double quotes.
    if col.startswith('"'):
        col = col[1:]
    if col.endswith('"'):
        col = col[:-1]
    return col.lower().replace('-', '_').replace('#', 'number')


#def init(input_filename):
    # Get truncation warnings of the form:
    #   /usr/local/lib/python2.6/site-packages/SQLAlchemy-0.6.6-py2.6.egg/sqlalchemy/engine/default.py:299:
    #   Warning: Data truncated for column 'reimbursement' at row 1
    #   cursor.execute(statement, parameters)
    # This happens because the reimbursement values are stored as single precision floats, but are
    # read as double precision floats. Those reimbursement values that can not
    # be represented as a float, get truncation errors.
    # The following code will cause this warning to ignored, instead of printing to stderr.
    #warnings.filterwarnings(action="ignore", message="Data truncated for column 'reimbursement'")
    #warnings.filterwarnings(action="ignore", message="BaseException.message has been deprecated")
    pass
