#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Copy the data from the staging tables to the production tables.

No need to truncate the production tables prior to running this program.  It is
done automatically, if needed.

This should take about a second to execute.
"""

# Example:
#   python python/push_to_prod.py

import argparse
import sys
import datetime

import oltg.subcommands
import oltg.models
from oltg.models.create_models import (Oltg,
                                       OltgStaging,
                                       BillingAndCptCode,
                                       BillingAndCptCodeStaging,
                                       CautionUrl,
                                       CautionUrlStaging,
                                       ComponentTest,
                                       ComponentTestStaging,
                                       CrossReference,
                                       CrossReferenceStaging,
                                       ReferenceRange,
                                       ReferenceRangeStaging)
from oltg.models.messages import Messages
from oltg.models.db_specific import update_sequences


production_classes = [Oltg, BillingAndCptCode, CautionUrl,
                      ComponentTest, CrossReference, ReferenceRange]

staging_classes = [eval(prod.__name__ + 'Staging') for prod in production_classes]

production_tables = [prod.table_name for prod in production_classes]

staging_tables = [stage.table_name for stage in staging_classes]

debug = False


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('-m', '--mnemonics', nargs = '*',
                        help = 'optional list of lab mnemonics; pushes all if not provided.',
                        default = [])


def action(args):
    """
    Truncate the production and copy the staging data.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    return push(session, engine, d['db_type'], [m.upper() for m in args.mnemonics])


def push(session, engine, db_type, mnemonics):
    """
    Call this if you already have the session.

    Note: if mnemonics is [] then do all of them.
    """
    global debug
    messages = Messages(session, 'Push to Prod')
    try:
        ok = False
        messages.store('started for %s' % (', '.join(mnemonics)) if mnemonics else 'All')
        try:
            if debug:
                print "Starting deletes"
            for tab in production_tables:
                if mnemonics:
                    sql = "DELETE FROM mastermu_oltg.%s WHERE mnemonic IN ('%s')" % (tab, "','".join(mnemonics))
                    session.execute(sql)
                    if debug:
                        print '%s\nDeleted %s from %s' % (sql, ','.join(mnemonics), tab)
                else:
                    sql = 'DELETE FROM mastermu_oltg.%s' % (tab,)
                    session.execute(sql)
                    if debug:
                        print '%s\nDeleted all %s' % (sql, tab)
                session.commit()
            if debug:
                print "Deletes complete. Starting to reset was_changed."
            # Now reset the was_changed flag to note that there are no pending pushes.
            if mnemonics:
                sql = "UPDATE mastermu_oltg.oltg_staging SET was_changed = FALSE WHERE mnemonic IN ('%s')" % ("','".join(mnemonics),)
            else:
                sql = "UPDATE mastermu_oltg.oltg_staging SET was_changed = FALSE"
            r = session.execute(sql)
            if debug:
                print '%s\nwas_changed rowcount=%s' % (sql, r.rowcount)
            session.commit()

            if debug:
                print "Starting push."
            for (prod, stage) in zip(production_tables, staging_tables):
                if mnemonics:
                    sql = "INSERT INTO mastermu_oltg.%s SELECT * FROM mastermu_oltg.%s WHERE mnemonic IN ('%s')" % (prod, stage, "','".join(mnemonics))
                else:
                    sql = 'INSERT INTO mastermu_oltg.%s SELECT * FROM mastermu_oltg.%s' % (prod, stage)
                r = session.connection().execute(sql)
                if debug:
                    print '%s\nprod=%s, r.rowcount=%s' % (sql, prod, r.rowcount)
            session.commit()

            update_sequences(db_type, session)
            if debug:
                print "DB copy complete"
            ok = True
        except Exception as e:
            # Unexpected exception.
            messages.store('Caught exception', ok, e)
        messages.store('completed', ok)
    finally:
        oltg.models.release_session(session, engine)
    return 0 if ok else 1               # exit status
