#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Controller for the search page.
"""

from datetime import datetime

import oltg
from oltg.controllers import app
from oltg.controllers.display import display_page
from oltg.controllers.edit import edit
from oltg.controllers.common import common_namespace
import oltg.models
import oltg.models.access_log as access_log
from oltg.templates.Search import Search
from oltg.templates.Welcome import Welcome
from oltg.models.db_specific import full_text_where, full_text_string
from oltg.models.tally_rankings import tally_rankings_map


def search_page(environ, start_response, logger):
    """Search page."""
    session = environ['SESSION']
    staff_only = environ.get('STAFF_ONLY', False)
    edit_mode = environ.get('EDIT_MODE', False)
    config_dict = environ['CONFIG']
    db_type = config_dict['db_type']
    parameters = environ[app + '.parameters']
    message = ''
    if 'search_type' in parameters:
        search_type = parameters['search_type']
        first_time = False
    else:
        # No search_type. Use '' instead of None so it goes into the VALUE
        # attribute of the search_type INPUT box.
        search_type = ''
        first_time = True
    search_text = parameters.get('search_text', '')
    action = parameters.get('action', 'search') # Default to search
    # The search_as_component and search_cross_reference are checkboxes which
    # should default to checked.  This will only happen the first time the user
    # enters the page.
    if first_time:
        search_as_component = parameters.get('search_as_component', 'yes')
        search_cross_reference = parameters.get('search_cross_reference', 'yes')
    else:
        search_as_component = parameters.get('search_as_component', '')
        search_cross_reference = parameters.get('search_cross_reference', '')

    access_log.Writer(config_dict['access_log_file']).write(staff_only, edit_mode,
                                                            environ.get('REMOTE_USER', 'Unknown'),
                                                            environ.get('REMOTE_ADDR', 'Unknown'),
                                                            'search',
                                                            'search_as_component="%s", search_cross_reference="%s", text="%s"' % (search_as_component, search_cross_reference, search_text))

    have_search_results = False
    search_results = []
    if action == 'search':
        # TODO: it should be possible to determine the database type
        # from the session object, so passing in db_type should not be
        # necessary.
        (have_search_results, search_results) = search(session, db_type, search_type, search_text,
                                                       search_as_component, search_cross_reference,
                                                       staff_only, edit_mode)
        if (not have_search_results) and not first_time:
            message = "Please enter a test mnemonic or a search string and click the search button."
        if len(search_results) == 1:
            # Only one match. Go directly to the display or edit page.
            parameters['mnemonic'] = search_results[0][0]
            return (edit if edit_mode else display_page)(environ, start_response, logger)
    else:
        message = 'Internal error: unknown action "%s"' % (action,)

    start_response('200 OK', [('Content-Type', 'text/html')])
    namespace = common_namespace(environ, config_dict, first_time=first_time)
    namespace.update(dict(
        have_search_results =   have_search_results,
        search_results =        search_results,
        ))
    if first_time:
        t = Welcome(searchList = [namespace])
    else:
        t = Search(searchList = [namespace])
    return [str(t.respond())]


def search(session, db_type, search_type, search_text, search_as_component,
           search_cross_reference, staff_only, edit_mode):
    """
    Basic search.

    Returns {have_search_results, search_results)
    have_search_results si a booloean indicating whether or not we tried to do a search. The
    boolean is false if no search was done.

    search_results is a list of the search results, if any.
    """
    have_search_results = True          # Assume we have search results
    if search_type == 'mnemonic':
        search_results = get_mnemonic_search(session, db_type, search_text, search_as_component, search_cross_reference, staff_only, edit_mode)
    elif search_type == 'text':
        search_results = get_text_search(session, db_type, search_text, search_as_component, search_cross_reference, staff_only, edit_mode)
    else:
        search_results = []
        have_search_results = False
    # Convert the tally count to bullets.
    search_results = [(mnemonic, name, specimen_type, map_tally_count_to_level(total), 
                       total, sendout) for (mnemonic, name, specimen_type, total, sendout) in search_results]
    return (have_search_results, search_results)


def map_tally_count_to_level(count):
    """
    Map a tally count for a test to a string.
    """
    for rank in sorted(tally_rankings_map.keys()):
        if count <= tally_rankings_map[rank]:
            return '&bull;' * rank
    # Bigger than expected. The tally data is probably stale.
    return '&bull;' * len(tally_rankings_map)


# -----------------------------------------------------------------------------

def get_mnemonic_search(session, db_type, mnemonic, search_as_component, search_cross_reference, staff_only, edit_mode):
    """
    Retieve the details for a test whose mnemonic that exactly matches the
    search parameter.
    """
    mnemonic = mnemonic.upper()
    if search_as_component:
        sql = """
SELECT oltg.mnemonic,
  CASE WHEN oltg.name IS NOT NULL AND oltg.name != '' THEN oltg.name
       ELSE oltg.lab_name
  END AS "name",
  CASE WHEN oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '' THEN oltg.specimen_type
       ELSE ''
  END AS "specimen_type",
  CASE WHEN t.total IS NULL THEN 0
       ELSE t.total
  END AS "total",
  CASE WHEN substr(b.billing_code, 1, 5) IN ('10584','10585') OR
            (oltg.done_uwmc='SO' AND oltg.done_hmc='SO') THEN 'Sendout'
       ELSE ''
  END || ',' ||
  CASE WHEN security_flag = 'I' THEN 'Staff Only'
  ELSE CASE WHEN security_flag = 'N' THEN 'Not Shown'
       ELSE ''
       END
  END AS "notes"
FROM mastermu_oltg.oltg{suffix} oltg
LEFT OUTER JOIN mastermu_oltg.dept_tally_view t ON oltg.mnemonic = t.mnemonic
LEFT OUTER JOIN mastermu_oltg.billing_and_cpt_codes{suffix} b
ON oltg.mnemonic = b.mnemonic AND substr(b.billing_code, 1, 5) IN ('10584','10585')
WHERE oltg.mnemonic = :mnemonic
  AND {order_flag}
  AND {security_setting}
UNION DISTINCT
-- Go up one level. Get T -> B and T -> P.
SELECT oltg.mnemonic,
  CASE WHEN oltg.name IS NOT NULL AND oltg.name != '' THEN oltg.name
       ELSE oltg.lab_name
  END AS "name",
  CASE WHEN oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '' THEN oltg.specimen_type
       ELSE ''
  END AS "specimen_type",
  CASE WHEN t.total IS NULL THEN 0
       ELSE t.total
  END AS "total",
  CASE WHEN substr(b.billing_code, 1, 5) IN ('10584','10585') OR
            (oltg.done_uwmc='SO' AND oltg.done_hmc='SO') THEN 'Sendout'
       ELSE ''
  END || ',' ||
  CASE WHEN security_flag = 'I' THEN 'Staff Only'
  ELSE CASE WHEN security_flag = 'N' THEN 'Not Shown'
       ELSE ''
       END
  END AS "notes"
FROM mastermu_oltg.oltg{suffix} oltg
JOIN mastermu_oltg.component_tests{suffix} c ON oltg.mnemonic = c.mnemonic
LEFT OUTER JOIN mastermu_oltg.dept_tally_view t ON oltg.mnemonic = t.mnemonic
LEFT OUTER JOIN mastermu_oltg.billing_and_cpt_codes{suffix} b
ON oltg.mnemonic = b.mnemonic AND substr(b.billing_code, 1, 5) IN ('10584','10585')
WHERE c.component_mnemonic IN 
  (SELECT o2.mnemonic
   FROM mastermu_oltg.oltg{suffix} o2
   WHERE o2.mnemonic = :mnemonic
  )
  AND {order_flag}
  AND {security_setting}
UNION DISTINCT
-- Going from parent batteries to grandparent packages: T -> B -> P
SELECT oltg.mnemonic,
  CASE WHEN oltg.name IS NOT NULL AND oltg.name != '' THEN oltg.name
       ELSE oltg.lab_name
  END AS "name",
  CASE WHEN oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '' THEN oltg.specimen_type
       ELSE ''
  END AS "specimen_type",
  CASE WHEN t.total IS NULL THEN 0
       ELSE t.total
  END AS "total",
  CASE WHEN substr(b.billing_code, 1, 5) IN ('10584','10585') OR
            (oltg.done_uwmc='SO' AND oltg.done_hmc='SO') THEN 'Sendout'
       ELSE ''
  END || ',' ||
  CASE WHEN security_flag = 'I' THEN 'Staff Only'
  ELSE CASE WHEN security_flag = 'N' THEN 'Not Shown'
       ELSE ''
       END
  END AS "notes"
FROM mastermu_oltg.oltg{suffix} oltg
JOIN mastermu_oltg.component_tests{suffix} c ON oltg.mnemonic = c.mnemonic
LEFT OUTER JOIN mastermu_oltg.dept_tally_view t ON oltg.mnemonic = t.mnemonic
LEFT OUTER JOIN mastermu_oltg.billing_and_cpt_codes{suffix} b
ON oltg.mnemonic = b.mnemonic AND substr(b.billing_code, 1, 5) IN ('10584','10585')
WHERE c.component_mnemonic IN 
  (SELECT distinct(o2.mnemonic)
   FROM mastermu_oltg.component_tests{suffix} c2
   JOIN mastermu_oltg.oltg{suffix} o2 ON o2.mnemonic = c2.mnemonic
   WHERE c2.component_mnemonic IN 
     (SELECT o3.mnemonic
      FROM mastermu_oltg.oltg{suffix} o3
      WHERE o3.mnemonic = :mnemonic
     )
     AND o2.tbp_type = 'B'
  )
  AND {order_flag}
  AND {security_setting}
ORDER BY 4 DESC,1;"""
    else:
        sql = """
SELECT oltg.mnemonic,
  CASE WHEN oltg.name IS NOT NULL AND oltg.name != '' THEN oltg.name
       ELSE oltg.lab_name
  END AS "name",
  CASE WHEN oltg.specimen_type IS NOT NULL AND oltg.specimen_type != '' THEN oltg.specimen_type
       ELSE ''
  END AS "specimen_type",
  CASE WHEN t.total IS NULL THEN 0
       ELSE t.total
  END AS "total",
  CASE WHEN substr(b.billing_code, 1, 5) IN ('10584','10585') OR
            (oltg.done_uwmc='SO' AND oltg.done_hmc='SO') THEN 'Sendout'
       ELSE ''
  END || ',' ||
  CASE WHEN security_flag = 'I' THEN 'Staff Only'
  ELSE CASE WHEN security_flag = 'N' THEN 'Not Shown'
       ELSE ''
       END
  END AS "notes"
FROM mastermu_oltg.oltg{suffix} AS oltg
LEFT OUTER JOIN mastermu_oltg.dept_tally_view AS t ON oltg.mnemonic = t.mnemonic
LEFT OUTER JOIN mastermu_oltg.billing_and_cpt_codes{suffix} AS b
ON oltg.mnemonic = b.mnemonic AND substr(b.billing_code, 1, 5) IN ('10584','10585')
WHERE oltg.mnemonic = :mnemonic
  AND {order_flag}
  AND {security_setting}
ORDER BY 4 DESC,1;"""
    clauses = dict(
        suffix = '',
        )
    if edit_mode:
        # Edit mode allows editing of all tests.
        clauses['security_setting'] = "1=1"
        clauses['suffix'] = '_staging'
        clauses['order_flag'] = "2=2"
    elif staff_only:
        clauses['security_setting'] = "security_flag != 'N'"
        clauses['order_flag'] = "(oltg.order_flag = 'Y' OR oltg.order_flag = 'B' OR oltg.order_flag IS NULL OR oltg.order_flag = '')"
    else:
        clauses['security_setting'] = "security_flag = 'E'"
        clauses['order_flag'] = "(oltg.order_flag = 'Y' OR oltg.order_flag IS NULL OR oltg.order_flag = '')"
    sql = sql.format(**clauses)
    #raise Exception('TWE mnemonic=%s, clauses=%s, sql=%s' % (mnemonic, clauses, sql))
    return list(session.execute(sql, {'mnemonic':mnemonic}))


def get_text_search(session, db_type, search_text, search_as_component, search_cross_reference, staff_only, edit_mode):
    """
    For single words, add a * to the end.
    For multi-word case, add a + in front of every word. Add a * after words whose length >=3.
    Retrieve the deteils for a test whose name or cross reference matches the search parameter.
    staff_only - show test that outside people shouldn't see.
    """

    # This big query has 3 parts, separated by UNION DISTINCT
    # Part 1 gets all of the tests that match full text. Call this set of mnemonics T.
    # Part 2 gets all of T's parents, which can be either batteries or packages (panels).
    # Call the batteries in this set of mnemonics B.
    # Part 3 gets all of B's parents, which will be packages.

    if search_as_component:
        sql = """
SELECT o1.mnemonic,
  CASE WHEN o1.name IS NOT NULL AND o1.name != '' THEN o1.name
       ELSE o1.lab_name
  END AS "name",
  CASE WHEN o1.specimen_type IS NOT NULL AND o1.specimen_type != '' THEN o1.specimen_type
       ELSE ''
  END AS "specimen_type",
  CASE WHEN t.total IS NULL THEN 0
       ELSE t.total
  END AS "total",
  CASE WHEN substr(b.billing_code, 1, 5) IN ('10584','10585') OR
            (o1.done_uwmc='SO' AND o1.done_hmc='SO') THEN 'Sendout'
       ELSE ''
  END || ',' ||
  CASE WHEN security_flag = 'I' THEN 'Staff Only'
  ELSE CASE WHEN security_flag = 'N' THEN 'Not Shown'
       ELSE ''
       END
  END AS "notes"
FROM mastermu_oltg.oltg{suffix} o1
{join_xref_1}
LEFT OUTER JOIN mastermu_oltg.dept_tally_view t ON o1.mnemonic = t.mnemonic
LEFT OUTER JOIN mastermu_oltg.billing_and_cpt_codes{suffix} b
ON o1.mnemonic = b.mnemonic AND substr(b.billing_code, 1, 5) IN ('10584','10585')
  WHERE
  ({full_text_1}
   OR {xref_match_1}
  )
  AND {order_flag}
  AND {security_setting}
UNION DISTINCT
-- Go up one level. Get T -> B and T -> P.
SELECT o1.mnemonic,
  CASE WHEN o1.name IS NOT NULL AND o1.name != '' THEN o1.name
       ELSE o1.lab_name
  END AS "name",
  CASE WHEN o1.specimen_type IS NOT NULL AND o1.specimen_type != '' THEN o1.specimen_type
       ELSE ''
  END AS "specimen_type",
  CASE WHEN t.total IS NULL THEN 0
       ELSE t.total
  END AS "total",
  CASE WHEN substr(b.billing_code, 1, 5) IN ('10584','10585') OR
            (o1.done_uwmc='SO' AND o1.done_hmc='SO') THEN 'Sendout'
       ELSE ''
  END || ',' ||
  CASE WHEN security_flag = 'I' THEN 'Staff Only'
  ELSE CASE WHEN security_flag = 'N' THEN 'Not Shown'
       ELSE ''
       END
  END AS "notes"
FROM mastermu_oltg.oltg{suffix} o1
JOIN mastermu_oltg.component_tests{suffix} c ON o1.mnemonic = c.mnemonic
LEFT OUTER JOIN mastermu_oltg.dept_tally_view t ON o1.mnemonic = t.mnemonic
LEFT OUTER JOIN mastermu_oltg.billing_and_cpt_codes{suffix} b
ON o1.mnemonic = b.mnemonic AND substr(b.billing_code, 1, 5) IN ('10584','10585')
WHERE c.component_mnemonic IN 
  (SELECT o2.mnemonic
   FROM mastermu_oltg.oltg{suffix} o2
  {join_xref_2}
   WHERE
   {full_text_2}
   OR {xref_match_2}
  )
  AND {order_flag}
  AND {security_setting}
UNION DISTINCT
-- Going from parent batteries to grandparent packages: T -> B -> P
SELECT o1.mnemonic,
  CASE WHEN o1.name IS NOT NULL AND o1.name != '' THEN o1.name
       ELSE o1.lab_name
  END AS "name",
  CASE WHEN o1.specimen_type IS NOT NULL AND o1.specimen_type != '' THEN o1.specimen_type
       ELSE ''
  END AS "specimen_type",
  CASE WHEN t.total IS NULL THEN 0
       ELSE t.total
  END AS "total",
  CASE WHEN substr(b.billing_code, 1, 5) IN ('10584','10585') OR
            (o1.done_uwmc='SO' AND o1.done_hmc='SO') THEN 'Sendout'
       ELSE ''
  END || ',' ||
  CASE WHEN security_flag = 'I' THEN 'Staff Only'
  ELSE CASE WHEN security_flag = 'N' THEN 'Not Shown'
       ELSE ''
       END
  END AS "notes"
FROM mastermu_oltg.oltg{suffix} o1
JOIN mastermu_oltg.component_tests{suffix} c ON o1.mnemonic = c.mnemonic
LEFT OUTER JOIN mastermu_oltg.dept_tally_view t ON o1.mnemonic = t.mnemonic
LEFT OUTER JOIN mastermu_oltg.billing_and_cpt_codes{suffix} b
ON o1.mnemonic = b.mnemonic AND substr(b.billing_code, 1, 5) IN ('10584','10585')
WHERE c.component_mnemonic IN
  (SELECT distinct(o2.mnemonic)
   FROM mastermu_oltg.component_tests{suffix} c2
   JOIN mastermu_oltg.oltg{suffix} o2 ON o2.mnemonic = c2.mnemonic
   WHERE c2.component_mnemonic IN 
     (SELECT o3.mnemonic
      FROM mastermu_oltg.oltg{suffix} o3
      {join_xref_3}
      WHERE
      {full_text_3}
      OR {xref_match_3}
     )
     AND o2.tbp_type = 'B'
  )
  AND {order_flag}
  AND {security_setting}
ORDER BY 4 DESC,1"""
    else:
        sql = """
SELECT DISTINCT
  o1.mnemonic,
  CASE WHEN o1.name IS NOT NULL AND o1.name != '' THEN o1.name
       ELSE o1.lab_name
  END AS "name",
  CASE WHEN o1.specimen_type IS NOT NULL AND o1.specimen_type != '' THEN o1.specimen_type
       ELSE ''
  END AS "specimen_type",
  CASE WHEN t.total IS NULL THEN 0
       ELSE t.total
  END AS "total",
  CASE WHEN substr(b.billing_code, 1, 5) IN ('10584','10585') OR
            (o1.done_uwmc='SO' AND o1.done_hmc='SO') THEN 'Sendout'
       ELSE ''
  END || ',' ||
  CASE WHEN security_flag = 'I' THEN 'Staff Only'
  ELSE CASE WHEN security_flag = 'N' THEN 'Not Shown'
       ELSE ''
       END
  END AS "notes"
FROM mastermu_oltg.oltg{suffix} o1
{join_xref_1}
LEFT OUTER JOIN mastermu_oltg.dept_tally_view t ON o1.mnemonic = t.mnemonic
LEFT OUTER JOIN mastermu_oltg.billing_and_cpt_codes{suffix} b
ON o1.mnemonic = b.mnemonic AND substr(b.billing_code, 1, 5) IN ('10584','10585')
  WHERE
  ({full_text_1}
   OR {xref_match_1}
  )
  AND {order_flag}
  AND {security_setting}
ORDER BY 4 DESC,1"""
    clauses = dict(
        suffix = '',
        )
    for i in range(1,3+1):
        clauses['full_text_%d' % i] = full_text_where(db_type, 
            ("o%d.mnemonic o%d.name o%d.lab_name coalesce(o%d.orca_name,'') coalesce(o%d.epic_name,'')" % ((i,)*5)).split(' '))
    if search_cross_reference:
        for i in range(1,3+1):
            clauses['join_xref_%d' % i] = 'LEFT OUTER JOIN mastermu_oltg.cross_references%s c%d ON o%d.mnemonic = c%d.mnemonic' % ((clauses['suffix'],) + (i,) * 3)
            clauses['xref_match_%d' % i] = full_text_where(db_type, ['c%d.cross_reference' % (i,)])
    else:
        # If we aren't looking at cross references, we don't need to do the join.
        for i in range(1,3+1):
            clauses['join_xref_%d' % i] = ''
            clauses['xref_match_%d' % i] = '0=1' # OR
    if edit_mode:
        # Edit mode allows editing of all tests.
        clauses['security_setting'] = "2=2"      # AND
        clauses['order_flag'] = "2=2"      # AND
        clauses['suffix'] = '_staging'
    elif staff_only:
        clauses['security_setting'] = "security_flag != 'N'"
        clauses['order_flag'] = "(o1.order_flag = 'Y' OR o1.order_flag = 'B' OR o1.order_flag IS NULL OR o1.order_flag = '')"
    else:
        clauses['security_setting'] = "security_flag = 'E'"
        clauses['order_flag'] = "(o1.order_flag = 'Y' OR o1.order_flag IS NULL OR o1.order_flag = '')"
    sql = sql.format(**clauses)
    #raise Exception('TWE clauses=%s, edit_mode=%s, full_text_string=%s\n\nsql=%s' % (clauses, edit_mode, full_text_string(db_type, search_text), sql))
    return list(session.execute(sql, {'search_text': full_text_string(db_type, search_text)}))
