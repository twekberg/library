/* Common JS functions. */

//-----------------------------------------------------------------------------
/**
 * Get all of the attributes and their values for an object as a string. The
 * attribute/value pairs are sorted and are separated by ", ". If the length of
 * the value exceeds MAX_VALUE_LENGTH then the value is truncated and "..." is
 * appended.
 *
 * @param  object  the object whose attributes are to be extracted.
 *
 * @return
 *   String - nicely formatted attribute listing for the object, sorted by
 * attribute name.
 */
//-----------------------------------------------------------------------------
function getAttributes(object) {
    var MAX_VALUE_LENGTH = 50;
    var attribute;
    var value;
    var result = new Array();

    for (attribute in object) {
        try {
            // Some objects have trouble here, so we have to put it in a
            // try/catch block.
            value = (object[attribute] + "").replace("\n", "\\n");
        }
        catch (e) {
            value = "Exception:" + e.name;
        }
        if (value.length > MAX_VALUE_LENGTH)
            value = value.substring(0, MAX_VALUE_LENGTH) + "...";
        result[result.length] = attribute + "=" + value;
    }
    
    return (result.sort()).join(", ");
}


//-----------------------------------------------------------------------------
/**
 * Return a string which is the hexadecimal value of the characters comprising
 * the string.
 *
 * @param  s  the string to be converted to hex.
 *
 * @return
 *   String - hexadecimal representation of s.
 */
//-----------------------------------------------------------------------------
function toHex(s) {
    var i;
    var ch;
    var hex;
    var hexes = new Array();
    var ret;

    for(i=0; i<s.length; i++) {
        ch = s.charCodeAt(i);
        if (ch == 0)
            hex = "00";
        else {
            hex = "";
            if (ch < 0) {
                alert("too small: " + ch);
            }
            while(ch > 0) {
                hex = (ch % 16).toString(16).toUpperCase() + hex;
                ch = Math.floor(ch / 16);
            }
            if (hex.length < 2)
                hex = "0" + hex;
        }
        hexes[i] = hex;
    }

    ret = "";
    for(i=0; i<hexes.length; i+=4) {
        if (ret != "")
            ret = ret + " ";
        ret = ret + (hexes.slice(i, i+4)).join("");
    }
    return ret;
}

// TWE: Another hex dump utility that does a better
// job of formatting.
//
// Hexdump.js
// Matt Mower <self@mattmower.com>
// 08-02-2011
// License: MIT
//
// None of the other JS hex dump libraries I could find
// seemed to work so I cobbled this one together.
//

var Hexdump = {
	
	to_hex: function( number ) {
		var r = number.toString(16);
		if( r.length < 2 ) {
			return "0" + r;
		} else {
			return r;
		}
	},
	
	dump_chunk: function( chunk ) {
		var dumped = "";
		
		for( var i = 0; i < 4; i++ ) {
			if( i < chunk.length ) {
				dumped += Hexdump.to_hex( chunk.charCodeAt( i ) );
			} else {
				dumped += "..";
			}
		}
		
		return dumped;
	},
	
	dump_block: function( block ) {
		var dumped = "";
		
		var chunks = block.match( /.{1,4}/g );
		for( var i = 0; i < 4; i++ ) {
			if( i < chunks.length ) {
				dumped += Hexdump.dump_chunk( chunks[i] );
			} else {
				dumped += "........";
			}
			dumped += " ";
		}
		
		dumped += "    " + block.replace( /[\x00-\x1F]/g, "." );
		
		return dumped;
	},
	
	dump: function( s ) {
		var dumped = "";
		
		var blocks = s.match( /.{1,16}/g );
		for( var block in blocks ) {
			dumped += Hexdump.dump_block( blocks[block] ) + "\n";
		}
		
		return dumped;
	}
	
};
