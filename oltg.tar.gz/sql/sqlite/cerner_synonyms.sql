--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2012 University of Washington Medical Center
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Medical Center and is not to
--    be disclosed to any third party without prior express written
--    permission of University of Washington Medical Center University
--    of Washington Medical Center, as the author and owner under 17
--    U.S.C. Sec. 201(b) of this work made for hire, claims copyright
--    in this material as an unpublished work under 17 U.S.C. Sec.s 102
--    and 104(a)
-- 
--  ******************************************************************* 


-- Details for cerner names and synonyms.

CREATE TABLE IF NOT EXISTS cerner_synonyms (
  "id" INTEGER NOT NULL PRIMARY KEY AUTOINCREMENT,
  "cerner_order_code" INTEGER NOT NULL REFERENCES cerner_orders(code) ON DELETE CASCADE,
  "name" varchar(100) NOT NULL,
  "is_primary" boolean NOT NULL DEFAULT 0,
  --                                        12345678901234567890123
  "updated_date" varchar(23) NOT NULL    -- YYYY-MM-DD HH:MM:SS.SSS format
);

