--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2010 University of Washington Medical Center
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Medical Center and is not to
--    be disclosed to any third party without prior express written
--    permission of University of Washington Medical Center University
--    of Washington Medical Center, as the author and owner under 17
--    U.S.C. Sec. 201(b) of this work made for hire, claims copyright
--    in this material as an unpublished work under 17 U.S.C. Sec.s 102
--    and 104(a)
-- 
--  ******************************************************************* 

DROP TABLE IF EXISTS `mastermu_oltg`.`fee_schedules`;
DROP TABLE IF EXISTS `mastermu_oltg`.`users`;
DROP VIEW  IF EXISTS `mastermu_oltg`.`dept_tally_view`;
DROP TABLE IF EXISTS `mastermu_oltg`.`messages`;
DROP TABLE IF EXISTS `mastermu_oltg`.`tally_rankings`;

DROP TABLE IF EXISTS `mastermu_oltg`.`lis_feed`;
DROP TABLE IF EXISTS `mastermu_oltg`.`lis_feed_staging`;
DROP TABLE IF EXISTS `mastermu_oltg`.`cross_references_staging`;
DROP TABLE IF EXISTS `mastermu_oltg`.`cross_references`;
DROP TABLE IF EXISTS `mastermu_oltg`.`billing_and_cpt_codes_staging`;
DROP TABLE IF EXISTS `mastermu_oltg`.`billing_and_cpt_codes`;
DROP TABLE IF EXISTS `mastermu_oltg`.`reference_ranges_staging`;
DROP TABLE IF EXISTS `mastermu_oltg`.`reference_ranges`;
DROP TABLE IF EXISTS `mastermu_oltg`.`caution_urls_staging`;
DROP TABLE IF EXISTS `mastermu_oltg`.`caution_urls`;
DROP TABLE IF EXISTS `mastermu_oltg`.`component_tests_staging`;
DROP TABLE IF EXISTS `mastermu_oltg`.`component_tests`;
DROP TABLE IF EXISTS `mastermu_oltg`.`oltg_staging`;
DROP TABLE IF EXISTS `mastermu_oltg`.`oltg`;
