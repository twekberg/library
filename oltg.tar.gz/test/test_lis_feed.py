#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Read a predefined bcDump file and make sure the data gets entered properly.

All of thest test have mnemonics that end with _TEST.
"""


import os
from os import path
import sys
import unittest
from labmed.util.pluralize import just_pluralize
import subprocess

import getters
import oltg.config as config
import oltg.models
import oltg.subcommands.scan_lis as scan_lis


class LisFeedLoad(unittest.TestCase):
    """
    Test cases for the scan_lis program that reads a feed of LIS test data to
    update the database.

    A preconstructed simple LIS feed file is used to load test details. All of
    these tests have a mnemonic with ' _TEST' as a suffix.
    """
    @classmethod
    def setUpClass(cls):
        configfile = path.join('config', os.environ['HOSTNAME'], 'oltg') + '.cfg'
        d = config.read(configfile)
        (cls.session, engine) = oltg.models.setup_db_session(d)
        oltg.models.setup_db_models(cls.session, engine)

        LisFeedLoad.bcdump_file = 'test/data/bcDump-test.txt'

        arguments = scan_lis.parse_arguments([LisFeedLoad.bcdump_file])
        scan_lis.scan(cls.session, engine, arguments)      # Load the tests


    def test_all_there(self):
        object_type = 'Oltg'
        expected_values = ["ABPATH_TEST",
                           "ACENBG_TEST",
                           "ACHE_TEST",
                           "ACID_TEST",
                           "ACODE_TEST",
                           "ACUTRP_TEST",
                           "ACX_TEST",
                           "ADR_TEST",
                           "AMHB_TEST",
                           "HIPA_TEST",
                           "NA_TEST",
                           "RALKT_TEST"
                           ]
        expected_count = len(expected_values)
        os = getters.get_all_tests(self.session)
        self.assertIsNotNone(os, 'Unable to retrieve %s objects' % (object_type,))
        self.assertEqual(len(list(os)),
                         expected_count,
                         'Unable to retrieve %d %s %s got %d\n%s' % (expected_count,
                                                                     object_type,
                                                                     just_pluralize(expected_count, 'object'),
                                                                     len(list(os)),
                                                                     sorted([x.mnemonic for x in (list(os))])))
        for o in os:
            self.assertIn(o.mnemonic, expected_values)


    def test_one_cpt_code(self):
        object_type = 'BillingAndCptCode'
        mnemonic = 'ACID_TEST'
        expected_values = ['84066']
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        codes = getters.get_billing(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s\n%s' % (expected_count, object_type, just_pluralize(expected_count, 'object'), mnemonic, list(codes)))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].cpt_code, expected_values[i])
        

    def test_several_cpt_code(self):
        object_type = 'BillingAndCptCode'
        mnemonic = 'ACX_TEST'
        expected_values = ['85018', '82810', '83050', '82375', '456']
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        codes = getters.get_billing(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s\n%s' % (expected_count, object_type, just_pluralize(expected_count, 'object'), mnemonic, list(codes)))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].cpt_code, expected_values[i])


    def test_no_cpt_code(self):
        object_type = 'BillingAndCptCode'
        mnemonic = 'ACHE_TEST'
        expected_values = []
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        codes = getters.get_billing(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s' % (expected_count, object_type, just_pluralize(expected_count, 'object'), mnemonic))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].cpt_code, expected_values[i])


    def test_no_components(self):
        object_type = 'ComponentTest'
        mnemonic = 'ACHE_TEST'
        expected_values = []
        expected_count = len(expected_values)
        o = getters.get_oltg(self.session, mnemonic)
        # Must have the base object.
        self.assertIsNotNone(o, 'Unable to retrieve Oltg object for %s' % (mnemonic,))
        codes = getters.get_components(self.session, mnemonic)
        self.assertIsNotNone(codes, 'Unable to retrieve %s object for %s' % (object_type, mnemonic))
        self.assertEqual(len(list(codes)), expected_count, 'Unable to retrieve %d %s %s for %s' % (expected_count, object_type, just_pluralize(expected_count, 'object'), mnemonic))
        for i in xrange(expected_count):
            self.assertEqual(codes[i].cpt_code, expected_values[i])


    @classmethod
    def tearDownClass(self):
        """
        The unittest module runs in its own thread, making it difficult
        to run this cleanup code when the test have finished. Making this
        a test insures that it will be run last.
        """
        p = subprocess.Popen(['scripts/delete-tests', LisFeedLoad.bcdump_file],
                             stdout=subprocess.PIPE)
        exit_status = p.wait()
        # It would be nice to make sure the exit_status is 0, but can't
        # call assertEqual from this class method.

if __name__ == '__main__':
    unittest.main()
