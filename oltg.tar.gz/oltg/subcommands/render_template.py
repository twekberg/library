"""
Render a Cheetah template for a mnemonic.
"""

import argparse
import sys
import pprint
import json
from os import path, environ

from Cheetah.Template import Template

import oltg
import oltg.subcommands

def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('-j','--json', help = 'JSON format file containing data for a mmemonic.',
                        type = argparse.FileType('r'))
    parser.add_argument('-t','--template-file',
                        help='template file to render; by default uses Simple.tmpl if -j is provided, otherwise Welcome.tmpl')
    parser.add_argument('-d','--outdir', default='.',
                        help="Directory in which to store output [default: '%(default)s']")
    parser.add_argument('-v','--verbose', action = 'count', default = 1,
                        help = '-v, be more verbose; -vv, be even more verbose')

    # These are values for the template.
    parser.add_argument('-b','--background-color', default='default',
                        choices=('default', 'yellow', 'green'),
                        help="Background color for the page. [default: '%(default)s']")
    parser.add_argument('-o','--home-page', default='oltg',
                        help="URL for the home page. [default: '%(default)s']")
    parser.add_argument('-m','--page-mode', default='',
                        help="Mode string for the page. For example '- edit' [default: '%(default)s']")
    parser.add_argument('-s','--page-subtitle', default='',
                        help="Subtitle for the page [default: '%(default)s']")
    parser.add_argument('-p','--reference-range-placement', default='top',
                        choices=('top', 'bottom'),
                        help="Where to render the reference range detail. [default: '%(default)s']")
    parser.add_argument('-e','--show-empty', default=False, action = 'store_true',
                        help='show empty fields')
    parser.add_argument('-f','--show-staff-detail', default=False, action = 'store_true',
                        help='show staff detail on the page')
    parser.add_argument('-x','--static-page', default=False, action = 'store_true',
                        help='Show a static web page.')
    parser.add_argument('-c','--static-content-home', default='/mastermu/oltg/',
                        help='base path for directories containing static content (eg, css,js). Use "-c." to use local static content for testing. [default: %(default)s]',
                        metavar = 'PATH')


def action(args):

    data = {}

    if args.json:
        data.update(json.load(args.json))
        htmlfile = path.join(args.outdir, path.splitext(path.basename(args.json.name))[0]+'.html')
        template='oltg/templates/Simple.tmpl'
    else:
        template='oltg/templates/Welcome.tmpl'
        htmlfile = path.join(args.outdir, path.splitext(path.basename(template))[0]+'.html')
        
    if args.template_file:
        template = args.template_file

    print 'writing %s' % htmlfile
        
    environ = dict(
        advanced_actions = False,       # Create test and push to prod.
        background_color = args.background_color,
        hide_subcomponents = True,      # Initially hide subcomponents of a package/panel
        home_page = args.home_page,
        page_mode = args.page_mode,
        page_sub_title = args.page_subtitle,
        reference_range_near_top = True if args.reference_range_placement=='top' else False,
        show_empty = args.show_empty,
        show_staff_detail = args.show_staff_detail,
        static_page = args.static_page,
        static_content_home = args.static_content_home.rstrip('/')+'/',
        version = oltg.__version__,

        search_text = '',               # Default values for search elements
        search_as_component = 'yes',
        search_cross_reference = 'yes',
        )
    
    with open(template) as tfile:
        page = Template(tfile.read(), searchList=[data, environ])

    if args.verbose > 2:
        print page
    elif args.verbose > 1:
        print htmlfile
    with open(htmlfile, 'w') as html:
        html.write(page.respond())


