#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2012 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Defines functions that can be used to set up a database.
"""


from os import path
import shutil

import oltg.config as config
import oltg.models


config_dir = 'test/config/'
data_dir = 'test/data/'
db_dir = 'test/db/'


def init(config_filename, sql_filename=None):
    """
    Creates and initializes the database.

    The config_filename is normally the base name of a configuration
    file. These files are normally stored in the test/config
    directory. If config_filename is an absolute path it specifies
    an alternate location.

    The sql_filename is normally the base name of a file containing
    SQL commands. These files are normally stored in the test/data
    directory. As with config_filename, If sql_filename is an absolute
    path it specifies an alternate location. If sql_filename is None
    (the default) then nothing is done to initialize the database.
    
    Returns the DB session object.
    """
    d = config.read(path.join(config_dir, config_filename))
    copy_db(d['db_file'])
    (session, engine) = oltg.models.setup_db_session(d)
    oltg.models.setup_db_models(session, engine)
    if sql_filename:
        load_db(session, path.join(data_dir, sql_filename))
    return (session, engine)


def copy_db(db_name):
    """
    Create a new database file using empty_db.sqlite as a base.
    """
    shutil.copyfile(path.join(db_dir, 'empty_db.sqlite'), db_name)


def load_db(session, data_filename):
    """
    Execute insert statements. Can span multiple lines.

    Lines starting with '--' are SQL comments and are ignored.
    """
    with open(data_filename) as in_sql:
        sql = ''
        for line in in_sql:
            if line.startswith('--'):
                continue
            sql += ' ' + line.strip()
            if sql.endswith(';'):
                t = session.execute(sql)
                sql = ''
