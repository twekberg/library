#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Controller for the edit page.
"""

## The setdefaultencoding function is only intended to be used by the site
## module implementation and, where needed, by sitecustomize. Once used by the
## site module, it is removed from the sys module's namespace. Reloading sys
## brings that name back. The default encoding is 'ascii' which doesn't
## handle 8 bit encodings like \xB0 (&deg;).
import sys
reload(sys)
sys.setdefaultencoding('utf-8')

from datetime import datetime
import re
import cgi

import oltg
import oltg.models
from oltg.models.create_models import (CrossReferenceStaging as CrossReference,
                                       CautionUrlStaging as CautionUrl,
                                       AuditLog,
                                       CernerPlaceholderMap,
                                       CernerOrder,
                                       CernerSynonym,
                                       CernerNonplaceholderSynonym,
                                       CernerSynonymDisplay)
import oltg.controllers.collectors as collectors
from oltg.controllers import app
from oltg.controllers.db_interface import get_mnemonic_detail
from oltg.controllers.common import common_namespace
from oltg.controllers.common import adjust_new_value
from oltg.templates.EditCreateTest import EditCreateTest


debug = False
debug_messages = []


def edit(environ, start_response, logger):
    """Edit details for a test."""
    session = environ.get('SESSION', None)
    engine = environ.get('ENGINE', None)
    config_dict = environ['CONFIG']
    oltg.models.setup_db_models(session, engine)
    global debug_messages
    parameters = environ[app + '.parameters']
    #raise Exception('dir=%s, parameters=%s' % (dir(parameters), parameters))
    mnemonic = parameters.get('mnemonic', '')
    action = parameters.get('action', '')

    # When edit comes from a different URL, use this to validate it, and look up the user name.
    home_page = environ.get('SCRIPT_NAME', '').rstrip('/') or None

    o = 'Nothing'
    if mnemonic:
        mnemonic = mnemonic.upper()
        o = oltg.models.object_query.get_oltg(mnemonic)
        if o:
            debug_messages = []
            if action == 'edit':
                message = do_edit(session, environ.get('REMOTE_USER', 'Unknown User'), mnemonic, parameters, o)
            else:
                message = ''
            if debug_messages and debug:
                message = '<br>'.join(debug_messages) + '<br>' + message
            namespace = get_mnemonic_detail(mnemonic, from_database=True)
            namespace.update(dict(
                create =              False,
                display_test =        True,
                all_cerner_lab_mnemonics = oltg.models.object_query.get_all_cerner_lab_mnemonics(),
                message =             message,
                ))
            # Process the cerner settings.
            data = oltg.models.object_query.get_cerner_name_details(mnemonic)
            if data:
                namespace['primary'] = data[0]
                namespace['synonyms'] = data[1:]
                namespace['show_cerner_synonyms'] = True
            else:
                namespace['show_cerner_synonyms'] = False
        else:
            namespace['message'] = 'Unable to locate test for mnemonic %s' % (mnemonic,)
    else:
        namespace = {'mnemonic': mnemonic,
                     'display_test': False,
                     'message': '',
                     }
        if 'mnemonic' in parameters:
            namespace['message'] = 'Please enter the mnemonic for the test you want to edit.'
    namespace.update(common_namespace(environ, config_dict))
    start_response('200 OK', [('Content-Type', 'text/html')])
    with open('/tmp/editout.txt', 'w') as o:
        o.write('namespace=%s' % (namespace,))
    t = EditCreateTest(searchList = [namespace], filter='Filter')
    return [str(t.respond())]


class DoEdit(object):
    """
    Helper class to handle editing of the various columns.
    """
    def __init__(self, session, user, mnemonic, parameters, o):
        self.session = session
        self.user = user
        self.mnemonic = mnemonic
        self.parameters = parameters
        self.o = o
        self.n_changes = 0

    def process(self, name, db_name=None):
        """
        Normal code to process a setting.
        name is the name used in the <form>.
        db_name is the optional name for the database column.
        """
        if db_name is None:
            db_name = name
        old_value = self.o.get(db_name)
        if not is_same(name, old_value, self.parameters):
            new_value = adjust_new_value(self.parameters.getall(name))[0]
            self.log_change(db_name, old_value, new_value)
            self.o.set(db_name, new_value)

    def log_change(self, column_name, old_value, new_value):
        al = AuditLog()
        al.mnemonic = self.mnemonic
        al.user = self.user
        al.updated_date = datetime.now()
        al.column_name = column_name
        if old_value is None:
            old_value = ''
        if len(old_value) > al.get_db_type_length('old_value'):
            al.old_value_big = old_value
        else:
            al.old_value = old_value
        if new_value is None:
            new_value = ''
        if len(new_value) > al.get_db_type_length('new_value'):
            al.new_value_big = new_value
        else:
            al.new_value = new_value
        self.session.add(al)
        self.n_changes += 1

    def process_orca_name(self):
        data = oltg.models.object_query.get_cerner_name_details(self.mnemonic)
        if data:
            # See if any of the 'show' values changed.
            for synonym in data:
                if bool(self.parameters.get('synonym_id_%s' % (synonym['cerner_synonym_id'],), '')) != synonym['show']:
                    self.log_change("orca_name.show_%s" % (synonym['name'],), str(synonym['show']), str(not synonym['show']))
                    synonym['show'] = not synonym['show']
                    sd = oltg.models.object_query.get_cerner_synonym_display(synonym['cerner_synonym_id'])
                    sd.show = synonym['show']
                    self.n_changes += 1
        else:
            cerner_code_type = self.parameters.get('cerner_code_type', '')
            if cerner_code_type == '':
                # Do nothing
                return
            elif cerner_code_type == 'labund':
                cerner_order_code = 285805416
            elif cerner_code_type == 'labonly':
                cerner_order_code = 0
            else:
                # User specified an order code in a menu.
                cerner_order_code = int(self.parameters.get('cerner_order_code'))
            # The general strategy here is to create a copy of the CernerOrder
            # object, CernerSynonym objects and CernerSynonymDisplay objects so
            # that the 'show' settings for this mnemonic are independent from
            # those same objects the user selected.
            next_code = oltg.models.object_query.get_max_cerner_order_code() + 1
            # Choose a range of codes beyond the cerner codes.
            if next_code < 2**32:
                next_code = 2**32
            # Get the defail for the Cerner order selected by the user.
            cerner_order = oltg.models.object_query.get_cerner_order(cerner_order_code)
            cerner_synonyms = oltg.models.object_query.get_cerner_synonyms(cerner_order_code)
            cerner_synonym_displays = oltg.models.object_query.get_cerner_synonym_displays(cerner_order_code)
            cm = CernerOrderMap()
            cm.code = next_code
            cm.lab_mnemonic = self.mnemonic
            self.session.add(cm)
            # The copying starts here.
            o = CernerOrder()
            o.code = next_code
            o.lab_mnemonic = self.mnemonic
            o.primary_name = cerner_order.primary_name
            o.primary_name_hidden = cerner_order.primary_name_hidden
            o.active = cerner_order.active
            o.updated_date = cerner_order.updated_date
            self.session.add(o)
            # Commit now so the synonyms can see it.
            self.session.commit()
            for i in range(len(cerner_synonyms)):
                cerner_synonym = cerner_synonyms[i]
                cerner_synonym_display = cerner_synonym_displays[i]
                s = CernerSynonym()
                s.cerner_order_code = next_code
                s.name = cerner_synonym.name
                s.is_primary = cerner_synonym.is_primary
                s.updated_date = cerner_synonym.updated_date
                self.session.add(s)
                self.session.commit()
                # Create a CernerSynonymDisplay copy that is linked to the
                # CernerSynonym we just created.
                sd = CernerSynonymDisplay()
                sd.cerner_synonym_id = s.id
                sd.show = cerner_synonym_display.show
                self.session.add(sd)
            self.session.commit()
            self.n_changes += 1


def do_edit(session, user, mnemonic, parameters, o):
    """
    Changes the value in the oltg object to reflect the changes requested by the user.
    parameters - values from the form.
    o - the oltg staging object before the change.

    Returns a message to display to the user.
    """
        
    de = DoEdit(session, user, mnemonic, parameters, o)
    global debug, debug_message

    de.process('test_name', 'name')
    de.process_orca_name()
    de.process('epic_name')
    
    old_values = collectors.cross_references(mnemonic)
    if not is_same('cross_references', old_values, parameters, True):
        # Delete the old cross references.
        session.query(CrossReference).filter(CrossReference.mnemonic == mnemonic).delete()
        new_values = sorted(adjust_new_value(parameters.getall('cross_references')))
        # Add the new ones.
        for cross_reference in new_values:
            cr = CrossReference()
            cr.mnemonic = mnemonic
            cr.cross_reference = cross_reference
            session.add(cr)
        de.log_change('cross_references', str(old_values), str(new_values))

    de.process('specimen_type')
    de.process('test_info')

    old_values = collectors.cautions(mnemonic)
    new_values = zip(parameters.getall('cautions_address'), parameters.getall('cautions_label'))
    if debug:
        if old_values != new_values:
            debug_messages.append('TWE compare: for cautions_urls old_values=%s, new_values=%s comparing %s' %
                                  (old_values, new_values, old_values == new_values))
    if old_values != new_values:
        # Delete the old caution_urls
        session.query(CautionUrl).filter(CautionUrl.mnemonic == mnemonic).delete()
        # Add the new ones.
        for (address, label) in new_values:
            cu = CautionUrl()
            cu.mnemonic = mnemonic
            cu.address = address
            cu.label = label
            session.add(cu)
        de.log_change('caution_urls', str(old_values), str(new_values))

    de.process('security_flag')
    de.process('collection')
    de.process('amount')
    de.process('minimum_amount')
    de.process('specimen_handling')
    de.process('processing_instructions')
    de.process('done_uwmc')
    de.process('done_hmc')
    de.process('done_other')
    de.process('frequency')
    de.process('available_stat')
    de.process('method')
    de.process('additional_billing')

    new_updated_date = parameters.get('updated_date')
    if new_updated_date:
        try:
            # Convert to a datetime object.
            new_updated_date = datetime.strptime(new_updated_date, '%m/%d/%Y')
        except ValueError as e:
            pass
    else:
        # Nothing was specified. Assume now with just the date elements.
        now = datetime.now()
        new_updated_date = datetime(now.year, now.month, now.day)
    if debug:
        if new_updated_date != o.updated_date:
            debug_messages.append('TWE updated_date, old_value=%s, new_value=%s, same=%s' %
                                  (new_updated_date, o.updated_date, new_updated_date == o.updated_date))
    if new_updated_date != o.updated_date:
        de.log_change('updated_date', str(o.updated_date), str(new_updated_date))
        o.updated_date = new_updated_date

    de.process('reference_range_addendum')

    if de.n_changes > 0:
        o.was_changed = True
        session.commit()
    return 'Number of changes made: %d.' % (de.n_changes,) if de.n_changes > 0 else 'No changes made.'


def is_same(what, old_value, parameters, sort=False):
    """
    Determine if the old value is the same as the new value.
    """
    global debug, debug_message
    old_value = adjust_old_value(old_value)
    new_value = adjust_new_value(parameters.getall(what))
    if debug:
        debug_message= 'TWE is_same: for %s, old_value=%s, new_value=%s' % (what, old_value, sorted(new_value) if sort else new_value)
    if (sort and sorted(old_value) == sorted(new_value)) or (not sort and old_value == new_value):
        return True
    if debug:
        debug_messages.append(debug_message + ', returning False')
    return False


def adjust_old_value(old_value):
    old_value = '' if old_value is None else old_value
    if type(old_value) is not type([]):
        old_value = [old_value]         # Needed for getall
    return old_value


def maybe_changed(what, old_value, parameters, sort=False):
    """
    Debug code to output a message when something is changed from its original value.
    """
    if is_same(what, old_value, parameters, sort):
        return ''
    return ('<br>%s changed from "%s" to "%s",<br>old:<br>%s<br>new:<br>%s' %
            (what,
             '' if old_value is None else old_value,
             parameters.getall(what),
             hex_dump('\n'.join(adjust_old_value(old_value))),
             hex_dump('\n'.join(adjust_new_value(parameters.getall(what)))),
             ))


FILTER=''.join([(len(repr(chr(x)))==3) and chr(x) or '.' for x in range(256)])
def hex_dump(src, length=8, line_sep=''):
    """
    Generate a hex dump with length values on a line, suitable to
    outputting to an HTML page.
    """
    result=[]
    for i in xrange(0, len(src), length):
       s = src[i:i+length]
       hexa = ' '.join(["%02X"%ord(x) for x in s])
       printable = cgi.escape(s.translate(FILTER))
       result.append("%04X   %-*s   %s\n" % (i, length*3, hexa, printable))
    return '<pre>' + line_sep.join(result) + '</pre>'
