#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
The Medicare fee schedules are updated periodically and need to be loaded into the fee_schedules table.
This program scans the spreadsheet and inserts the data into the fee_schedules
table.

No need to truncate the fee_schedules table prior to running this program.
It is done automatically, if needed.

The source of the Medicare fee schedules is this web site:
  http://www.cms.gov/ClinicalLabFeeSched/02_clinlab.asp
"""

# Example:
#   python python/scan_fee_schedule.py ~/SANDBOX/CLAB2011_Fee.xls

import argparse
import os
import os.path
import re
import sys
import warnings
import xlrd

import sqlalchemy.exc

import oltg.subcommands
import oltg.models
from oltg.models.create_models import FeeSchedule
from oltg.models.messages import Messages


# The following are row indexes in the spreadsheet where certain data can be found.
# Row index for the state abbreviations.
state_row = 4
# Column index for the Modifier column.
modifier_col = 1
# Column index for the CPT code.
cpt_col = 0
# Row index where the data starts.
start_data_row = 7
# Column index for the WA column (Washington).
wa_col = None


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('fee_file', action="store",
                        help='This is the file that contains the Medicare fee schedules.')


def action(args):
    """
    Scan the fee schedule using filename specified in the args.
    The file is assumed to be an excel file.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    messages = Messages(session, 'Load Fee Schedule')
    try:
        filename = args.fee_file
        ok = False
        messages.store('started')
        try:
            count = 0
            init(filename)
            row_index = 0
            if is_fee_schedule():
                already_retried = False
                retry = True
                while retry:
                    retry = False
                    for row_index in xrange(start_data_row,sheet.nrows):
                        modifier = sheet.cell_value(row_index, modifier_col)
                        if modifier != 'QW':
                            cpt_code = sheet.cell_value(row_index, cpt_col)
                            # This number comes as a 32 bit float value, which has trash below the cents.
                            # Generate a 64 bit float value with more precision.
                            dollar = float(sheet.cell_value(row_index, wa_col))
                            f = FeeSchedule()
                            f.cpt_code = cpt_code
                            f.reimbursement = dollar
                            count += 1
                            session.add(f)
                    try:
                        session.commit()
                        ok = True
                    except sqlalchemy.exc.IntegrityError as e:
                        # MySQL and PostgreSQL have different exception
                        # messages. Fortunately they have the same exception
                        # type (IntegrityError).
                        if (re.search('Duplicate entry .* for key ', e.message)
                            or re.search('duplicate key value violates unique constraint', e.message)):
                            if already_retried:
                                # Still getting a duplicate error.
                                messages.store('Caught exception', False, e)
                            else:
                                # Truncate the table and try again.
                                print "Doing truncate on mastermu_oltg.%s" % (FeeSchedule.table_name,)
                                session.rollback()
                                session.execute("truncate mastermu_oltg.%s" % (FeeSchedule.table_name,))
                                session.commit()
                                already_retried = True
                                retry = True
                                count = 0
                                messages.store('retrying')
                        else:
                            # Some other error.
                            messages.store('Caught exception', False, e)
            else:
                messages.store("File %s is not a fee schedule spreadsheet." % (filename,), False)
        except Exception as e:
            # Unexpected exception.
            messages.store('Caught exception', False, e)
        messages.store('completed. count=%d' % (count,), ok)
    finally:
        oltg.models.release_session(session, engine)
    return 0 if ok else 1               # exit status


def is_fee_schedule():
    """
    The fee schedule should have cell A2 containing the string 'Fee Schedule'.
    Also, row #5 (index 4) should have a 'WA' somewhere.
    # Sets wa_col to the column index of the 'WA' column.
    """
    global sheet, wa_col
    val = sheet.cell_value(1,0)
    wa_col = None
    for i in range(sheet.ncols):
        if sheet.cell_value(state_row, i) == 'WA':
            wa_col = i
            break
    return val == 'Fee Schedule' and wa_col is not None


def init(input_filename):
    global sheet

    book = xlrd.open_workbook(input_filename)
    sheet = book.sheet_by_index(0)
    # Get truncation warnings of the form:
    #   /usr/local/lib/python2.6/site-packages/SQLAlchemy-0.6.6-py2.6.egg/sqlalchemy/engine/default.py:299:
    #   Warning: Data truncated for column 'reimbursement' at row 1
    #   cursor.execute(statement, parameters)
    # This happens because the reimbursement values are stored as single precision floats, but are
    # read as double precision floats. Those reimbursement values that can not
    # be represented as a float, get truncation errors.
    # The following code will cause this warning to ignored, instead of printing to stderr.
    warnings.filterwarnings(action="ignore", message="Data truncated for column 'reimbursement'")
    warnings.filterwarnings(action="ignore", message="BaseException.message has been deprecated")
