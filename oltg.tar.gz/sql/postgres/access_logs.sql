--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2011 University of Washington Medical Center
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Medical Center and is not to
--    be disclosed to any third party without prior express written
--    permission of University of Washington Medical Center University
--    of Washington Medical Center, as the author and owner under 17
--    U.S.C. Sec. 201(b) of this work made for hire, claims copyright
--    in this material as an unpublished work under 17 U.S.C. Sec.s 102
--    and 104(a)
-- 
--  ******************************************************************* 


CREATE TABLE mastermu_oltg.access_logs (
  id BIGSERIAL NOT NULL PRIMARY KEY,
  staff_only boolean NOT NULL,
  edit_mode boolean NOT NULL,
  "user" varchar(100) NOT NULL,
  updated_date timestamp NOT NULL,
  -- Uses environ['REMOTE_ADDR']
  ip_address varchar(50) NOT NULL,
  -- Either 'search' or 'display'
  action varchar(50) NOT NULL,
  -- search parameters or mnemonic that was displayed.
  details varchar(200) NOT NULL
);

COMMENT ON TABLE mastermu_oltg.access_logs IS 'Who did what when from where.';
