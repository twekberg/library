#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Scan the LIS OLTG data feed and put data into the staging tables.

The argument specifies the filename so one can be passed for testing purposes.
"""

# Example:
#    python python/scan_lis.py bcDump-LAB0-2011-06-22.txt


import oltg.subcommands
import oltg.models
import oltg.models.object_queries as object_queries
from oltg.models.messages import Messages
from oltg.subcommands.tojson import action as tojson_action
from oltg.controllers import app

from datetime import datetime
import hashlib
import re
import sys
import argparse


debug = False

DESCRIPTION = __doc__.strip()
SEP = '\t'
FS = '\034'


"""
Use this query to display those updated dates that do not parse properly.

SELECT distinct(o.updated)
FROM oltg n
JOIN mastermu.oltg o
ON n.mnemonic = o.mnemonic
WHERE n.updated_date IS NULL
AND o.updated IS NOT NULL
ORDER BY 1;
"""

DATE_PATTERNS = [
    # This is the date format that the LIS feed uses.
    # Doesn't take leap year into account, but that is OK since we are only trying
    # to distinguish dates from reference range notes. Note that the leading 0 for
    # the MM and DD is optional.
    #               MM             / DD                      /YYYY
    (re.compile(r'^(0?[1-9]|1[012])/(0?[1-9]|[12][0-9]|3[01])/\d\d\d\d'), '%m/%d/%Y'),
    # This is the date format the database uses. Used by updated_date.
    #              YYYY    - MM             - DD
    (re.compile(r'^\d\d\d\d-(0?[1-9]|1[012])-(0?[1-9]|[12][0-9]|3[01])'), '%Y-%m-%d'),
    #               MM             / DD                      /YY
    (re.compile(r'^(0?[1-9]|1[012])/(0?[1-9]|[12][0-9]|3[01])/\d\d'), '%m/%d/%y'),
    ]


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('feed_file', action="store",
                        help='This is the file that contains the LIS feed data.')


def action(args):
    try:
        (config_dict, session, engine) = oltg.subcommands.init_args(args)

        # Need to scan the file twice, one to update the production tables, again for the staging tables.
        oltg.models.object_query = object_queries.ProdObjectQueries(session, config_dict['db_type'])
        ok = scan(session, args, 'prod')
        oltg.models.object_query = object_queries.StagingObjectQueries(session, config_dict['db_type'])
        ok += scan(session, args, 'staging')
    finally:
        oltg.models.release_session(session, engine)
    return ok


def scan(session, args, table_type):
    """
    Call this from other python code.
    The caller needs to release the DB session.

    table_type is only used for the status message.
    """
    handler = Handler(session)
    handler.messages.store('started for ' + table_type)
    ok = True
    filename = args.feed_file
    try:
        with open(filename) as inp:
            line = readline(inp)
            if line:
                headers = line.split(SEP)
                while(True):
                    line = readline(inp)
                    if line is None:
                        break
                    if line == '':
                        # Skip empty lines.
                        continue
                    if line.startswith('Finished'):
                        break
                    d = dict(zip(headers, line.split(SEP)))
                    if d['hosp'] == 'U':
                        if debug:
                            print 'TWE line=%s' % (line,)
                        handler.handle(d, line)
            else:
                ok = False
                handler.messages.store('No records found in file %s' % (filename,), Ok)
        handler.close()
        if handler.changed_and_new_mnemonics:
            # Update the json files for these mnemonics.
            
            class Args(object):
                def __init__(self):
                    self.config = '/home/mastermu/%s/config/%s.cfg' % (app, app)
                    self.hostname = None
                    self.app = app
                    self.mnemonics = handler.changed_and_new_mnemonics
                    self.outdir = None
                    self.verbose = 1
            status_j = tojson_action(Args())
            handler.messages.store('Generated %d json files' % (len(handler.changed_and_new_mnemonics),))
    except Exception as e:
        ok = False
        handler.messages.store('Caught exception', ok, e)
    handler.messages.store('completed. count=%d' % (handler.count,), ok)
    return 0 if ok else 1


def readline(f):
    """
    Reads a line of data. Returns None when the end of file is reached.
    """
    line = f.readline()
    if len(line) > 0:
        if line[-1] == '\n':
            line = line[:-1]
        if len(line) > 0 and line[-1] == '\r':
            line = line[:-1]
        return line
    return None


class Handler(object):
    commit_limit = 50                   # Batch commits using this.
    def __init__(self, session):
        self.session = session
        self.count = 0
        self.commit_count = 0
        self.messages = Messages(session, 'LIS Feed')
        self.changed_and_new_mnemonics = []


    def compute_hash(self, s):
        return hashlib.sha512(s).hexdigest()


    def commit(self):
        self.commit_count += 1
        if self.commit_count >= Handler.commit_limit:
            self.session.commit()
            self.commit_count = 0


    def close(self):
        if self.commit_count:
            self.session.commit()


    def handle(self, d, line, do_commit=True):
        self.count += 1
        mnemonic = d['mnemonic']
        o = oltg.models.object_query.get_oltg(mnemonic)
        something_changed = False
        lis_feed = None
        if o is None:
            if debug:
                print 'TWE New test %s' % (mnemonic,)
            o = self.store_new_oltg_data(d)
            something_changed = True
        else:
            # Existing test. Did it change?
            f = oltg.models.object_query.get_lis_feed(mnemonic)
            if len(list(f)) == 0 or f[0].whole_line_hash != self.compute_hash(line):
                if debug:
                    print 'TWE Existing test changed %s' % (mnemonic,)
                lis_feed = f[0] if len(list(f))>0 else None
                self.store_existing_oltg_data(d, o, lis_feed)
                something_changed = True
        if something_changed:
            self.changed_and_new_mnemonics.append(mnemonic)
            self.update_lis_feed(d, line, lis_feed)
            if do_commit:
                self.commit()
                if debug:
                    print 'TWE store_existing_oltg_data did a commit. Check for first line from feed'
        return (something_changed, o)


    def update_lis_feed(self, d, line, f=None):
        """
        The LIS feed identified a test that is either new or has changed. Record
        the defails for this test here.

        d - dictionary of a test parsed from line.
        line - is the line from the feed.
        """
        new_lis_feed = False
        if f is None:
            new_lis_feed = True
            f = oltg.models.object_query.create_lis_feed_object()
        f.mnemonic = d['mnemonic']
        f.whole_line_hash       = self.compute_hash(line)
        f.oltg_hash             = self.compute_hash(self.combine_oltg(d))
        f.billing_codes_hash    = self.compute_hash(d['bCode#cpt'])
        f.component_tests_hash  = self.compute_hash(d['components'])
        f.reference_ranges_hash = self.compute_hash(self.combine_reference_ranges(d))
        f.updated_date = datetime.now()
        if new_lis_feed:
            self.session.add(f)


    def combine_oltg(self, d):
        """
        Used to determine if data from the LIS feed differs from what is in the DB.
        """
        return ','.join([d['hosp'],
                         d['type'],
                         self.rstrip_7bit(d['lab-name']),
                         d['dept'],
                         d['dept-name'],
                         d['unit'],
                         d['oFlg'],
                         d['spFlg'],
                         d['rrEffDate'],
                         d['rrUnits']])


    def combine_reference_ranges(self, d):
        val = ''
        try:
            i = 1
            # Iterate through the reference ranges, exiting when you get a KeyError
            # This allows the number of reference range values to increase
            # without any code changes.
            while True:
                f_age = d['F-AgeRng%02d' % i]
                f_ref = d['F-RefRng%02d' % i]
                m_age = d['M-AgeRng%02d' % i]
                m_ref = d['M-RefRng%02d' % i]
                if i > 1:
                    val += ','
                val += 'f_age %s|f_ref %s|m_age %s|m_ref %s' % (f_age, f_ref, m_age, m_ref)
                i += 1
        except KeyError:
            pass
        return val


    def store_new_oltg_data(self, d):
        """
        Store OLTG data into the database.

        d - dictionary object for the data.
        """
        o = oltg.models.object_query.create_oltg_object()
        o.mnemonic = d['mnemonic']
        o.name = d['name1']                       # empty on feed
        o.hospital = d['hosp']
        o.specimen_type = d['spType']             # empty on feed
        o.specimen_handling = d['spHand-1']       # empty on feed
        o.collection = d['collect-1']             # empty on feed
        o.amount = d['amount']                    # empty on feed
        o.minimum_amount = d['minimum']           # empty on feed
        o.done_uwmc = d['done-UWMC']              # empty on feed
        o.done_hmc = d['done-HMC']                # empty on feed
        o.done_other = d['done-Oth-1']            # empty on feed
        o.frequency = d['freq-1']                 # empty on feed
        o.available_stat = d['avlStat']           # empty on feed
        o.updated_date = self.parse_date(d['updated']) # empty on feed
        o.security_flag = d['SecFlg']             # empty on feed
        o.reference_range_addendum = d['bcRR-1']  # empty on feed
        self.session.add(o)
        self.store_existing_oltg_data(d, o)
        return o


    def store_existing_oltg_data(self, d, o, f=None):
        """
        Store OLTG data into the database.

        d - dictionary object for the data.

        o - an Oltg object.

        f - an optional LisFeed object.
        """
        if debug:
            print 'TWE o=%s' % (o,)
        if f is None or f.oltg_hash != self.compute_hash(self.combine_oltg(d)):
            o.lab_name            = self.rstrip_7bit(d['lab-name'])
            o.tbp_type            = d['type']
            o.dept_code           = d['dept']
            o.dept_full_name      = d['dept-name']
            o.unit                = d['unit']
            o.order_flag          = d['oFlg']
            o.suppress_print_flag = d['spFlg']
            rr_eff_date_string    = d['rrEffDate']
            rr_eff_date           = self.parse_date(rr_eff_date_string)
            if rr_eff_date is None:
                # Didn't parse, or empty string. May have a note.
                o.reference_range_effective_date = None
                o.reference_range_notes = rr_eff_date_string
            else:
                # Parse was OK. No notes.
                o.reference_range_effective_date = rr_eff_date
                o.reference_range_notes = ''
            o.reference_range_units = d['rrUnits']

        if f is None or f.reference_ranges_hash != self.compute_hash(self.combine_reference_ranges(d)):
            self.update_reference_ranges(d)
        if f is None or f.billing_codes_hash != self.compute_hash(d['bCode#cpt']):
            self.update_billing_codes_and_cpt_codes(d)
        if f is None or f.component_tests_hash != self.compute_hash(d['components']):
            self.update_component_tests(d)


    def parse_date(self, s):
        """
        Parse a string using the date patterns that are allowed.
        """
        if s is None or s == '':
            return None
        for (date_pattern,parse_string) in DATE_PATTERNS:
            re_match = re.search(date_pattern, s)
            if re_match:
                return datetime.strptime(re_match.group(0), parse_string)
        # No date pattern matched.
        return None


    def update_reference_ranges(self, d):
        """
        Check for reference ranges and d delete them.
        Then add the new ones.
        """
        mnemonic = d['mnemonic']
        oltg.models.object_query.delete_reference_ranges(mnemonic)
        try:
            i = 0
            ordering = 0
            # Iterate through the reference ranges, exiting when you get a KeyError
            # This allows the number of reference range values to increase
            # or decrease without any code changes.
            while True:
                i += 1
                f_age = d['F-AgeRng%02d' % i]
                if f_age != '':
                    f_ref = d['F-RefRng%02d' % i]
                    if debug:
                        print 'TWE f_age=%s, f_ref=%s' % (f_age, f_ref)
                    r = oltg.models.object_query.create_reference_range_object()
                    r.mnemonic = mnemonic
                    r.sex='F'
                    r.age_range = f_age
                    r.ordering = i
                    self.generate_ref(f_ref, r)
                    self.session.add(r)

                m_age = d['M-AgeRng%02d' % i]
                if m_age != '':
                    m_ref = d['M-RefRng%02d' % i]
                    r = oltg.models.object_query.create_reference_range_object()
                    r.mnemonic = mnemonic
                    r.sex='M'
                    r.age_range = m_age
                    r.ordering = i
                    self.generate_ref(m_ref, r)
                    self.session.add(r)
        except KeyError:
            pass


    def generate_ref(self, ref_text, r):
        refs = ref_text.split(FS)
        if refs[0] != '' and refs[1] == '' and refs[2] == '' and refs[3] == '':
            # example: ZNPT  numeric reference range
            r.reference_text = refs[0]
            r.reference_text_code = ''
            r.verify_text = ''
            r.verify_text_code = ''
        elif refs[0] != '' and refs[1] == '' and refs[2] != '' and refs[3] == '':
            # example: ZPPHT  numeric reference range and numeric verify range
            r.reference_text = refs[0]
            r.reference_text_code = ''
            r.verify_text = refs[2]
            r.verify_text_code = ''
        elif refs[0] != '' and refs[1] != '' and refs[2] == '' and refs[3] == '':
            # example: ACETN  non-numeric code and text
            r.reference_text = refs[1]
            r.reference_text_code = refs[0]
            r.verify_text = ''
            r.verify_text_code = ''
        elif refs[0] != '' and refs[1] != '' and refs[2] != '' and refs[3] == '':
            # example: ACETN  non-numeric code and text and numeric verify range
            r.reference_text = refs[1]
            r.reference_text_code = refs[0]
            r.verify_text = refs[2]
            r.verify_text_code = ''
        else:
            # Unknown combination.
            self.messages.store('Warning', True, 'Unknown reference range combination: %s, refs=%s' % (repr(ref_text),repr(refs)))


    def update_billing_codes_and_cpt_codes(self, d):
        """
        Generate database entries for the billing and CPT codes. The string from
        the LIS feed is of the form:
          billing code '#' CPT code [ '\' billing code '#' CPT code ] ... '\'
        """
        mnemonic = d['mnemonic']
        oltg.models.object_query.delete_billing_and_cpt_codes(mnemonic)
        codes = d['bCode#cpt']
        if len(codes) > 0:
            if codes[-1] == '\\':
                # Strip off the trailing \ so split works better.
                codes = codes[:-1]
            try:
                for code in codes.split('\\'):
                    (billing_code, cpt_code) = code.split('#')
                    bc = oltg.models.object_query.create_billing_and_cpt_code_object()
                    bc.mnemonic = mnemonic
                    bc.cpt_code = cpt_code
                    bc.billing_code = billing_code
                    self.session.add(bc)
            except ValueError as e:
                self.messages.store('Warning', True, 'Malformed billing and CPT code was found in test %s: "%s". Additional billing and CPT codes may be found in the LIS feed file.' % (mnemonic, code))


    def update_component_tests(self, d):
        mnemonic = d['mnemonic']
        oltg.models.object_query.delete_component_tests(mnemonic)
        components = d['components']
        if len(components) > 0:
            if components[-1] == '#':
                # Strip off the trailing # so split works better.
                components = components[:-1]
            try:
                for component in components.split('#'):
                    (component_mnemonic, suppressed) = component.split('!')
                    c = oltg.models.object_query.create_component_test_object()
                    c.mnemonic = mnemonic
                    c.component_mnemonic = component_mnemonic
                    c.suppressed = suppressed
                    self.session.add(c)
            except ValueError as e:
                self.messages.store('Warning', True, 'Malformed component was found in test %s: "%s". Additional components may be found in the LIS feed file.' % (mnemonic, component))


    def rstrip_7bit(self, s):
        """
        Strip off any characters that are not 7 bit ascii.
        """
        # This caused a problem with SBLDC3's lab_name which had a trailing NBSP.

        if s:                           # Not None and len(s)>0
            while ord(s[-1]) > 127:
                s = s[:-1]
        return s


def parse_arguments(argv):
    """
    Parse the arguments and return the arguments for the action method.

    It is assumed that the argv[0] is the first argument.
    """
    parser = argparse.ArgumentParser(description=DESCRIPTION,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    build_parser(parser)
    return parser.parse_args(argv)
