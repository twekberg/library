"""
This provides an iterator to import all of the OLTG subcommand modules.
If a new subcommand is added, just put it in the commands list.
"""

import glob
from os.path import splitext, split, join
from os import path
import argparse
import socket
import sys

import oltg.config as config
import oltg.models


def itermodules(subcommands_path, root=__name__):
    """
    Go through all subcommands in this package and import them.
    Called as an iterator, returning each subcommand and its module.
    """
    commands = [x for x in [splitext(split(p)[1])[0] for p in sorted(glob.glob(join(subcommands_path, '*.py')))] if not x.startswith('_')]

    for command in commands:
        try:
            yield command, __import__('%s.%s' % (root, command), fromlist=[command])
        except Exception, msg:
            # Indicate an error.
            # TODO: remove external dependencies causing import errors
            # sys.stderr.write('not %s.%s\n' % (root, command))
            print msg
            #pass


def default_parser(parser):
    """
    Pretty much all subcommands have these arguments.
    """
    parser.add_argument('--app', help = 'name of the application (corresponds to $APP in Makefile) (default: oltg)',
                        default='oltg')
    parser.add_argument('--hostname', help='hostname used to identify the config file [default: $HOSTNAME]')
    parser.add_argument('--config', help = 'path to config file (can be provided in place of APP)')


def init_args(args, init_db=True):
    """
    Process the initial arguments, and optionally intializine the database.

    Returns a tuple of the dictionary from the config file and the DB session
    object. If the DB was not initialized then the second return value will be
    None.
    """
    if args.config:
        configfile = args.config
    else:
        # Using os.environ('HOSTNAME') doesn't always work.
        # In cron jobs and HTTP it isn't set.
        # This always returns a fully qualified host name.
        host = args.hostname or (socket.gethostname() if '.' in socket.gethostname() else socket.gethostbyaddr(socket.gethostname()))
        configfile = path.join('config', host, args.app) + '.cfg'

    # Generate a warning if configfile isn't there.
    d = config.read(configfile)
        
    if init_db:
        (session, engine) = oltg.models.setup_db_session(d)
        oltg.models.setup_db_models(session, engine)
    else:
        session = None
        engine = None
    return (d, session, engine)
