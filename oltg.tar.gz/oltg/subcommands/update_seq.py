#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2012 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
For postgres it is useful to have a single command to update all of the sequences to make sure they are up-to-date.
Normally this isn't needed, but during development is can be useful.
"""


import oltg.subcommands
import oltg.models
from oltg.models.db_specific import update_sequences


def build_parser(parser):
    oltg.subcommands.default_parser(parser)


def action(args):
    # Don't bother logging to the messages table. If there is an error we will
    # see it.
    (d, session, engine) = oltg.subcommands.init_args(args)
    print 'Number of sequences updated: %d' % (update_sequences(d['db_type'], session),)
    return 0                            # exit status
