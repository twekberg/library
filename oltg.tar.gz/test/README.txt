This directory contains test cases for elements of the online test guide. Each
test is a python file whose module name starts with 'test'. The support module
getters is used by some tests to retrieve values from the database. The support
module db_setup defines functions to create and initialize a new database.

The database being used is specified by the configuration file(s) in the
config/ directory. This will be sqlite for those cases where we don't want to
modify or depend on values remaining constant.

The database(s) are in the db/ directory. The sqlite database empty_db.sqlite
has all of the OLTG meta data, but no contents. That is, all of the tables are
defined but they are all empty. The general practice is to copy this DB to
another file and then do INSERTs on that file.

Data to be placed into a database is in the data/ directory. Some of these
contain SQL INSERT statements to initialize the database for a particular
test.

If you want to create another test that uses sqlite, look at test_basic.py to
see how this is done.
