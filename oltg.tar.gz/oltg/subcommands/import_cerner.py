#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
This is a replacement for import_cpoe. It loads data into the cerner_orders table.

The format is not expected to change in the future.

This should take about 31 seconds to execute.
"""

# Example:
#   ./runoltg import_cerner filename

from datetime import datetime
import os
import os.path
import random
import re
import sys

from labmed.util.unicode import to_unicode
from labmed.util.date_time_parser import parse_date, STD_DATE_FORMAT
from labmed.util.pluralize import just_pluralize
import labmed.spreadsheet_reader

import oltg.subcommands
import oltg.models
import oltg.models.object_queries as object_queries
from oltg.models.create_models import (Oltg,
                                       CernerOrder,
                                       CernerSynonym,
                                       CernerSynonymDisplay,
                                       CernerNonplaceholderSynonym)
from oltg.models.messages import Messages


# Rather than put this in a file, or as command line parameters, this data is
# hardcoded here.
# This is the list of activity types (column E) that are to be ignore. This list is much
# smaller than the number of activity types to include.
ocs_activity_type_disp_ignores = ['Cytology',
                                  'Cytogenetics',
                                  'Anatomic Pathology',
                                  ]


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('updated_date', action="store",
                        help='This is the date to record for this update. Use just about any date format.')
    labmed.spreadsheet_reader.spreadsheet_parser(parser, what_file='cerner order')


def action(args):
    """
    Scan Chuck's CERNER file. The format of this will most likely change in the future.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    messages = Messages(session, 'Load CERNER unload')
    try:
        ok = False
        updated_date = datetime.strptime(parse_date(args.updated_date), STD_DATE_FORMAT)
        messages.store('started')
        # Mark the existing orders' ready_for_delete=1. The ones that remain
        # when we are done are deleted.
        # Code 0 is a special one for 'orderable by lab only'.
        session.execute("UPDATE mastermu_oltg.cerner_orders SET ready_for_delete=TRUE WHERE code!=0")
        session.execute("UPDATE mastermu_oltg.cerner_synonyms SET ready_for_delete=TRUE WHERE cerner_order_code!=0")
        # Work on synonyms later.
        try:
            act = labmed.spreadsheet_reader.Action(args.input_filename,
                                                   RowHandler,
                                                   row_handler_args = {'session': session,
                                                                       'only_print': False,
                                                                       'updated_date': updated_date},
                                                   csv_sep=args.csv_sep)
            act.loop()
            # Post processing: need to initialize the show flag based on
            # whether or not there is a primary name, and if the
            # primary_name_hidden flag is set.
            for (o, s, sd) in list(session.query(CernerOrder,CernerSynonym,CernerSynonymDisplay)
                     .join(CernerSynonym)
                     .join(CernerSynonymDisplay)
                     .filter(CernerOrder.active == True)
                     .all()):
                if o.primary_name is not None and o.primary_name_hidden == False:
                    # We have a primary name and it is not hidden. Show the
                    # primary and hide the ordinary synonyms.
                    if s.is_primary:
                        sd.show = True
                    else:
                        sd.show = False
                else:
                    # Either we don't have a primary name or it is hidden. Hide
                    # the primary and show the ordinary synonyms.
                    if s.is_primary:
                        sd.show = False
                    else:
                        sd.show = True
            session.commit()
            ok = True
        except Exception as e:
            # Unexpected exception.
            print 'Caught exception %s: %s\n%s' % (str(type(e)), e, tb)
            messages.store('Caught exception', ok, e)
        messages.store('completed. act.count=%d, bad_hide_count=%d' % (act.count, act.row_handler.bad_hide_count), ok)
        # Delete the cerner_synonyms and cerner_orders that are not in the
        # spreadsheet. CASCADE will delete related cerner_synonyms,
        # cerner_synonym_displays and cerner_nonplaceholder_synonym rows. We
        # have to delete cerner_synonyms because they may be deleted
        # individually.
        session.execute("DELETE FROM mastermu_oltg.cerner_synonyms WHERE ready_for_delete=TRUE AND cerner_order_code!=0 ")
        session.execute("DELETE FROM mastermu_oltg.cerner_orders WHERE ready_for_delete=TRUE AND code!=0 ")

    finally:
        session.commit()
        oltg.models.release_session(session, engine)
    return 0 if ok else 1               # exit status


class RowHandler(labmed.spreadsheet_reader.BaseRowHandler):
    """
    Default row handler simply copies the data into the object.
    """
    def __init__(self, session, column_names, only_print, updated_date):
        labmed.spreadsheet_reader.BaseRowHandler.__init__(self, session, CernerOrder, column_names, only_print)
        self.updated_date = updated_date
        self.now = datetime.now()
        self.bad_hide_count = 0

    def handle(self, row):
        mnemonic = to_unicode(row[self.column_map['mnemonic']])
        catalog_cd = row[self.column_map['catalog_cd']]
        is_active = row[self.column_map['active_ind']] == '1'
        hide_flag = row[self.column_map['hide_flag']] == '1'
        mnemonic_type = row[self.column_map['mnemonic_type']]
        activity_type = row[self.column_map['ocs_activity_type_disp']]
        # Ignore the inactive rows, rows that that have 'zz' as part of their
        # name, or activities we should ignore.
        if is_active and mnemonic[:2].lower() != 'zz' and activity_type not in ocs_activity_type_disp_ignores:
            o = list(self.session.query(CernerOrder).filter(CernerOrder.code == catalog_cd))
            if len(o) == 0:
                # Not there yet. Need to create one.
                o = CernerOrder()
                o.code = catalog_cd
                o.lab_mnemonic = None   # Don't know yet
                o.primary_name_hidden = hide_flag
                o.active = is_active
                o.updated_date = self.updated_date
                o.ready_for_delete = False
                self.session.add(o)
                is_primary = mnemonic_type == 'Primary'
                if is_primary:
                    o.primary_name = mnemonic
                self.new_synonym(mnemonic, catalog_cd, is_primary=is_primary, show=not hide_flag)
            else:
                # Found an existing CernerOrder object. Add synonyms or update primary.
                o = o[0]
                o.updated_date = self.updated_date
                o.ready_for_delete = False
                if mnemonic_type == 'Primary':
                    if o.primary_name is None:
                        o.primary_name = mnemonic
                        # Earlier record had hide=no, now hide=yes (or the other way around)
                        # Set it to what this Primary record says.
                        if o.primary_name_hidden != hide_flag:
                            o.primary_name_hidden = hide_flag
                            self.bad_hide_count += 1
                    primary_synonym = list(self.session.query(CernerSynonym)
                                           .filter_by(cerner_order_code=catalog_cd)
                                           .filter_by(is_primary=True)
                                           .all())
                    if len(primary_synonym) == 0:
                        # Didn't find it for some reason, create it.
                        self.new_synonym(mnemonic, o.code, is_primary=True, show=not hide_flag)
                    else:
                        s = primary_synonym[0]
                        # Make sure we get a name change, if any.
                        if s.name != mnemonic:
                            s.name = mnemonic
                        s.updated_date = self.updated_date
                        s.ready_for_delete = False
                else:                   # Ordinary synonym.
                    synonyms = list(self.session.query(CernerSynonym)
                                    .filter_by(cerner_order_code=catalog_cd)
                                    .all())
                    # Check to see if it already there.
                    if len(synonyms) == 0:
                        # No synonyms yet.
                        self.new_synonym(mnemonic, o.code)
                    else:
                        for s in synonyms:
                            if s.name == mnemonic:
                                s.updated_date = self.updated_date
                                s.ready_for_delete = False
                                break
                        else:
                            # Didn't find the name. Add it.
                            self.new_synonym(mnemonic, o.code)
                self.session.commit()


    def new_synonym(self, name, code, is_primary=False, show=True):
        """
        Create new CernerSynonym and CernerSynonymDisplay objects.
        """
        self.session.commit()           # Write the CernerObject
        s = CernerSynonym()
        s.cerner_order_code = code
        s.name = name
        s.is_primary = is_primary
        s.updated_date = self.updated_date
        s.ready_for_delete = False
        self.session.add(s)
        self.session.commit()           # Write the CernerSynonym
        sd = CernerSynonymDisplay()
        sd.cerner_synonym_id = s.id
        sd.show = show
        self.session.add(sd)
        self.session.commit()           # Write the CernerSynonymDisplay
        
