#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Makes sure that all tests can be displayed.
"""


import os
from os import path
import unittest
from labmed.util.pluralize import just_pluralize
from datetime import datetime
import getters
import re
import sys
import traceback

import oltg.config as config
import oltg.models
from oltg.controllers import app
from oltg.controllers.display import display_page
import oltg.models.object_queries as object_queries


class AfterConvertOldOltg(unittest.TestCase):
    def test_all(self):
        configfile = path.join('config', os.environ['HOSTNAME'], 'oltg') + '.cfg'
        config_dict = config.read(configfile)
        (session, engine) = oltg.models.setup_db_session(config_dict)
        oltg.models.setup_db_models(session, engine)
        prev_ch = ''
        oltg.models.object_query = object_queries.ProdObjectQueries(session, config_dict['db_type'])
        mnemonics = getters.get_all_oltg(session)
        sys.stderr.write('%d tests\n' % (len(mnemonics),))
        for (mnemonic,) in mnemonics:
            ch = mnemonic[0]
            if ch != prev_ch:
                print ch
                prev_ch = ch
            sys.stderr.write('.')
            try:
                environ = dict(SESSION = session,
                               ENGINE = engine,
                               CONFIG = config_dict,
                               STAFF_ONLY = True,
                               EDIT_MODE = True)
                environ[app + '.parameters'] = {'mnemonic':mnemonic}
                dis = display_page(environ, lambda ok,atts: None, None)
                self.assertTrue(len(dis) > 0)
                # Make sure the mnemonic is enclosed in markup. If the markup changes, this will fail.
                self.assertTrue(dis[0].find('<td>' + mnemonic + '</td>') >= 0)
            except UnicodeEncodeError as e:
                o = list(getters.get_oltg(session, mnemonic))[0]
                xref = [x.cross_reference for x in getters.get_xref(session, mnemonic)]
                processing_instructions = '' if o.processing_instructions is None else [ord(c) for c in o.processing_instructions] 
                extra = 'amount="%s"\ncollection="%s"\ncross_references="%s"\ndone_other="%s"\nmethod="%s"\nname="%s"\nprocessing_instructions="%s"\n%s\nreference_range_addendum="%s"\nspecimen_handling="%s"\ntest_info="%s"' % (o.amount, o.collection, xref, o.done_other, o.method, o.name, o.processing_instructions, processing_instructions, o.reference_range_addendum, o.specimen_handling, o.test_info)
                raise Exception('Caught UnicodeEncodeError for mnemonic %s: %s\n%s' % (mnemonic,e,extra))
            except Exception as e:
                tb = traceback.format_exc()
                print 'Caught Exception %s for mnemonic %s\n%s' % (e, mnemonic, tb)
                raise e
        print

if __name__ == '__main__':
    unittest.main()
