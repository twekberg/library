#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Generate the parameters for the psql \copy command to import the olt OLTG.

Not useful when run standalong.
"""

# Example:
#   ./runoltg import_twe /home/tekberg/SANDBOX/oltg-short.csv

import sys
reload(sys)
sys.setdefaultencoding('8859')

import argparse
from datetime import datetime
import os
import os.path
import re
import sys
import warnings

import xlrd
import sqlalchemy.exc

import oltg.subcommands
import oltg.models
import oltg.models.object_queries as object_queries
from oltg.models.create_models import OldOltg
from oltg.models.messages import Messages


def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('oltg_file', action="store",
                        help='This is the file that contains the old OLTG CSV data.')
    parser.add_argument('real_oltg_file', action="store",
                        help='This is the file that will  contain the old OLTG CSV data when the COPY is done.')


def action(args):
    """
    Scan the old OLTG file.
    """
    (d, session, engine) = oltg.subcommands.init_args(args)
    messages = Messages(session, 'Old OLTG COPY params')
    try:
        filename = args.oltg_file
        real_oltg_file = args.real_oltg_file
        ok = False
        messages.store('started')
        try:
            count = 0
            with open(filename) as in_file:
                first_line = True
                for line in in_file:
                    line = line.rstrip()
                    row = re.findall(r'"([^"]*)"(?:,|$)', line)
                    if first_line:
                        first_line = False
                        # Get the column headers.
                        column_headers = [sqlify(col) for col in row]
                        break
            sql = """mastermu.oltg (%s) FROM '%s' NULL AS '' CSV HEADER""" % (','.join(column_headers), real_oltg_file)
            print sql
            ok = True
        except Exception as e:
            # Unexpected exception.
            messages.store('Caught exception', ok, e)
        messages.store('completed', ok)
    finally:
        oltg.models.release_session(session, engine)
    return 0 if ok else 1               # exit status


def sqlify(col):
    """
    Convert to name suitable for SQL.
    """
    # Remove leading/trailing double quotes.
    return col.lower().replace('-', '_').replace('#', 'number')
