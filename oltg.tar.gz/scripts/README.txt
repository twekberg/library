This directory contains several kinds of scripts:

auto_scan_lis.py - compares data of last successful LIS feed load with the date
of the current feed file. If the feed file is more recent then the subcommands
scan_lis and push_to_prod are executed.

copy-files - used to deploy the code.

delete-test - deletes a single test from all tables.
delete-tests - deletes all tests using a bcDump file as input.
extract-mnemonic - extracts test mnemonics from a bcDump file.

import-cerner-names - reads an ecode file for cerner (orca) names.

README.txt - this file.

update-oltg-from-web - updates the oltg schema using data retrieved from byblos.

get-oltg-static-page.cgi - web front end for static OLTG pages
wget-oltg-page - retrieves one static page from byblos
wget-oltg-pages - retrieves all static pages using the mnemonics in the old oltg table.

Cron jobs are set up to run

  auto_scan_lis.py on odin as tekberg

  update-oltg-from-web on odin as tekberg

  wget-oltg-pages on web as root
