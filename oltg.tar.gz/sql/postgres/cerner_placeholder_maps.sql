--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2012 University of Washington Medical Center
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Medical Center and is not to
--    be disclosed to any third party without prior express written
--    permission of University of Washington Medical Center University
--    of Washington Medical Center, as the author and owner under 17
--    U.S.C. Sec. 201(b) of this work made for hire, claims copyright
--    in this material as an unpublished work under 17 U.S.C. Sec.s 102
--    and 104(a)
-- 
--  ******************************************************************* 


CREATE TABLE mastermu_oltg.cerner_placeholder_maps (
  "lab_mnemonic" varchar(16) NOT NULL PRIMARY KEY,
  "placeholder_lab_mnemonic" varchar(16) NOT NULL,
  "ready_for_delete" boolean NOT NULL DEFAULT FALSE
);

COMMENT ON TABLE mastermu_oltg.cerner_placeholder_maps IS 'Maps a non-placeholder lab mnemonic that is not defined in Cerner to a placeholder lab mnemonic which is defined in Cerner.';

