#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Defines a base class for models.

Look at the methods' help strings for details.
"""


class BaseModel(object):
    def __str__(self):
        """
        Generalized method for displaying details about the object.
        """
        return self.__class__.__name__ + ('[%s]' % (', '.join(['%s=%s' % (column.name, self.__getattribute__(column.name) if column.name in dir(self) else 'None') for column in self.__class__.db_types.columns]),))


    def get_column_names(self):
        """
        Return a list of all column names.
        """
        return [column.name for column in self.__class__.db_types.columns]


    def get(self, column_name):
        """
        Get the value for a column.
        """
        return self.__getattribute__(column_name)


    def row_to_dict(self, d):
        """
        Get a dictionary of values.
        For each key in d, get the value, and store it in a new dictionary using
        d[k] as the key.

        For example, assume an OldOltg object, a dictionary where the keys are
        mastermu.oltg_staging column names, and the dictionary's values are the
        corresponding LIS feed names. This method will return a dictionary
        where a LIS feed column names are used to retrieve the corresponding DB
        values.
        """
        out_d = {}
        for db_k in d:
            try:
                v = self.get(db_k)
                out_d[d[db_k]] = '' if v is None else v
            except AttributeError:
                # Attribute isn't there. Skip it.
                pass
        return out_d


    def set(self, name, value):
        """
        Set a column by its name to a value.
        """
        if self.get_db_type_name(name) == 'INTEGER' and value == '':
            value = None
        self.__setattr__(name, value)


    def get_db_type_name(self, name):
        """
        Get the database type of the column.
        """
        return list(self.db_types.columns)[self.get_column_names().index(name)].type.__class__.__name__


    def get_db_type_length(self, name):
        """
        If the column has a length (e.g. VARCHAR) return its length.
        If not, return None
        """
        try:
            return list(self.db_types.columns)[self.get_column_names().index(name)].type.length
        except AttributeError as e:
            return None
