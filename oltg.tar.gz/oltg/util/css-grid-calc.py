#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2011 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************

"""
Read a CSS file evaluating markup.

Markup language:
%{python expression} --> whatever %s generates
%set{name=expression} --> no output
%%                   --> %   # Escape for %

The %{...} can be anywhere on a line. Multiple instances of ${...} are
allowed.  After a %{...} is replaced, scanning continues with the next
character after the replacement.

The %set{ must be at the start of a line. Any text after the closing }
in a %set is ignored.

The %% is only needed when the output needs to be %{...}. Use %%{...}.

All other instances of a % are ignored.

Usage:
  python css-grid-calc.py input_filename

The output goes to a file of the same name with a .css extension.
The input_filename cannot have an extension of .css.
"""


import sys
import os.path
import re


#                             1     1 2     2
set_pat = re.compile(r'^%set\{([^,]+)=([^}]+)}')
#                         1     1
expr_pat = re.compile(r'(?<!%)%{([^}]+)}')

# The symbol table for eval.
symtab = {}


def main(in_filename):
    (name, ext) = os.path.splitext(in_filename)
    out_filename = name + '.css'
    if in_filename == out_filename:
        print 'The input filename must not be a .css file.'
        exit(1)
    with open(out_filename, 'w') as out:
        with open(in_filename) as inp:
            line_number = 0
            for line in inp:
                line_number += 1
                if line.find('%') < 0:
                    # No markup.
                    out.write(line)
                    continue
                mat = set_pat.search(line)
                if mat:
                    name = mat.group(1)
                    expr = mat.group(2)
                    value = evaluate(expr)
                    if value.isdigit():
                        value = int(value)
                    symtab[name] = value
                else:
                    # Look for a python expression to evaluate
                    pos = 0
                    while True:
                        mat = expr_pat.search(line, pos)
                        if not mat:
                            break
                        value = evaluate(mat.group(1))
                        line_start = line[0:mat.start()]
                        line = line_start + value + line[mat.end():]
                        pos = len(line_start) + len(value)
                    if line.find('%%') >= 0:
                        line = line.replace('%%', '%')
                    out.write(line)


def evaluate(expr):
    """Evaluate an expression, and return a string result."""
    try:
        value = str(eval(expr, symtab))
    except Exception as e:
        print 'Error while evaluating expression "%s": Exception %s: %s' % (expr, str(type(e)), e)
        value = expr
    return value


if __name__ == '__main__':
    if len(sys.argv) != 2:
        print "Usage: python css-grid-calc.py csx-filename"
        exit(1)
    main(sys.argv[1])
