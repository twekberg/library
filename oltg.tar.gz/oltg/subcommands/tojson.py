"""
Serialize data for a lab test as a JSON file.

JSON files store all data required to render either public or
staff-only pages. Serializes a dict containing a key-pair for each
attribute.

Note that JSON files can be deserialized to a dict `d` like this:

    import json
    with open('file.json') as infile:
        d = json.load(infile)
"""

import argparse
import sys
import pprint
import json
import os
import os.path

import oltg.subcommands
import oltg.models
import oltg.models.object_queries as object_queries
from oltg.models.messages import Messages
from oltg.controllers.db_interface import get_mnemonic_detail

def get_all_mnemonics(session):
    # Need to get ALL mnemonic, even when security_flag='N', because some of
    # those are components of public tests.  For example HCTG has HCT as a
    # component, which has security_flag='N' and order_flag='N'.  HTCG has
    # security_flag='E' and order_flag='Y'.
    sql = """SELECT mnemonic FROM mastermu_oltg.oltg ORDER BY 1"""
    return [x[0] for x in session.execute(sql)]

def build_parser(parser):
    oltg.subcommands.default_parser(parser)
    parser.add_argument('-m', '--mnemonics', nargs = '*',
                        help = 'optional list of lab mnemonics; serializes all if not provided.',
                        default = None)
    parser.add_argument('-o','--outdir', default=None,
                        help="Directory in which to store output [default: 'mnemonics_json_dir' from config]")
    parser.add_argument('-v','--verbose', action = 'count', default = 1,
                        help = '-v, be more verbose; -vv, be even more verbose')
    
def action(args):
    (d, session, engine) = oltg.subcommands.init_args(args)
    oltg.models.object_query = object_queries.ProdObjectQueries(session, d['db_type'])
    if args.outdir is None:
        args.outdir = d['mnemonics_json_dir']

    dump_all = args.mnemonics is None
    mnemonics = get_all_mnemonics(session) if dump_all else args.mnemonics

    if not (args.outdir == '-' or os.path.exists(args.outdir)):
        os.makedirs(args.outdir)
    ok = True
    try:
        messages = Messages(session, 'tojson')
        messages.store('started with %d mnemonics' % (len(mnemonics),))
        count = 0
        os.umask(0)                     # Make sure others can rewrite this file.
        for mne in [m.upper() for m in mnemonics]:
            count += 1
            data = get_mnemonic_detail(mne)
            if args.verbose == 2:
                sys.stdout.write(data['mnemonic'])
                if count % 10 == 0:
                    sys.stdout.write('\n')
                else:
                    sys.stdout.write(' ')
            if args.verbose > 2:
                print data['mnemonic'], data['name']
            if args.verbose > 3:
                pprint.pprint(data)
            if args.outdir=='-':
                json_dump(data, sys.stdout)
            else:
                with open(os.path.join(args.outdir, '%s.json' % mne), 'w') as fout:
                    json_dump(data, fout)
        if args.verbose == 2:
            sys.stdout.write('\n')
    except Exception as e:
        ok = False
        messages.store('Caught exception', ok, e)
    finally:
        messages.store('completed', ok)
    return 0 if ok else 1

def json_dump(data, fout):
    json.dump(data, fout, sort_keys=True, indent=4)
