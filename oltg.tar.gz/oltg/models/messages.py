#  @(#) $Id:  $  

### *********************************************************************
###
###   Copyright (c) 2012 University of Washington Laboratory Medicine
###   All Rights Reserved
###
###   The information contained herein is confidential to and the
###   property of University of Washington Laboratory Medicine and is
###   not to be disclosed to any third party without prior express
###   written permission of University of Washington Laboratory Medicine.
###   University of Washington Laboratory Medicine, as the
###   author and owner under 17 U.S.C. Sec. 201(b) of this work made
###   for hire, claims copyright in this material as an unpublished 
###   work under 17 U.S.C. Sec.s 102 and 104(a)   
###
### *********************************************************************


"""
Interface to the messages table for status messages.

Create a class instance with the details that say the same, then call
the store method to write to the messages table.
"""


import sys
import traceback
from datetime import datetime

from oltg.models.create_models import Message


class Messages(object):
    def __init__(self, session, category):
        self.session = session
        self.category = category

    def store(self, text, ok = True, failure_exception = None):
        """
        Store a status message in the database. A trigger records the date/time.
        failure_exception can be either a string, or an excepption. For exceptions, a traceback is generated.
        """
        m = Message()
        m.category = self.category
        m.text = text
        m.created_date = datetime.now()
        m.ok = ok
        if isinstance(failure_exception, basestring):
            failure_detail = failure_exception
        elif failure_exception:
            # Store the traceback.
            (ty, value, tb) = sys.exc_info()
            failure_details = []
            for (file, line, module, text) in traceback.extract_tb(tb):
                if text:
                    # text is a line of source code
                    failure_details.append('  File "%s", line %d, in %s\n    %s' % (file, line, module, text))
                else:
                    failure_details.append('  File "%s", line %d, in %s' % (file, line, module))
            failure_detail = 'Traceback (most recent call last):\n%s\n%s: %s' % (
                '\n'.join(failure_details),
                failure_exception.__class__.__name__,
                value)
        else:
            failure_detail = None
        m.failure_detail = failure_detail
        self.session.add(m)
        self.session.commit()
