--  @(#) $Id:  $  

--  *********************************************************************
-- 
--    Copyright (c) 2010 University of Washington Medical Center
--    All Rights Reserved
-- 
--    The information contained herein is confidential to and the
--    property of University of Washington Medical Center and is not to
--    be disclosed to any third party without prior express written
--    permission of University of Washington Medical Center University
--    of Washington Medical Center, as the author and owner under 17
--    U.S.C. Sec. 201(b) of this work made for hire, claims copyright
--    in this material as an unpublished work under 17 U.S.C. Sec.s 102
--    and 104(a)
-- 
--  ******************************************************************* 

DROP TABLE IF EXISTS access_logs;
DROP TABLE IF EXISTS audit_logs;
DROP TABLE IF EXISTS billing_and_cpt_codes;
DROP TABLE IF EXISTS billing_and_cpt_codes_staging;
DROP TABLE IF EXISTS caution_urls;
DROP TABLE IF EXISTS caution_urls_staging;
DELETE FROM cerner_orders;
DROP TABLE IF EXISTS cerner_synonym_displays;
DROP TABLE IF EXISTS cerner_nonplaceholder_synonyms;
DROP TABLE IF EXISTS cerner_synonyms;
DROP TABLE IF EXISTS cerner_placeholder_maps;
DROP TABLE IF EXISTS cerner_orders;
DROP TABLE IF EXISTS component_tests;
DROP TABLE IF EXISTS component_tests_staging;
DROP TABLE IF EXISTS cross_references;
DROP TABLE IF EXISTS cross_references_staging;
DROP VIEW IF EXISTS dept_tally_view;
DROP TABLE IF EXISTS fee_schedules;
DROP TABLE IF EXISTS lis_feed;
DROP TABLE IF EXISTS lis_feed_stating;
DROP TABLE IF EXISTS messages;
DROP TABLE IF EXISTS reference_ranges;
DROP TABLE IF EXISTS reference_ranges_staging;
DROP TABLE IF EXISTS special_terms;
DROP TABLE IF EXISTS tally_rankings;
DROP TABLE IF EXISTS oltg;
DROP TABLE IF EXISTS oltg_staging;
